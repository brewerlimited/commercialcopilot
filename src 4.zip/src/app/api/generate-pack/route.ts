import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { getAuthUserFromRequest } from "@/lib/apiAuth";
import { buildGenerateDraftPayload, tryStoreDraftPayload } from "@/lib/generateDraftPayload";
import { generateAiDraftFromPayload } from "@/lib/aiDraft";

export const dynamic = "force-dynamic";

function clampNum(value: any, fallback = 0) {
  const n = typeof value === "number" ? value : parseFloat(String(value));
  return Number.isFinite(n) ? n : fallback;
}

function isActiveSubscription(status?: string | null) {
  return status === "active" || status === "trialing";
}

function isUuid(value: unknown) {
  return (
    typeof value === "string" &&
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)
  );
}

export async function POST(req: NextRequest) {
  try {
    const user = await getAuthUserFromRequest(req);
    if (!user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const eventId = String(body?.eventId || body?.event_id || "").trim();
    const requestedForceGenerate = Boolean(body?.forceGenerateMode);
    const pack = body?.pack || {};

    if (!isUuid(eventId)) {
      return NextResponse.json({ error: "Invalid event id" }, { status: 400 });
    }

    const admin = supabaseAdmin();

    const eventRes = await admin
      .from("events")
      .select("id,user_id")
      .eq("id", eventId)
      .eq("user_id", user.id)
      .maybeSingle();

    if (eventRes.error) throw eventRes.error;
    if (!eventRes.data) {
      return NextResponse.json({ error: "Event not found" }, { status: 404 });
    }

    const [profileRes, creditRes] = await Promise.all([
      admin
        .from("profiles")
        .select("id,subscription_status,is_admin_unlimited,credits_remaining")
        .eq("id", user.id)
        .maybeSingle(),
      admin
        .from("user_credits")
        .select("credits_remaining")
        .eq("user_id", user.id)
        .maybeSingle(),
    ]);

    if (profileRes.error) throw profileRes.error;
    if (creditRes.error) throw creditRes.error;

    const profile = profileRes.data || {};
    const isAdminUnlimited = Boolean((profile as any).is_admin_unlimited);
    const forceGenerateMode = requestedForceGenerate && isAdminUnlimited;
    const creditsRemaining = clampNum(
      (creditRes.data as any)?.credits_remaining ?? (profile as any)?.credits_remaining,
      0
    );

    // Idempotency guard: once a pack has been generated for this event,
    // normal Generate Pack calls must return the saved pack instead of creating
    // a duplicate pack or deducting another credit. Only the internal/admin
    // force-generate mode is allowed to bypass this.
    if (!forceGenerateMode) {
      const existingPackRes = await admin
        .from("event_packs")
        .select("id")
        .eq("event_id", eventId)
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (existingPackRes.error) throw existingPackRes.error;

      if (existingPackRes.data?.id) {
        const draftPayload = await buildGenerateDraftPayload({
          admin,
          eventId,
          userId: user.id,
        });

        await tryStoreDraftPayload({
          admin,
          eventId,
          userId: user.id,
          packId: existingPackRes.data.id,
          payload: draftPayload,
        });

        return NextResponse.json({
          success: true,
          existing: true,
          packId: existingPackRes.data.id,
          creditsRemaining,
          draftPayload,
        });
      }
    }

    if (!isAdminUnlimited && !isActiveSubscription((profile as any).subscription_status)) {
      return NextResponse.json(
        { error: "Your subscription is not active. Open Billing to upgrade before generating a pack." },
        { status: 403 }
      );
    }

    if (!isAdminUnlimited && creditsRemaining <= 0) {
      return NextResponse.json(
        { error: "No credits remaining. Open Billing to upgrade or buy additional credits before generating a pack." },
        { status: 403 }
      );
    }

    const draftPayload = await buildGenerateDraftPayload({
      admin,
      eventId,
      userId: user.id,
    });

    console.info(`[generate-pack] AI generation started for event `);
    const aiDraft = await generateAiDraftFromPayload(draftPayload);
    console.info(`[generate-pack] AI generation completed for event `);

    const insertPackRes = await admin
      .from("event_packs")
      .insert({
        event_id: eventId,
        user_id: user.id,
        delay_days: clampNum(pack.delay_days, 0),
        defined_cost: clampNum(pack.defined_cost, 0),
        prelim_cost: clampNum(pack.prelim_cost, 0),
        fee_amount: clampNum(pack.fee_amount, 0),
        total_value: clampNum(pack.total_value, 0),
        readiness_score: clampNum(pack.readiness_score, 0),
        pack_version: clampNum(pack.pack_version, 1),
      })
      .select("id")
      .single();

    if (insertPackRes.error) throw insertPackRes.error;

    await tryStoreDraftPayload({
      admin,
      eventId,
      userId: user.id,
      packId: insertPackRes.data?.id,
      payload: draftPayload,
      aiDraft,
    });

    let nextCredits = creditsRemaining;

    if (!isAdminUnlimited) {
      nextCredits = Math.max(0, creditsRemaining - 1);
      const now = new Date().toISOString();

      const [profileUpdateRes, creditUpdateRes] = await Promise.all([
        admin
          .from("profiles")
          .update({ credits_remaining: nextCredits, updated_at: now })
          .eq("id", user.id),
        admin
          .from("user_credits")
          .upsert(
            { user_id: user.id, credits_remaining: nextCredits, updated_at: now },
            { onConflict: "user_id" }
          ),
      ]);

      if (profileUpdateRes.error) throw profileUpdateRes.error;
      if (creditUpdateRes.error) throw creditUpdateRes.error;
    }

    return NextResponse.json({
      success: true,
      generated: true,
      packId: insertPackRes.data?.id,
      creditsRemaining: nextCredits,
      draftPayload,
      aiDraft,
    });
  } catch (error: any) {
    console.error("Generate pack error:", error);
    return NextResponse.json(
      { error: error?.message || "Failed to generate pack" },
      { status: 500 }
    );
  }
}
