export type ExportEventMeta = {
  title: string;
  contractType?: string | null;
  contractSource?: string | null;
  delayDays?: number;
  generatedAt?: string;
  instructionRef?: string | null;
  ceRef?: string | null;
  programmeRef?: string | null;
};

export type ExportBasis = {
  happened_summary?: string;
  cause_type?: string | null;
  cause_summary?: string;
  difference_from_plan?: string;
  mechanism_tags?: string[];
  mitigation_summary?: string;
  time_impact_toggle?: string;
};

export type ExportResourceLine = {
  category: string;
  item_name: string;
  unit: string;
  qty: number;
  hours?: number | null;
  rate: number;
  total: number;
  notes?: string | null;
  start_date?: string | null;
  end_date?: string | null;
  linked_event?: string | null;
};

export type ExportPrelimLine = {
  name: string;
  qty: number;
  unit: string;
  rate: number;
  notes?: string | null;
};

export type ExportValuation = {
  fee_percent: number;
  fee_basis: "defined_cost" | "defined_cost_plus_prelims";
  work_days_per_week?: number;
};

export type ExportReviewSettings = {
  include_basis?: boolean;
  include_entitlement?: boolean;
  include_time_impact?: boolean;
  include_evidence_register?: boolean;
  include_cost_summary?: boolean;
  include_prelims_fee?: boolean;
  include_risk_notes?: boolean;
  include_commercial_pushback?: boolean;
  include_excel?: boolean;
  include_pdf?: boolean;
  qualifications_notes?: string;
};

export type ExportFileCounts = {
  instructions: number;
  photos: number;
  site_records: number;
  programme: number;
  cost_support: number;
};

export type WorkbookPayload = {
  meta: ExportEventMeta;
  basis: ExportBasis;
  resources: ExportResourceLine[];
  prelims: ExportPrelimLine[];
  valuation: ExportValuation;
  review: ExportReviewSettings;
  fileCounts: ExportFileCounts;
  readiness: number;
  warnings: number;
  blockers: number;
};

type Cell = {
  value?: string | number;
  style?: string;
  mergeAcross?: number;
  type?: "String" | "Number";
};

type Row = Cell[];

type Sheet = {
  name: string;
  columns?: number[];
  rows: Row[];
};

type ColumnMode = "auto" | "fixed" | "wrap";

type ColumnRule = {
  mode: ColumnMode;
  min: number;
  max?: number;
  padding?: number;
  width?: number;
};

const STAFF_KEYWORDS = [
  "project manager",
  "quantity surveyor",
  "commercial manager",
  "site manager",
  "site supervisor",
  "foreman",
  "engineer",
  "planner",
  "administrator",
  "admin",
  "qs",
  "pm",
];

function sanitizeXmlText(value: unknown) {
  return String(value ?? "")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u0084\u0086-\u009F]/g, "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function money(n: number) {
  const v = Number(n);
  return Number.isFinite(v) ? Number(v.toFixed(2)) : 0;
}

function displayDate(value?: string | null) {
  if (!value) return "";
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleDateString("en-GB");
}

function normaliseText(value?: string | null) {
  return (value ?? "").trim();
}

function byHierarchy(a: ExportResourceLine, b: ExportResourceLine) {
  return `${a.linked_event ?? ""}|${a.start_date ?? ""}|${a.notes ?? ""}|${a.item_name}`.localeCompare(
    `${b.linked_event ?? ""}|${b.start_date ?? ""}|${b.notes ?? ""}|${b.item_name}`
  );
}

function looksLikeStaff(itemName: string, notes?: string | null) {
  const text = `${itemName} ${notes ?? ""}`.toLowerCase();
  return STAFF_KEYWORDS.some((k) => text.includes(k));
}

function calcPrelimsTotal(prelims: ExportPrelimLine[]) {
  return prelims.reduce((sum, line) => sum + (Number(line.qty) || 0) * (Number(line.rate) || 0), 0);
}

function groupLabel(line: ExportResourceLine) {
  return {
    activity: normaliseText(line.linked_event) || "General activity",
    date: displayDate(line.start_date),
    task: normaliseText(line.notes) || "General task",
  };
}

function titleRows(title: string, subtitle: string, cols: number): Row[] {
  return [
    [{ value: title, style: "title", mergeAcross: cols - 1 }],
    [{ value: subtitle, style: "subtitle", mergeAcross: cols - 1 }],
    [],
  ];
}

function buildStructuredRows(lines: ExportResourceLine[], itemLabel: string): Row[] {
  const rows: Row[] = [];
  const sorted = [...lines].sort(byHierarchy);
  let lastActivity = "";
  let lastDate = "";
  let lastTask = "";

  for (const line of sorted) {
    const g = groupLabel(line);
    if (g.activity !== lastActivity) {
      rows.push([{ value: g.activity, style: "group", mergeAcross: 6 }]);
      lastActivity = g.activity;
      lastDate = "";
      lastTask = "";
    }
    if (g.date !== lastDate) {
      rows.push([{ value: `Date: ${g.date || "—"}`, style: "subgroup", mergeAcross: 6 }]);
      lastDate = g.date;
      lastTask = "";
    }
    if (g.task !== lastTask) {
      rows.push([{ value: `Task: ${g.task}`, style: "task", mergeAcross: 6 }]);
      lastTask = g.task;
    }

    rows.push([
      { value: line.item_name || itemLabel, style: "item" },
      { value: line.unit === "hour" ? (Number(line.hours) || Number(line.qty) || 0) : Number(line.qty) || 0, style: "cell", type: "Number" },
      { value: line.unit || "", style: "cell" },
      { value: money(Number(line.rate) || 0), style: "currency", type: "Number" },
      { value: money(Number(line.total) || 0), style: "currency", type: "Number" },
      { value: normaliseText(line.end_date) || "", style: "cell" },
      { value: normaliseText(line.notes) || "", style: "cellWrap" },
    ]);
  }

  if (rows.length === 0) {
    rows.push([{ value: "No lines entered.", style: "muted", mergeAcross: 6 }]);
  }

  return rows;
}

function buildSummarySheet(payload: WorkbookPayload): Sheet {
  const staff = payload.resources.filter((x) => x.category === "staff" || (x.category === "labour" && looksLikeStaff(x.item_name, x.notes)));
  const labour = payload.resources.filter((x) => x.category === "labour" && !looksLikeStaff(x.item_name, x.notes));
  const plant = payload.resources.filter((x) => x.category === "plant" || x.category === "equipment");
  const materials = payload.resources.filter((x) => x.category === "material" || x.category === "materials");
  const charges = payload.resources.filter((x) => x.category === "subcontract" || x.category === "charge" || x.category === "charges");
  const prelimsTotal = calcPrelimsTotal(payload.prelims);
  const definedCost = payload.resources.reduce((sum, x) => sum + (Number(x.total) || 0), 0);
  const feeBase = payload.valuation.fee_basis === "defined_cost_plus_prelims" ? definedCost + prelimsTotal : definedCost;
  const feeAmount = feeBase * ((Number(payload.valuation.fee_percent) || 0) / 100);
  const total = definedCost + prelimsTotal + feeAmount;

  const activityMap = new Map<string, number>();
  for (const line of payload.resources) {
    const activity = normaliseText(line.linked_event) || "General activity";
    activityMap.set(activity, (activityMap.get(activity) || 0) + (Number(line.total) || 0));
  }

  const rows: Row[] = [
    ...titleRows(payload.meta.title || "Compensation Event", "Commercial Co-Pilot — Summary", 5),
    [{ value: "Event", style: "label" }, { value: payload.meta.title || "—", style: "value", mergeAcross: 3 }],
    [{ value: "Generated", style: "label" }, { value: displayDate(payload.meta.generatedAt || new Date().toISOString()), style: "value" }, { value: "Contract", style: "label" }, { value: normaliseText(payload.meta.contractType)?.replaceAll("_", " ").toUpperCase() || "—", style: "value" }],
    [{ value: "Delay days", style: "label" }, { value: Number(payload.meta.delayDays) || 0, style: "value", type: "Number" }, { value: "Readiness", style: "label" }, { value: `${payload.readiness}%`, style: "value" }],
    [],
    [{ value: "Value summary", style: "section", mergeAcross: 4 }],
    [{ value: "Staff", style: "label" }, { value: money(staff.reduce((s, x) => s + (Number(x.total) || 0), 0)), style: "currency", type: "Number" }, { value: "Blockers", style: "label" }, { value: payload.blockers, style: "value", type: "Number" }],
    [{ value: "Labour", style: "label" }, { value: money(labour.reduce((s, x) => s + (Number(x.total) || 0), 0)), style: "currency", type: "Number" }, { value: "Warnings", style: "label" }, { value: payload.warnings, style: "value", type: "Number" }],
    [{ value: "Plant", style: "label" }, { value: money(plant.reduce((s, x) => s + (Number(x.total) || 0), 0)), style: "currency", type: "Number" }, { value: "Basis included", style: "label" }, { value: payload.review.include_basis ? "Yes" : "No", style: "value" }],
    [{ value: "Materials", style: "label" }, { value: money(materials.reduce((s, x) => s + (Number(x.total) || 0), 0)), style: "currency", type: "Number" }, { value: "Excel output", style: "label" }, { value: payload.review.include_excel ? "Yes" : "No", style: "value" }],
    [{ value: "Charges", style: "label" }, { value: money(charges.reduce((s, x) => s + (Number(x.total) || 0), 0)), style: "currency", type: "Number" }, { value: "PDF output", style: "label" }, { value: payload.review.include_pdf ? "Yes" : "No", style: "value" }],
    [{ value: "Prelims", style: "label" }, { value: money(prelimsTotal), style: "currency", type: "Number" }, { value: `Fee (${payload.valuation.fee_percent || 0}%)`, style: "label" }, { value: money(feeAmount), style: "currency", type: "Number" }],
    [{ value: "Total CE value", style: "totalLabel" }, { value: money(total), style: "total", type: "Number" }, { value: "Contract source", style: "label" }, { value: payload.meta.contractSource === "upload_contract" ? "Uploaded contract" : "Standard contract logic", style: "value" }],
    [],
    [{ value: "Activity summary", style: "section", mergeAcross: 4 }],
    [{ value: "Activity", style: "header" }, { value: "Value", style: "header" }, { value: "% of direct cost", style: "header" }, { value: "", style: "header" }],
  ];

  Array.from(activityMap.entries())
    .sort((a, b) => b[1] - a[1])
    .forEach(([activity, value]) => {
      rows.push([
        { value: activity, style: "cellWrap" },
        { value: money(value), style: "currency", type: "Number" },
        { value: definedCost > 0 ? `${((value / definedCost) * 100).toFixed(1)}%` : "0.0%", style: "value" },
        { value: "", style: "value" },
      ]);
    });

  return { name: "Summary", columns: [220, 95, 120, 150], rows };
}

function buildBasisSheet(payload: WorkbookPayload): Sheet {
  const b = payload.basis;
  const mech = (b.mechanism_tags || []).length ? (b.mechanism_tags || []).join(", ") : "—";
  const rows: Row[] = [
    ...titleRows(payload.meta.title || "Compensation Event", "Basis of Change", 4),
    [{ value: "What happened", style: "section", mergeAcross: 3 }],
    [{ value: b.happened_summary || "—", style: "body", mergeAcross: 3 }],
    [],
    [{ value: "Cause", style: "section", mergeAcross: 3 }],
    [{ value: b.cause_summary || "—", style: "body", mergeAcross: 3 }],
    [],
    [{ value: "Difference from plan", style: "section", mergeAcross: 3 }],
    [{ value: b.difference_from_plan || "—", style: "body", mergeAcross: 3 }],
    [],
    [{ value: "Mechanism tags", style: "section", mergeAcross: 3 }],
    [{ value: mech, style: "body", mergeAcross: 3 }],
    [],
    [{ value: "Mitigation", style: "section", mergeAcross: 3 }],
    [{ value: b.mitigation_summary || "—", style: "body", mergeAcross: 3 }],
    [],
    [{ value: "Time impact toggle", style: "label" }, { value: b.time_impact_toggle || "unsure", style: "value", mergeAcross: 2 }],
    [{ value: "Qualifications / notes", style: "label" }, { value: payload.review.qualifications_notes || "—", style: "body", mergeAcross: 2 }],
  ];
  return { name: "Basis of Change", columns: [180, 200, 200, 200], rows };
}

function buildSheetFromLines(name: string, lines: ExportResourceLine[], itemLabel: string): Sheet {
  const rows: Row[] = [
    ...titleRows(name, "Activity-led cost build-up", 7),
    [{ value: itemLabel, style: "header" }, { value: "Qty / Hrs", style: "header" }, { value: "Unit", style: "header" }, { value: "Rate", style: "header" }, { value: "Cost", style: "header" }, { value: "End / ref", style: "header" }, { value: "Notes", style: "header" }],
    ...buildStructuredRows(lines, itemLabel),
  ];
  return { name, columns: [280, 80, 70, 80, 95, 85, 220], rows };
}

function buildPrelimsSheet(payload: WorkbookPayload): Sheet {
  const prelimsTotal = calcPrelimsTotal(payload.prelims);
  const definedCost = payload.resources.reduce((sum, x) => sum + (Number(x.total) || 0), 0);
  const feeBase = payload.valuation.fee_basis === "defined_cost_plus_prelims" ? definedCost + prelimsTotal : definedCost;
  const feeAmount = feeBase * ((Number(payload.valuation.fee_percent) || 0) / 100);
  const rows: Row[] = [
    ...titleRows("Prelims + Fee", "Time-related costs and fee application", 6),
    [{ value: "Item", style: "header" }, { value: "Qty", style: "header" }, { value: "Unit", style: "header" }, { value: "Rate", style: "header" }, { value: "Cost", style: "header" }, { value: "Notes", style: "header" }],
  ];

  if (payload.prelims.length === 0) {
    rows.push([{ value: "No prelim items entered.", style: "muted", mergeAcross: 5 }]);
  } else {
    for (const line of payload.prelims) {
      rows.push([
        { value: line.name || "Prelim item", style: "cellWrap" },
        { value: Number(line.qty) || 0, style: "cell", type: "Number" },
        { value: line.unit || "", style: "cell" },
        { value: money(Number(line.rate) || 0), style: "currency", type: "Number" },
        { value: money((Number(line.qty) || 0) * (Number(line.rate) || 0)), style: "currency", type: "Number" },
        { value: normaliseText(line.notes) || "", style: "cellWrap" },
      ]);
    }
  }

  rows.push(
    [],
    [{ value: "Summary", style: "section", mergeAcross: 5 }],
    [{ value: "Defined Cost", style: "label" }, { value: money(definedCost), style: "currency", type: "Number" }, { value: "", style: "label", mergeAcross: 4 }],
    [{ value: "Prelims total", style: "label" }, { value: money(prelimsTotal), style: "currency", type: "Number" }, { value: "", style: "label", mergeAcross: 4 }],
    [{ value: `Fee (${payload.valuation.fee_percent || 0}%)`, style: "label" }, { value: money(feeAmount), style: "currency", type: "Number" }, { value: payload.valuation.fee_basis === "defined_cost_plus_prelims" ? "Based on Defined Cost + Prelims" : "Based on Defined Cost only", style: "value", mergeAcross: 4 }],
    [{ value: "Total CE value", style: "totalLabel" }, { value: money(definedCost + prelimsTotal + feeAmount), style: "total", type: "Number" }, { value: "", style: "totalLabel", mergeAcross: 4 }],
  );

  return { name: "Prelims + Fee", columns: [250, 70, 70, 80, 90, 220], rows };
}

function buildTimeRiskSheet(payload: WorkbookPayload): Sheet {
  const rows: Row[] = [
    ...titleRows("Time Risk", "Programme and prolongation overview", 4),
    [{ value: "Delay days", style: "label" }, { value: Number(payload.meta.delayDays) || 0, style: "value", type: "Number" }, { value: "Time impact toggle", style: "label" }, { value: payload.basis.time_impact_toggle || "unsure", style: "value" }],
    [{ value: "Programme records", style: "label" }, { value: payload.fileCounts.programme, style: "value", type: "Number" }, { value: "Site records", style: "label" }, { value: payload.fileCounts.site_records, style: "value", type: "Number" }],
    [],
    [{ value: "Time impact narrative", style: "section", mergeAcross: 3 }],
    [{
      value: payload.basis.time_impact_toggle === "yes"
        ? `Current inputs indicate a time effect with ${Number(payload.meta.delayDays) || 0} day(s) recorded against the event. The final narrative can be developed further once the AI layer is connected.`
        : payload.basis.time_impact_toggle === "no"
          ? "Current inputs indicate no direct time impact has been recorded for this event."
          : "Time impact remains to be confirmed from the current inputs.",
      style: "body",
      mergeAcross: 3,
    }],
  ];
  return { name: "Time Risk", columns: [160, 120, 160, 180], rows };
}

function buildAuditSheet(payload: WorkbookPayload): Sheet {
  const totalEvidence = payload.fileCounts.instructions + payload.fileCounts.photos + payload.fileCounts.site_records + payload.fileCounts.programme + payload.fileCounts.cost_support;
  const rows: Row[] = [
    ...titleRows("Audit", "Generation metadata and checks", 4),
    [{ value: "Generated at", style: "label" }, { value: new Date(payload.meta.generatedAt || new Date().toISOString()).toLocaleString("en-GB"), style: "value", mergeAcross: 2 }],
    [{ value: "Readiness score", style: "label" }, { value: `${payload.readiness}%`, style: "value" }, { value: "Blockers", style: "label" }, { value: payload.blockers, style: "value", type: "Number" }],
    [{ value: "Warnings", style: "label" }, { value: payload.warnings, style: "value", type: "Number" }, { value: "Resource lines", style: "label" }, { value: payload.resources.length, style: "value", type: "Number" }],
    [{ value: "Evidence files", style: "label" }, { value: totalEvidence, style: "value", type: "Number" }, { value: "Prelim lines", style: "label" }, { value: payload.prelims.length, style: "value", type: "Number" }],
    [],
    [{ value: "Output selections", style: "section", mergeAcross: 3 }],
    [{ value: "Basis narrative", style: "label" }, { value: payload.review.include_basis ? "Included" : "Excluded", style: "value" }, { value: "Evidence register", style: "label" }, { value: payload.review.include_evidence_register ? "Included" : "Excluded", style: "value" }],
    [{ value: "Cost summary", style: "label" }, { value: payload.review.include_cost_summary ? "Included" : "Excluded", style: "value" }, { value: "Prelims + Fee", style: "label" }, { value: payload.review.include_prelims_fee ? "Included" : "Excluded", style: "value" }],
    [{ value: "Commercial pushback", style: "label" }, { value: payload.review.include_commercial_pushback ? "Included" : "Excluded", style: "value" }, { value: "PDF pack", style: "label" }, { value: payload.review.include_pdf ? "Included" : "Excluded", style: "value" }],
  ];
  return { name: "Audit", columns: [180, 130, 180, 130], rows };
}


function estimateTextLength(value: unknown) {
  const text = String(value ?? "").replace(/\s+/g, " ").trim();
  if (!text) return 0;

  let score = 0;
  for (const ch of text) {
    if (/[A-Z]/.test(ch)) score += 1.15;
    else if (/[mwMW@#%&]/.test(ch)) score += 1.2;
    else if (/[ilI.,'` ]/.test(ch)) score += 0.55;
    else if (/\d/.test(ch)) score += 0.95;
    else score += 1;
  }
  return Math.ceil(score);
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function getColumnRules(sheetName: string, columnCount: number): ColumnRule[] {
  if (sheetName === "Summary") {
    return [
      { mode: "fixed", min: 170, width: 170 },
      { mode: "fixed", min: 115, width: 115 },
      { mode: "fixed", min: 135, width: 135 },
      { mode: "fixed", min: 165, width: 165 },
    ];
  }

  if (sheetName === "Basis of Change") {
    return [
      { mode: "fixed", min: 170, width: 170 },
      { mode: "wrap", min: 165, max: 165 },
      { mode: "wrap", min: 165, max: 165 },
      { mode: "wrap", min: 165, max: 165 },
    ];
  }

  if (sheetName.includes("People") || sheetName === "2.0 Equipment" || sheetName === "3.0 Plant & Materials" || sheetName === "4.0 Charges") {
    return [
      { mode: "auto", min: 150, max: 240, padding: 14 },
      { mode: "fixed", min: 80, width: 80 },
      { mode: "auto", min: 70, max: 100, padding: 8 },
      { mode: "fixed", min: 85, width: 85 },
      { mode: "fixed", min: 100, width: 100 },
      { mode: "auto", min: 90, max: 120, padding: 8 },
      { mode: "wrap", min: 260, max: 300 },
    ];
  }

  if (sheetName === "Prelims + Fee") {
    return [
      { mode: "auto", min: 160, max: 240, padding: 12 },
      { mode: "fixed", min: 70, width: 70 },
      { mode: "auto", min: 65, max: 95, padding: 8 },
      { mode: "fixed", min: 85, width: 85 },
      { mode: "fixed", min: 100, width: 100 },
      { mode: "wrap", min: 260, max: 300 },
    ];
  }

  if (sheetName === "Time Risk") {
    return [
      { mode: "fixed", min: 150, width: 150 },
      { mode: "fixed", min: 110, width: 110 },
      { mode: "fixed", min: 150, width: 150 },
      { mode: "wrap", min: 240, max: 260 },
    ];
  }

  if (sheetName === "Audit") {
    return [
      { mode: "fixed", min: 170, width: 170 },
      { mode: "fixed", min: 130, width: 130 },
      { mode: "fixed", min: 170, width: 170 },
      { mode: "fixed", min: 130, width: 130 },
    ];
  }

  return Array.from({ length: columnCount }, () => ({ mode: "auto", min: 100, max: 180, padding: 10 }));
}

function computeSheetColumns(sheet: Sheet) {
  const columnCount = Math.max(
    sheet.columns?.length || 0,
    ...sheet.rows.map((row) => row.reduce((count, cell) => count + 1 + Math.max(0, cell?.mergeAcross || 0), 0)),
    0
  );

  const rules = getColumnRules(sheet.name, columnCount);
  const widths = Array.from({ length: columnCount }, (_, i) => rules[i]?.width || rules[i]?.min || sheet.columns?.[i] || 100);

  for (const row of sheet.rows) {
    let colIndex = 0;
    for (const cell of row) {
      const span = 1 + Math.max(0, cell?.mergeAcross || 0);
      if (span === 1 && cell && cell.value !== undefined) {
        const rule = rules[colIndex] || { mode: "auto", min: 100, max: 180, padding: 10 };
        if (rule.mode === "auto") {
          const contentWidth = estimateTextLength(cell.value) * 7 + (rule.padding || 10);
          const maxWidth = rule.max || 220;
          widths[colIndex] = clamp(Math.max(widths[colIndex], contentWidth), rule.min, maxWidth);
        } else if (rule.mode === "wrap") {
          widths[colIndex] = Math.max(widths[colIndex], rule.min);
        } else if (rule.mode === "fixed" && rule.width) {
          widths[colIndex] = rule.width;
        }
      }
      colIndex += span;
    }
  }

  return widths.map((w, i) => {
    const rule = rules[i];
    if (!rule) return w;
    if (rule.mode === "fixed") return rule.width || rule.min;
    if (rule.mode === "wrap") return clamp(w, rule.min, rule.max || rule.min);
    return clamp(w, rule.min, rule.max || w);
  });
}

function estimateRowHeight(row: Row, columnWidths: number[]) {
  if (!row || row.length === 0) return 18;
  let height = 20;
  let colIndex = 0;

  for (const cell of row) {
    const span = 1 + Math.max(0, cell?.mergeAcross || 0);
    const style = cell?.style || "";
    const text = String(cell?.value ?? "").trim();
    const mergedWidth = columnWidths.slice(colIndex, colIndex + span).reduce((a, b) => a + b, 0);

    if (style === "title") {
      height = Math.max(height, 28);
    } else if (style === "subtitle") {
      height = Math.max(height, 22);
    } else if ((style === "body" || style === "cellWrap" || style === "task" || style === "item") && text) {
      const approxLineCapacity = Math.max(14, Math.floor(mergedWidth / 7.2));
      const lines = Math.max(1, Math.ceil(estimateTextLength(text) / approxLineCapacity));
      const lineHeight = style === "body" ? 16 : 15;
      height = Math.max(height, Math.min(110, 8 + lines * lineHeight));
    }

    colIndex += span;
  }

  return Math.round(height);
}

function columnXml(width: number) {
  const ssWidth = Math.max(40, width) * 0.75;
  return `<Column ss:AutoFitWidth="0" ss:Width="${ssWidth.toFixed(2)}"/>`;
}

function cellXml(cell: Cell) {
  if (!cell || (cell.value === undefined && !cell.style && cell.mergeAcross === undefined)) return "<Cell/>";
  const style = cell.style ? ` ss:StyleID="${sanitizeXmlText(cell.style)}"` : "";
  const merge = typeof cell.mergeAcross === "number" && cell.mergeAcross > 0 ? ` ss:MergeAcross="${cell.mergeAcross}"` : "";
  const rawValue = cell.value ?? "";
  const type = cell.type || (typeof rawValue === "number" ? "Number" : "String");
  const value = type === "Number" ? rawValue : sanitizeXmlText(rawValue);
  return `<Cell${style}${merge}><Data ss:Type="${type}">${value}</Data></Cell>`;
}

function rowXml(row: Row, columnWidths: number[]) {
  if (!row || row.length === 0) return "<Row/>";
  const height = estimateRowHeight(row, columnWidths);
  return `<Row ss:AutoFitHeight="0" ss:Height="${height}">${row.map(cellXml).join("")}</Row>`;
}

function worksheetXml(sheet: Sheet) {
  const computedColumns = computeSheetColumns(sheet);
  const columns = computedColumns.map(columnXml).join("");
  const rows = sheet.rows.map((row) => rowXml(row, computedColumns)).join("\n");
  return `<Worksheet ss:Name="${sanitizeXmlText(sheet.name)}"><Table>${columns}${rows}</Table><WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><Selected/><ProtectObjects>False</ProtectObjects><ProtectScenarios>False</ProtectScenarios><FreezePanes/><FrozenNoSplit/><SplitHorizontal>3</SplitHorizontal><TopRowBottomPane>3</TopRowBottomPane><ActivePane>2</ActivePane><Panes><Pane><Number>3</Number></Pane><Pane><Number>2</Number><ActiveRow>4</ActiveRow></Pane></Panes></WorksheetOptions></Worksheet>`;
}

function workbookXml(sheets: Sheet[]) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
  <Author>Commercial Co-Pilot</Author>
  <Company>Commercial Co-Pilot</Company>
 </DocumentProperties>
 <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
  <ProtectStructure>False</ProtectStructure>
  <ProtectWindows>False</ProtectWindows>
 </ExcelWorkbook>
 <Styles>
  <Style ss:ID="Default" ss:Name="Normal">
   <Alignment ss:Vertical="Center"/>
   <Borders/>
   <Font ss:FontName="Calibri" ss:Size="10" ss:Color="#111827"/>
   <Interior/>
   <NumberFormat/>
   <Protection/>
  </Style>
  <Style ss:ID="title"><Font ss:Bold="1" ss:Size="16" ss:Color="#111827"/><Alignment ss:Vertical="Center" ss:WrapText="1"/></Style>
  <Style ss:ID="subtitle"><Font ss:Size="10" ss:Color="#475569"/><Alignment ss:Vertical="Center" ss:WrapText="1"/></Style>
  <Style ss:ID="section"><Font ss:Bold="1" ss:Size="11" ss:Color="#111827"/><Interior ss:Color="#F3F4F6" ss:Pattern="Solid"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E5E7EB"/></Borders></Style>
  <Style ss:ID="header"><Font ss:Bold="1" ss:Size="10" ss:Color="#111827"/><Interior ss:Color="#EEF2F7" ss:Pattern="Solid"/><Alignment ss:Vertical="Center" ss:WrapText="1"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#D1D5DB"/></Borders></Style>
  <Style ss:ID="label"><Font ss:Bold="1" ss:Size="10" ss:Color="#475569"/><Alignment ss:Vertical="Center"/></Style>
  <Style ss:ID="value"><Font ss:Size="10" ss:Color="#111827"/><Alignment ss:Vertical="Center" ss:WrapText="1"/></Style>
  <Style ss:ID="body"><Font ss:Size="10" ss:Color="#111827"/><Alignment ss:Vertical="Top" ss:WrapText="1"/></Style>
  <Style ss:ID="currency"><Font ss:Size="10" ss:Color="#111827"/><NumberFormat ss:Format="\u00a3#,##0.00"/><Alignment ss:Horizontal="Right" ss:Vertical="Center"/></Style>
  <Style ss:ID="totalLabel"><Font ss:Bold="1" ss:Size="10" ss:Color="#111827"/><Interior ss:Color="#F9FAFB" ss:Pattern="Solid"/></Style>
  <Style ss:ID="total"><Font ss:Bold="1" ss:Size="11" ss:Color="#111827"/><NumberFormat ss:Format="\u00a3#,##0.00"/><Interior ss:Color="#F9FAFB" ss:Pattern="Solid"/><Alignment ss:Horizontal="Right" ss:Vertical="Center"/></Style>
  <Style ss:ID="group"><Font ss:Bold="1" ss:Size="10" ss:Color="#111827"/><Interior ss:Color="#F8FAFC" ss:Pattern="Solid"/></Style>
  <Style ss:ID="subgroup"><Font ss:Bold="1" ss:Italic="1" ss:Size="10" ss:Color="#334155"/></Style>
  <Style ss:ID="task"><Font ss:Italic="1" ss:Size="10" ss:Color="#475569"/><Alignment ss:WrapText="1"/></Style>
  <Style ss:ID="item"><Font ss:Size="10" ss:Color="#111827"/><Alignment ss:WrapText="1"/></Style>
  <Style ss:ID="cell"><Font ss:Size="10" ss:Color="#111827"/></Style>
  <Style ss:ID="cellWrap"><Font ss:Size="10" ss:Color="#111827"/><Alignment ss:WrapText="1" ss:Vertical="Top"/></Style>
  <Style ss:ID="muted"><Font ss:Italic="1" ss:Size="10" ss:Color="#64748B"/></Style>
 </Styles>
 ${sheets.map(worksheetXml).join("\n")}
</Workbook>`;
}

export function buildCeWorkbookXml(payload: WorkbookPayload) {
  const staff = payload.resources.filter((x) => x.category === "staff" || (x.category === "labour" && looksLikeStaff(x.item_name, x.notes)));
  const labour = payload.resources.filter((x) => x.category === "labour" && !looksLikeStaff(x.item_name, x.notes));
  const plant = payload.resources.filter((x) => x.category === "plant" || x.category === "equipment");
  const material = payload.resources.filter((x) => x.category === "material" || x.category === "materials");
  const charges = payload.resources.filter((x) => x.category === "subcontract" || x.category === "charge" || x.category === "charges");

  const sheets: Sheet[] = [
    buildSummarySheet(payload),
    buildBasisSheet(payload),
    buildSheetFromLines("1.1 People (Staff)", staff, "Role"),
    buildSheetFromLines("1.2 People (Labour)", labour, "Role"),
    buildSheetFromLines("2.0 Equipment", plant, "Plant item"),
    buildSheetFromLines("3.0 Plant & Materials", material, "Material"),
    buildSheetFromLines("4.0 Charges", charges, "Charge / subcontract"),
    buildPrelimsSheet(payload),
    buildTimeRiskSheet(payload),
    buildAuditSheet(payload),
  ];

  return workbookXml(sheets);
}

export function downloadCeWorkbook(payload: WorkbookPayload) {
  const xml = buildCeWorkbookXml(payload);
  const blob = new Blob(["\ufeff", xml], { type: "application/vnd.ms-excel;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const slug = (payload.meta.title || "ce-pack")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "") || "ce-pack";
  a.href = url;
  a.download = `${slug}-pack.xls`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
