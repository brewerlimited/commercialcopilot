import { LegalBlock, LegalPage } from "@/components/marketing";

export default function PrivacyPage() {
  return (
    <LegalPage
      title="Privacy Policy"
      intro="This page explains, in straightforward terms, how project and account data is handled within the platform."
    >
      <LegalBlock title="What we collect">
        <p>We may collect account details, uploaded documents, event drafting inputs, valuation inputs, evidence references and usage information required to operate the software.</p>
      </LegalBlock>

      <LegalBlock title="Why we collect it">
        <p>Data is used to provide the drafting workflow, maintain user accounts, support product performance, improve stability and help deliver outputs requested by the user.</p>
      </LegalBlock>

      <LegalBlock title="Confidentiality">
        <p>Project and commercial information should be treated as confidential within the platform environment. Users should still exercise appropriate judgement regarding what information is uploaded and stored.</p>
      </LegalBlock>

      <LegalBlock title="Data retention">
        <p>Account and project data may be retained for as long as reasonably necessary to provide the service, support users, maintain records and comply with legal obligations.</p>
      </LegalBlock>

      <LegalBlock title="User rights">
        <p>Users may request access to or deletion of personal account data where applicable, subject to legal, contractual and technical limitations.</p>
      </LegalBlock>
    </LegalPage>
  );
}
