import { Card, PageWrap, PrimaryButton, SectionTitle, SiteShell, m } from "@/components/marketing";

export default function ContactPage() {
  return (
    <SiteShell>
      <PageWrap>
        <SectionTitle
          title="Book a demo"
          text="Use this page as the immediate CTA destination. You can replace the placeholder contact details with a Calendly link, form embed or direct email later."
        />

        <div style={{ display: "grid", gridTemplateColumns: "1fr 0.9fr", gap: 24 }}>
          <Card title="Recommended next step" text="For now, the cleanest flow is to route demo enquiries to a single email address or booking link.">
            <div style={{ display: "grid", gap: 10, color: m.sub, fontSize: 15, lineHeight: 1.65 }}>
              <div><strong style={{ color: m.black }}>Email:</strong> hello@commercialcopilot.co.uk</div>
              <div><strong style={{ color: m.black }}>Suggested action:</strong> replace this with your preferred demo booking method.</div>
              <div><strong style={{ color: m.black }}>Expected use:</strong> product demo, pilot access and pricing discussion.</div>
            </div>
          </Card>
          <Card title="Quick CTA" text="Once you have your booking flow ready, keep this page simple and conversion-focused.">
            <PrimaryButton href="mailto:hello@commercialcopilot.co.uk">Email to book demo</PrimaryButton>
          </Card>
        </div>
      </PageWrap>
    </SiteShell>
  );
}
