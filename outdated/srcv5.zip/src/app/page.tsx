import { Card, PageWrap, PrimaryButton, SecondaryButton, SectionTitle, SiteShell, m } from "@/components/marketing";

const painPoints = [
  "Weak entitlement narrative",
  "Unclear cause and effect",
  "Missing clause references",
  "Inconsistent cost build-up",
  "Poor evidence structure",
];

const outputs = [
  {
    title: "Basis of Change",
    text: "Structured cause → effect → mechanism logic that reads like a commercial submission rather than rough site notes.",
  },
  {
    title: "Cost build-up",
    text: "Deterministic labour, plant, material, prelim and fee structure that stays controlled and auditable.",
  },
  {
    title: "Time impact narrative",
    text: "Clear explanation of delay and sequencing effect where the event has programme consequences.",
  },
  {
    title: "Evidence structure",
    text: "Checklist-led capture of instructions, records, photos, programme support and cost evidence.",
  },
  {
    title: "Commercial defence notes",
    text: "Anticipate likely contractor pushback before submission so the pack is stronger on first issue.",
  },
  {
    title: "Professional export pack",
    text: "One Word document, one Excel workbook and a ready-to-send submission email draft.",
  },
];

const proof = [
  '"This structures CEs better than most consultants."',
  '"Saves hours every week."',
  '"Improves clarity of entitlement arguments."',
];

export default function HomePage() {
  return (
    <SiteShell>
      <PageWrap>
        <section
          style={{
            display: "grid",
            gridTemplateColumns: "minmax(0, 1.15fr) minmax(360px, 0.85fr)",
            gap: 28,
            alignItems: "stretch",
          }}
        >
          <div
            style={{
              background: m.card,
              border: `1px solid ${m.border}`,
              borderRadius: 28,
              padding: 30,
              display: "grid",
              alignContent: "space-between",
              gap: 24,
            }}
          >
            <div style={{ display: "grid", gap: 14 }}>
              <div style={{ fontSize: 14, fontWeight: 800, color: m.sub }}>Commercial Co-Pilot</div>
              <h1
                style={{
                  margin: 0,
                  fontSize: 58,
                  lineHeight: 0.98,
                  letterSpacing: -2,
                  fontWeight: 900,
                  color: m.black,
                  maxWidth: 720,
                }}
              >
                Produce clause-correct CEs in minutes.
              </h1>
              <p style={{ margin: 0, fontSize: 19, lineHeight: 1.65, color: m.sub, maxWidth: 720 }}>
                Built for NEC & JCT subcontractors. Structured Basis of Change, deterministic cost build-up and submission-ready outputs.
              </p>
            </div>

            <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
              <PrimaryButton href="/contact">Book Demo</PrimaryButton>
              <SecondaryButton href="/pricing">View Sample Output</SecondaryButton>
            </div>
          </div>

          <div
            style={{
              background: m.card,
              border: `1px solid ${m.border}`,
              borderRadius: 28,
              padding: 24,
              display: "grid",
              gap: 14,
            }}
          >
            <div style={{ fontSize: 16, fontWeight: 800, color: m.black }}>Demo overview</div>
            <div
              style={{
                minHeight: 360,
                borderRadius: 20,
                background: "linear-gradient(180deg, #f8fafc 0%, #eef2f7 100%)",
                border: `1px solid ${m.border}`,
                display: "grid",
                placeItems: "center",
                padding: 24,
                textAlign: "center",
              }}
            >
              <div style={{ display: "grid", gap: 14, maxWidth: 420 }}>
                <div style={{ fontSize: 18, fontWeight: 800, color: m.black }}>Demo video placeholder</div>
                <div style={{ fontSize: 15, lineHeight: 1.65, color: m.sub }}>
                  Show a 60–120 second walkthrough covering event setup, basis entry, resource build-up, review stage and final output preview.
                </div>
                <div style={{ fontSize: 14, color: m.muted }}>Include a brief preview of the final Word and Excel pack to build trust quickly.</div>
              </div>
            </div>
          </div>
        </section>

        <section style={{ paddingTop: 72, display: "grid", gap: 24 }}>
          <SectionTitle
            title="Most CEs fail because they are poorly structured"
            text="Weak drafting creates avoidable pushback, under-recovery and delay in agreement. The issue is usually structure, not lack of effort."
          />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 24, alignItems: "start" }}>
            <Card title="Common failure points">
              <ul style={{ margin: 0, paddingLeft: 20, display: "grid", gap: 10, color: m.sub, fontSize: 15, lineHeight: 1.6 }}>
                {painPoints.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </Card>
            <Card title="Commercial effect" text="Leads to rejected variations, delayed agreement and lost margin.">
              <div style={{ paddingTop: 6 }}>
                <SecondaryButton href="/contact">See how it works</SecondaryButton>
              </div>
            </Card>
          </div>
        </section>

        <section style={{ paddingTop: 72, display: "grid", gap: 24 }}>
          <SectionTitle title="How it works" text="A guided commercial workflow, not a blank document." />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 20 }}>
            <Card title="01 — Describe the event" text="Structured Basis of Change guidance keeps the factual narrative tight and commercially usable." />
            <Card title="02 — Add cost and time impact" text="Build labour, plant, material, prelim and fee totals in a deterministic format that stays auditable." />
            <Card title="03 — Generate submission-ready pack" text="Produce Word narrative, Excel build-up and commercial defence notes ready for review and issue." />
          </div>
          <div>
            <SecondaryButton href="/contact">Watch full demo</SecondaryButton>
          </div>
        </section>

        <section style={{ paddingTop: 72, display: "grid", gap: 24 }}>
          <SectionTitle title="What the platform produces" text="Every section is designed to strengthen the commercial position, not just make the document look polished." />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 20 }}>
            {outputs.map((item) => (
              <Card key={item.title} title={item.title} text={item.text} />
            ))}
          </div>
          <div>
            <SecondaryButton href="/pricing">View example output</SecondaryButton>
          </div>
        </section>

        <section style={{ paddingTop: 72, display: "grid", gap: 24 }}>
          <SectionTitle title="One successful CE can cover a year of subscription" text="This is not about replacing QS judgement. It is about improving quality, speed and commercial consistency often enough that the software pays for itself quickly." />
          <div style={{ display: "grid", gridTemplateColumns: "1.1fr 0.9fr", gap: 24 }}>
            <Card title="Illustrative recovery uplift">
              <div style={{ display: "grid", gap: 12, color: m.sub, fontSize: 15, lineHeight: 1.65 }}>
                <div>If average CE value = <strong style={{ color: m.black }}>£8,000</strong></div>
                <div>Improving recovery by just 5% = <strong style={{ color: m.black }}>£400</strong></div>
                <div>Across 20 CEs per year = <strong style={{ color: m.black }}>£8,000 additional recovery potential</strong></div>
              </div>
            </Card>
            <Card title="Commercial reality" text="For subcontractors handling regular change, one avoided under-recovery or one stronger submission can justify the platform quickly.">
              <div style={{ paddingTop: 6 }}>
                <SecondaryButton href="/contact">Estimate your ROI</SecondaryButton>
              </div>
            </Card>
          </div>
        </section>

        <section style={{ paddingTop: 72, display: "grid", gap: 24 }}>
          <SectionTitle title="Early feedback" text="Keep this light initially. Two or three strong quotes are enough to add credibility without clutter." />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 20 }}>
            {proof.map((quote) => (
              <Card key={quote} title="QS feedback" text={quote} />
            ))}
          </div>
        </section>

        <section style={{ paddingTop: 72 }}>
          <div
            style={{
              background: m.card,
              border: `1px solid ${m.border}`,
              borderRadius: 28,
              padding: 30,
              display: "grid",
              gap: 18,
              textAlign: "center",
            }}
          >
            <div style={{ fontSize: 38, lineHeight: 1.08, letterSpacing: -1, fontWeight: 900, color: m.black }}>
              Produce stronger Compensation Events with less effort.
            </div>
            <div style={{ fontSize: 18, lineHeight: 1.65, color: m.sub, maxWidth: 760, margin: "0 auto" }}>
              Book a demo to see how the workflow, costing and submission structure fit together in one commercial platform.
            </div>
            <div style={{ display: "flex", justifyContent: "center", gap: 14, flexWrap: "wrap" }}>
              <PrimaryButton href="/contact">Book Demo</PrimaryButton>
              <SecondaryButton href="/pricing">View Sample Output</SecondaryButton>
            </div>
          </div>
        </section>
      </PageWrap>
    </SiteShell>
  );
}
