import { Card, PageWrap, PrimaryButton, SecondaryButton, SectionTitle, SiteShell, m } from "@/components/marketing";

const plans = [
  {
    name: "Starter",
    price: "From £600 / month",
    text: "For subcontractors who want a guided CE workflow with deterministic costing and submission-ready structure.",
    items: [
      "Structured Basis, Evidence, Resources, Prelims + Fee and Review workflow",
      "Deterministic cost build-up",
      "Commercial defence notes in the pack structure",
      "Word + Excel + submission email output model",
      "Initial support for onboarding and early feedback",
    ],
  },
  {
    name: "Professional",
    price: "Custom",
    text: "For heavier users needing more credits, more frequent change and a stronger commercial process.",
    items: [
      "Higher CE credit allocation",
      "Priority support",
      "Refined output structure",
      "Future template and contract expansion",
      "Best suited to active civils and groundworks teams",
    ],
  },
  {
    name: "Enterprise",
    price: "Talk to us",
    text: "For larger teams looking at rollout, standardisation and deeper commercial control.",
    items: [
      "Team rollout planning",
      "Custom onboarding",
      "Process alignment",
      "Branded outputs later",
      "Roadmap input",
    ],
  },
];

export default function PricingPage() {
  return (
    <SiteShell>
      <PageWrap>
        <SectionTitle
          title="Pricing"
          text="Positioned for subcontractors who value stronger CE structure, faster drafting and better commercial consistency."
        />

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 20 }}>
          {plans.map((plan) => (
            <Card key={plan.name} title={plan.name}>
              <div style={{ fontSize: 28, lineHeight: 1, fontWeight: 900, letterSpacing: -0.8, color: m.black }}>{plan.price}</div>
              <div style={{ fontSize: 15, lineHeight: 1.65, color: m.sub }}>{plan.text}</div>
              <ul style={{ margin: 0, paddingLeft: 18, display: "grid", gap: 10, color: m.sub, fontSize: 15, lineHeight: 1.6 }}>
                {plan.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
                <PrimaryButton href="/contact">Book Demo</PrimaryButton>
                <SecondaryButton href="/login">Login</SecondaryButton>
              </div>
            </Card>
          ))}
        </div>

        <section style={{ paddingTop: 56 }}>
          <Card title="Notes" text="The final packaging model is one Word document, one Excel workbook and one submission email draft. Credit and plan mechanics can be tuned as the product moves from pilot to live charging." />
        </section>
      </PageWrap>
    </SiteShell>
  );
}
