import { LegalBlock, LegalPage } from "@/components/marketing";

export default function TermsPage() {
  return (
    <LegalPage
      title="Terms and Conditions"
      intro="A clean public-facing terms page for early commercial use. Final legal review can tighten this later."
    >
      <LegalBlock title="Use of the platform">
        <p>Commercial Co-Pilot is provided as a software platform to assist users in structuring Compensation Event and variation submissions.</p>
        <p>The platform is intended to support commercial drafting workflows. It does not replace user judgement, contract review obligations or project-specific commercial responsibility.</p>
      </LegalBlock>

      <LegalBlock title="User responsibility">
        <p>Users remain responsible for checking all factual content, contractual position, commercial assumptions, supporting evidence and final submission wording before issue.</p>
        <p>Any submission generated or supported through the platform should be reviewed internally by the user before being sent externally.</p>
      </LegalBlock>

      <LegalBlock title="Accounts and access">
        <p>Users are responsible for maintaining control of account access and any credentials linked to the platform.</p>
        <p>Access may be suspended or withdrawn where misuse, non-payment or abuse of the service is identified.</p>
      </LegalBlock>

      <LegalBlock title="Fees and billing">
        <p>Paid access, credits and plan terms may be subject to separate pricing and billing terms shown at the point of subscription or onboarding.</p>
        <p>Unless otherwise agreed in writing, fees are non-refundable once service access or usage has commenced.</p>
      </LegalBlock>

      <LegalBlock title="Intellectual property">
        <p>The platform, workflow structure, interface design and related software remain the intellectual property of Commercial Co-Pilot unless expressly agreed otherwise.</p>
        <p>Users retain responsibility for and ownership of their own uploaded project data and submission content, subject to the platform terms and privacy policy.</p>
      </LegalBlock>
    </LegalPage>
  );
}
