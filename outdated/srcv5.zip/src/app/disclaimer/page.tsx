import { LegalBlock, LegalPage } from "@/components/marketing";

export default function DisclaimerPage() {
  return (
    <LegalPage
      title="Disclaimer"
      intro="Important clarification on how the platform should be used in practice."
    >
      <LegalBlock title="Commercial assistance, not final advice">
        <p>The platform is designed to assist users in structuring commercial submissions. It is not legal advice, contract certification, delay analysis certification or professional advice of any regulated kind.</p>
      </LegalBlock>

      <LegalBlock title="User review remains essential">
        <p>All output should be checked by the user before issue. This includes contractual position, factual narrative, evidence completeness, valuation assumptions and any clause references included in the final pack.</p>
      </LegalBlock>

      <LegalBlock title="Deterministic costing principle">
        <p>The product is designed so that costing remains user-controlled and deterministic. Users remain responsible for the correctness of rates, quantities, prelim allowances, fee settings and supporting records.</p>
      </LegalBlock>

      <LegalBlock title="Project-specific limitations">
        <p>No generic software output can account for every project-specific amendment, bespoke clause set, evidential nuance or commercial risk. Final responsibility remains with the submitting party.</p>
      </LegalBlock>
    </LegalPage>
  );
}
