export type ExportEventMeta = {
  title: string;
  contractType?: string | null;
  contractSource?: string | null;
  delayDays?: number;
  generatedAt?: string;
  instructionRef?: string | null;
  ceRef?: string | null;
  programmeRef?: string | null;
};

export type ExportBasis = {
  happened_summary?: string;
  cause_type?: string | null;
  cause_summary?: string;
  difference_from_plan?: string;
  mechanism_tags?: string[];
  mitigation_summary?: string;
  time_impact_toggle?: string;
};

export type ExportResourceLine = {
  category: string;
  item_name: string;
  unit: string;
  qty: number;
  hours?: number | null;
  rate: number;
  total: number;
  notes?: string | null;
  start_date?: string | null;
  end_date?: string | null;
  linked_event?: string | null;
};

export type ExportPrelimLine = {
  name: string;
  qty: number;
  unit: string;
  rate: number;
  notes?: string | null;
};

export type ExportValuation = {
  fee_percent: number;
  fee_basis: "defined_cost" | "defined_cost_plus_prelims";
  work_days_per_week?: number;
};

export type ExportReviewSettings = {
  include_basis?: boolean;
  include_entitlement?: boolean;
  include_time_impact?: boolean;
  include_evidence_register?: boolean;
  include_cost_summary?: boolean;
  include_prelims_fee?: boolean;
  include_risk_notes?: boolean;
  include_commercial_pushback?: boolean;
  include_excel?: boolean;
  include_pdf?: boolean;
  qualifications_notes?: string;
};

export type ExportFileCounts = {
  instructions: number;
  photos: number;
  site_records: number;
  programme: number;
  cost_support: number;
};

export type WorkbookPayload = {
  meta: ExportEventMeta;
  basis: ExportBasis;
  resources: ExportResourceLine[];
  prelims: ExportPrelimLine[];
  valuation: ExportValuation;
  review: ExportReviewSettings;
  fileCounts: ExportFileCounts;
  readiness: number;
  warnings: number;
  blockers: number;
};

type Cell = {
  value?: string | number;
  style?: string;
  mergeAcross?: number;
  type?: "String" | "Number";
};

type Row = Cell[];

type Sheet = {
  name: string;
  columns?: number[];
  rows: Row[];
};

type ColumnSizingRule = {
  min?: number;
  max?: number;
  padding?: number;
  fixed?: number;
};

const STAFF_KEYWORDS = [
  "project manager",
  "quantity surveyor",
  "commercial manager",
  "site manager",
  "site supervisor",
  "foreman",
  "engineer",
  "planner",
  "administrator",
  "admin",
  "qs",
  "pm",
];

function sanitizeXmlText(value: unknown) {
  return String(value ?? "")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u0084\u0086-\u009F]/g, "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function money(n: number) {
  const v = Number(n);
  return Number.isFinite(v) ? Number(v.toFixed(2)) : 0;
}

function displayDate(value?: string | null) {
  if (!value) return "";
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleDateString("en-GB");
}

function normaliseText(value?: string | null) {
  return (value ?? "").trim();
}

function byHierarchy(a: ExportResourceLine, b: ExportResourceLine) {
  return `${a.linked_event ?? ""}|${a.start_date ?? ""}|${a.notes ?? ""}|${a.item_name}`.localeCompare(
    `${b.linked_event ?? ""}|${b.start_date ?? ""}|${b.notes ?? ""}|${b.item_name}`
  );
}

function looksLikeStaff(itemName: string, notes?: string | null) {
  const text = `${itemName} ${notes ?? ""}`.toLowerCase();
  return STAFF_KEYWORDS.some((k) => text.includes(k));
}

function calcPrelimsTotal(prelims: ExportPrelimLine[]) {
  return prelims.reduce((sum, line) => sum + (Number(line.qty) || 0) * (Number(line.rate) || 0), 0);
}

function groupLabel(line: ExportResourceLine) {
  return {
    activity: normaliseText(line.linked_event) || "General activity",
    date: displayDate(line.start_date),
    task: normaliseText(line.notes) || "General task",
  };
}

function titleRows(title: string, subtitle: string, cols: number): Row[] {
  return [
    [{ value: title, style: "title", mergeAcross: cols - 1 }],
    [{ value: subtitle, style: "subtitle", mergeAcross: cols - 1 }],
    [],
  ];
}

function valueLength(value: unknown) {
  return String(value ?? "").replace(/\r?\n/g, " ").trim().length;
}

function calcContentWidth(values: unknown[], rule: ColumnSizingRule = {}) {
  if (typeof rule.fixed === "number") return rule.fixed;
  const padding = rule.padding ?? 2;
  const min = rule.min ?? 10;
  const max = rule.max ?? 28;
  const longest = values.reduce((best, value) => Math.max(best, valueLength(value)), 0);
  return Math.max(min, Math.min(max, longest + padding));
}

function buildColumnWidths(rows: Row[], rules: ColumnSizingRule[]) {
  const valuesByColumn: unknown[][] = rules.map(() => []);

  rows.forEach((row) => {
    let columnIndex = 0;
    row.forEach((cell) => {
      const span = (cell?.mergeAcross ?? 0) + 1;
      if (span === 1 && valuesByColumn[columnIndex]) {
        valuesByColumn[columnIndex].push(cell?.value ?? "");
      }
      columnIndex += span;
    });
  });

  return rules.map((rule, index) => calcContentWidth(valuesByColumn[index] || [], rule));
}

function shouldWrapCell(cell?: Cell) {
  return ["body", "cellWrap", "task", "title", "subtitle"].includes(cell?.style || "");
}

function estimateRowHeight(row: Row, columnWidths: number[]) {
  if (!row || row.length === 0) return null;

  let hasWrappedCell = false;
  let maxLines = 1;
  let columnIndex = 0;

  for (const cell of row) {
    const span = (cell?.mergeAcross ?? 0) + 1;
    const mergedWidth = columnWidths.slice(columnIndex, columnIndex + span).reduce((sum, width) => sum + width, 0);

    if (shouldWrapCell(cell)) {
      hasWrappedCell = true;
      const text = String(cell?.value ?? "");
      const explicitLines = text.split(/\r?\n/);
      const approxCharsPerLine = Math.max(12, Math.floor(mergedWidth * 0.95));
      const wrappedLines = explicitLines.reduce((sum, line) => {
        const len = Math.max(1, valueLength(line));
        return sum + Math.max(1, Math.ceil(len / approxCharsPerLine));
      }, 0);
      maxLines = Math.max(maxLines, wrappedLines);
    }

    columnIndex += span;
  }

  if (!hasWrappedCell) return null;

  const lineHeight = 15;
  const verticalPadding = 6;
  return Math.max(18, maxLines * lineHeight + verticalPadding);
}

function buildStructuredRows(lines: ExportResourceLine[], itemLabel: string): Row[] {
  const rows: Row[] = [];
  const sorted = [...lines].sort(byHierarchy);
  let lastActivity = "";
  let lastDate = "";
  let lastTask = "";

  for (const line of sorted) {
    const g = groupLabel(line);
    if (g.activity !== lastActivity) {
      rows.push([{ value: g.activity, style: "group", mergeAcross: 6 }]);
      lastActivity = g.activity;
      lastDate = "";
      lastTask = "";
    }
    if (g.date !== lastDate) {
      rows.push([{ value: `Date: ${g.date || "—"}`, style: "subgroup", mergeAcross: 6 }]);
      lastDate = g.date;
      lastTask = "";
    }
    if (g.task !== lastTask) {
      rows.push([{ value: `Task: ${g.task}`, style: "task", mergeAcross: 6 }]);
      lastTask = g.task;
    }

    rows.push([
      { value: line.item_name || itemLabel, style: "item" },
      { value: line.unit === "hour" ? (Number(line.hours) || Number(line.qty) || 0) : Number(line.qty) || 0, style: "cell", type: "Number" },
      { value: line.unit || "", style: "cell" },
      { value: money(Number(line.rate) || 0), style: "currency", type: "Number" },
      { value: money(Number(line.total) || 0), style: "currency", type: "Number" },
      { value: normaliseText(line.end_date) || "", style: "cell" },
      { value: normaliseText(line.notes) || "", style: "cellWrap" },
    ]);
  }

  if (rows.length === 0) {
    rows.push([{ value: "No lines entered.", style: "muted", mergeAcross: 6 }]);
  }

  return rows;
}

function buildSummarySheet(payload: WorkbookPayload): Sheet {
  const staff = payload.resources.filter((x) => x.category === "staff" || (x.category === "labour" && looksLikeStaff(x.item_name, x.notes)));
  const labour = payload.resources.filter((x) => x.category === "labour" && !looksLikeStaff(x.item_name, x.notes));
  const plant = payload.resources.filter((x) => x.category === "plant" || x.category === "equipment");
  const materials = payload.resources.filter((x) => x.category === "material" || x.category === "materials");
  const charges = payload.resources.filter((x) => x.category === "subcontract" || x.category === "charge" || x.category === "charges");
  const prelimsTotal = calcPrelimsTotal(payload.prelims);
  const definedCost = payload.resources.reduce((sum, x) => sum + (Number(x.total) || 0), 0);
  const feeBase = payload.valuation.fee_basis === "defined_cost_plus_prelims" ? definedCost + prelimsTotal : definedCost;
  const feeAmount = feeBase * ((Number(payload.valuation.fee_percent) || 0) / 100);
  const total = definedCost + prelimsTotal + feeAmount;

  const activityMap = new Map<string, number>();
  for (const line of payload.resources) {
    const activity = normaliseText(line.linked_event) || "General activity";
    activityMap.set(activity, (activityMap.get(activity) || 0) + (Number(line.total) || 0));
  }

  const rows: Row[] = [
    ...titleRows(payload.meta.title || "Compensation Event", "Commercial Co-Pilot — Summary", 5),
    [{ value: "Event", style: "label" }, { value: payload.meta.title || "—", style: "value", mergeAcross: 3 }],
    [{ value: "Generated", style: "label" }, { value: displayDate(payload.meta.generatedAt || new Date().toISOString()), style: "value" }, { value: "Contract", style: "label" }, { value: normaliseText(payload.meta.contractType)?.replaceAll("_", " ").toUpperCase() || "—", style: "value" }],
    [{ value: "Delay days", style: "label" }, { value: Number(payload.meta.delayDays) || 0, style: "value", type: "Number" }, { value: "Readiness", style: "label" }, { value: `${payload.readiness}%`, style: "value" }],
    [],
    [{ value: "Value summary", style: "section", mergeAcross: 4 }],
    [{ value: "Staff", style: "label" }, { value: money(staff.reduce((s, x) => s + (Number(x.total) || 0), 0)), style: "currency", type: "Number" }, { value: "Blockers", style: "label" }, { value: payload.blockers, style: "value", type: "Number" }],
    [{ value: "Labour", style: "label" }, { value: money(labour.reduce((s, x) => s + (Number(x.total) || 0), 0)), style: "currency", type: "Number" }, { value: "Warnings", style: "label" }, { value: payload.warnings, style: "value", type: "Number" }],
    [{ value: "Plant", style: "label" }, { value: money(plant.reduce((s, x) => s + (Number(x.total) || 0), 0)), style: "currency", type: "Number" }, { value: "Basis included", style: "label" }, { value: payload.review.include_basis ? "Yes" : "No", style: "value" }],
    [{ value: "Materials", style: "label" }, { value: money(materials.reduce((s, x) => s + (Number(x.total) || 0), 0)), style: "currency", type: "Number" }, { value: "Excel output", style: "label" }, { value: payload.review.include_excel ? "Yes" : "No", style: "value" }],
    [{ value: "Charges", style: "label" }, { value: money(charges.reduce((s, x) => s + (Number(x.total) || 0), 0)), style: "currency", type: "Number" }, { value: "PDF output", style: "label" }, { value: payload.review.include_pdf ? "Yes" : "No", style: "value" }],
    [{ value: "Prelims", style: "label" }, { value: money(prelimsTotal), style: "currency", type: "Number" }, { value: `Fee (${payload.valuation.fee_percent || 0}%)`, style: "label" }, { value: money(feeAmount), style: "currency", type: "Number" }],
    [{ value: "Total CE value", style: "totalLabel" }, { value: money(total), style: "total", type: "Number" }, { value: "Contract source", style: "label" }, { value: payload.meta.contractSource === "upload_contract" ? "Uploaded contract" : "Standard contract logic", style: "value" }],
    [],
    [{ value: "Activity summary", style: "section", mergeAcross: 4 }],
    [{ value: "Activity", style: "header" }, { value: "Value", style: "header" }, { value: "% of direct cost", style: "header" }, { value: "", style: "header" }],
  ];

  Array.from(activityMap.entries())
    .sort((a, b) => b[1] - a[1])
    .forEach(([activity, value]) => {
      rows.push([
        { value: activity, style: "cellWrap" },
        { value: money(value), style: "currency", type: "Number" },
        { value: definedCost > 0 ? `${((value / definedCost) * 100).toFixed(1)}%` : "0.0%", style: "value" },
        { value: "", style: "value" },
      ]);
    });

  return { name: "Summary", columns: [28, 14, 18, 22], rows };
}

function buildBasisSheet(payload: WorkbookPayload): Sheet {
  const b = payload.basis;
  const mech = (b.mechanism_tags || []).length ? (b.mechanism_tags || []).join(", ") : "—";
  const rows: Row[] = [
    ...titleRows(payload.meta.title || "Compensation Event", "Basis of Change", 4),
    [{ value: "What happened", style: "section", mergeAcross: 3 }],
    [{ value: b.happened_summary || "—", style: "body", mergeAcross: 3 }],
    [],
    [{ value: "Cause", style: "section", mergeAcross: 3 }],
    [{ value: b.cause_summary || "—", style: "body", mergeAcross: 3 }],
    [],
    [{ value: "Difference from plan", style: "section", mergeAcross: 3 }],
    [{ value: b.difference_from_plan || "—", style: "body", mergeAcross: 3 }],
    [],
    [{ value: "Mechanism tags", style: "section", mergeAcross: 3 }],
    [{ value: mech, style: "body", mergeAcross: 3 }],
    [],
    [{ value: "Mitigation", style: "section", mergeAcross: 3 }],
    [{ value: b.mitigation_summary || "—", style: "body", mergeAcross: 3 }],
    [],
    [{ value: "Time impact toggle", style: "label" }, { value: b.time_impact_toggle || "unsure", style: "value", mergeAcross: 2 }],
    [{ value: "Qualifications / notes", style: "label" }, { value: payload.review.qualifications_notes || "—", style: "body", mergeAcross: 2 }],
  ];
  return { name: "Basis of Change", columns: [22, 24, 24, 24], rows };
}

function buildSheetFromLines(name: string, lines: ExportResourceLine[], itemLabel: string): Sheet {
  const rows: Row[] = [
    ...titleRows(name, "Activity-led cost build-up", 7),
    [{ value: itemLabel, style: "header" }, { value: "Qty / Hrs", style: "header" }, { value: "Unit", style: "header" }, { value: "Rate", style: "header" }, { value: "Cost", style: "header" }, { value: "End / ref", style: "header" }, { value: "Notes", style: "header" }],
    ...buildStructuredRows(lines, itemLabel),
  ];

  const columns = buildColumnWidths(rows, [
    { min: 18, max: 32, padding: 3 },
    { fixed: 12 },
    { min: 10, max: 14, padding: 2 },
    { fixed: 12 },
    { fixed: 14 },
    { min: 12, max: 18, padding: 2 },
    { fixed: 40 },
  ]);

  return { name, columns, rows };
}

function buildPrelimsSheet(payload: WorkbookPayload): Sheet {
  const prelimsTotal = calcPrelimsTotal(payload.prelims);
  const definedCost = payload.resources.reduce((sum, x) => sum + (Number(x.total) || 0), 0);
  const feeBase = payload.valuation.fee_basis === "defined_cost_plus_prelims" ? definedCost + prelimsTotal : definedCost;
  const feeAmount = feeBase * ((Number(payload.valuation.fee_percent) || 0) / 100);
  const rows: Row[] = [
    ...titleRows("Prelims + Fee", "Time-related costs and fee application", 6),
    [{ value: "Item", style: "header" }, { value: "Qty", style: "header" }, { value: "Unit", style: "header" }, { value: "Rate", style: "header" }, { value: "Cost", style: "header" }, { value: "Notes", style: "header" }],
  ];

  if (payload.prelims.length === 0) {
    rows.push([{ value: "No prelim items entered.", style: "muted", mergeAcross: 5 }]);
  } else {
    for (const line of payload.prelims) {
      rows.push([
        { value: line.name || "Prelim item", style: "item" },
        { value: Number(line.qty) || 0, style: "cell", type: "Number" },
        { value: line.unit || "", style: "cell" },
        { value: money(Number(line.rate) || 0), style: "currency", type: "Number" },
        { value: money((Number(line.qty) || 0) * (Number(line.rate) || 0)), style: "currency", type: "Number" },
        { value: normaliseText(line.notes) || "", style: "cellWrap" },
      ]);
    }
  }

  rows.push(
    [],
    [{ value: "Summary", style: "section", mergeAcross: 5 }],
    [{ value: "Defined Cost", style: "label" }, { value: money(definedCost), style: "currency", type: "Number" }, { value: "", style: "label", mergeAcross: 4 }],
    [{ value: "Prelims total", style: "label" }, { value: money(prelimsTotal), style: "currency", type: "Number" }, { value: "", style: "label", mergeAcross: 4 }],
    [{ value: `Fee (${payload.valuation.fee_percent || 0}%)`, style: "label" }, { value: money(feeAmount), style: "currency", type: "Number" }, { value: payload.valuation.fee_basis === "defined_cost_plus_prelims" ? "Based on Defined Cost + Prelims" : "Based on Defined Cost only", style: "value", mergeAcross: 4 }],
    [{ value: "Total CE value", style: "totalLabel" }, { value: money(definedCost + prelimsTotal + feeAmount), style: "total", type: "Number" }, { value: "", style: "totalLabel", mergeAcross: 4 }],
  );

  const columns = buildColumnWidths(rows, [
    { min: 18, max: 34, padding: 3 },
    { fixed: 10 },
    { min: 10, max: 14, padding: 2 },
    { fixed: 12 },
    { fixed: 14 },
    { fixed: 40 },
  ]);

  return { name: "Prelims + Fee", columns, rows };
}

function buildTimeRiskSheet(payload: WorkbookPayload): Sheet {
  const rows: Row[] = [
    ...titleRows("Time Risk", "Programme and prolongation overview", 4),
    [{ value: "Delay days", style: "label" }, { value: Number(payload.meta.delayDays) || 0, style: "value", type: "Number" }, { value: "Time impact toggle", style: "label" }, { value: payload.basis.time_impact_toggle || "unsure", style: "value" }],
    [{ value: "Programme records", style: "label" }, { value: payload.fileCounts.programme, style: "value", type: "Number" }, { value: "Site records", style: "label" }, { value: payload.fileCounts.site_records, style: "value", type: "Number" }],
    [],
    [{ value: "Time impact narrative", style: "section", mergeAcross: 3 }],
    [{
      value: payload.basis.time_impact_toggle === "yes"
        ? `Current inputs indicate a time effect with ${Number(payload.meta.delayDays) || 0} day(s) recorded against the event. The final narrative can be developed further once the AI layer is connected.`
        : payload.basis.time_impact_toggle === "no"
          ? "Current inputs indicate no direct time impact has been recorded for this event."
          : "Time impact remains to be confirmed from the current inputs.",
      style: "body",
      mergeAcross: 3,
    }],
  ];
  return { name: "Time Risk", columns: [18, 14, 18, 30], rows };
}

function buildAuditSheet(payload: WorkbookPayload): Sheet {
  const totalEvidence = payload.fileCounts.instructions + payload.fileCounts.photos + payload.fileCounts.site_records + payload.fileCounts.programme + payload.fileCounts.cost_support;
  const rows: Row[] = [
    ...titleRows("Audit", "Generation metadata and checks", 4),
    [{ value: "Generated at", style: "label" }, { value: new Date(payload.meta.generatedAt || new Date().toISOString()).toLocaleString("en-GB"), style: "value", mergeAcross: 2 }],
    [{ value: "Readiness score", style: "label" }, { value: `${payload.readiness}%`, style: "value" }, { value: "Blockers", style: "label" }, { value: payload.blockers, style: "value", type: "Number" }],
    [{ value: "Warnings", style: "label" }, { value: payload.warnings, style: "value", type: "Number" }, { value: "Resource lines", style: "label" }, { value: payload.resources.length, style: "value", type: "Number" }],
    [{ value: "Evidence files", style: "label" }, { value: totalEvidence, style: "value", type: "Number" }, { value: "Prelim lines", style: "label" }, { value: payload.prelims.length, style: "value", type: "Number" }],
    [],
    [{ value: "Output selections", style: "section", mergeAcross: 3 }],
    [{ value: "Basis narrative", style: "label" }, { value: payload.review.include_basis ? "Included" : "Excluded", style: "value" }, { value: "Evidence register", style: "label" }, { value: payload.review.include_evidence_register ? "Included" : "Excluded", style: "value" }],
    [{ value: "Cost summary", style: "label" }, { value: payload.review.include_cost_summary ? "Included" : "Excluded", style: "value" }, { value: "Prelims + Fee", style: "label" }, { value: payload.review.include_prelims_fee ? "Included" : "Excluded", style: "value" }],
    [{ value: "Commercial pushback", style: "label" }, { value: payload.review.include_commercial_pushback ? "Included" : "Excluded", style: "value" }, { value: "PDF pack", style: "label" }, { value: payload.review.include_pdf ? "Included" : "Excluded", style: "value" }],
  ];
  return { name: "Audit", columns: [20, 16, 20, 16], rows };
}

function columnXml(width: number) {
  const ssWidth = Math.max(40, width) / 7;
  return `<Column ss:AutoFitWidth="0" ss:Width="${ssWidth.toFixed(2)}"/>`;
}

function cellXml(cell: Cell) {
  if (!cell || (cell.value === undefined && !cell.style && cell.mergeAcross === undefined)) return "<Cell/>";
  const style = cell.style ? ` ss:StyleID="${sanitizeXmlText(cell.style)}"` : "";
  const merge = typeof cell.mergeAcross === "number" && cell.mergeAcross > 0 ? ` ss:MergeAcross="${cell.mergeAcross}"` : "";
  const rawValue = cell.value ?? "";
  const type = cell.type || (typeof rawValue === "number" ? "Number" : "String");
  const value = type === "Number" ? rawValue : sanitizeXmlText(rawValue);
  return `<Cell${style}${merge}><Data ss:Type="${type}">${value}</Data></Cell>`;
}

function rowXml(row: Row, columnWidths: number[]) {
  if (!row || row.length === 0) return "<Row/>";
  const height = estimateRowHeight(row, columnWidths);
  const attrs = height ? ` ss:AutoFitHeight="0" ss:Height="${height}"` : "";
  return `<Row${attrs}>${row.map(cellXml).join("")}</Row>`;
}

function worksheetXml(sheet: Sheet) {
  const columnWidths = sheet.columns || [];
  const columns = columnWidths.map(columnXml).join("");
  const rows = sheet.rows.map((row) => rowXml(row, columnWidths)).join("\n");
  return `<Worksheet ss:Name="${sanitizeXmlText(sheet.name)}"><Table>${columns}${rows}</Table><WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><Selected/><ProtectObjects>False</ProtectObjects><ProtectScenarios>False</ProtectScenarios><FreezePanes/><FrozenNoSplit/><SplitHorizontal>3</SplitHorizontal><TopRowBottomPane>3</TopRowBottomPane><ActivePane>2</ActivePane><Panes><Pane><Number>3</Number></Pane><Pane><Number>2</Number><ActiveRow>4</ActiveRow></Pane></Panes></WorksheetOptions></Worksheet>`;
}

function workbookXml(sheets: Sheet[]) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
  <Author>Commercial Co-Pilot</Author>
  <Company>Commercial Co-Pilot</Company>
 </DocumentProperties>
 <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
  <ProtectStructure>False</ProtectStructure>
  <ProtectWindows>False</ProtectWindows>
 </ExcelWorkbook>
 <Styles>
  <Style ss:ID="Default" ss:Name="Normal">
   <Alignment ss:Vertical="Center"/>
   <Borders/>
   <Font ss:FontName="Calibri" ss:Size="10" ss:Color="#111827"/>
   <Interior/>
   <NumberFormat/>
   <Protection/>
  </Style>
  <Style ss:ID="title"><Font ss:Bold="1" ss:Size="16" ss:Color="#111827"/><Alignment ss:Vertical="Center" ss:WrapText="1"/></Style>
  <Style ss:ID="subtitle"><Font ss:Size="10" ss:Color="#475569"/><Alignment ss:Vertical="Center" ss:WrapText="1"/></Style>
  <Style ss:ID="section"><Font ss:Bold="1" ss:Size="11" ss:Color="#111827"/><Interior ss:Color="#F3F4F6" ss:Pattern="Solid"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E5E7EB"/></Borders></Style>
  <Style ss:ID="header"><Font ss:Bold="1" ss:Size="10" ss:Color="#111827"/><Interior ss:Color="#EEF2F7" ss:Pattern="Solid"/><Alignment ss:Vertical="Center" ss:WrapText="1"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#D1D5DB"/></Borders></Style>
  <Style ss:ID="label"><Font ss:Bold="1" ss:Size="10" ss:Color="#475569"/><Alignment ss:Vertical="Center"/></Style>
  <Style ss:ID="value"><Font ss:Size="10" ss:Color="#111827"/><Alignment ss:Vertical="Center"/></Style>
  <Style ss:ID="body"><Font ss:Size="10" ss:Color="#111827"/><Alignment ss:Vertical="Top" ss:WrapText="1"/></Style>
  <Style ss:ID="currency"><Font ss:Size="10" ss:Color="#111827"/><NumberFormat ss:Format="\u00a3#,##0.00"/><Alignment ss:Horizontal="Right" ss:Vertical="Center"/></Style>
  <Style ss:ID="totalLabel"><Font ss:Bold="1" ss:Size="10" ss:Color="#111827"/><Interior ss:Color="#F9FAFB" ss:Pattern="Solid"/></Style>
  <Style ss:ID="total"><Font ss:Bold="1" ss:Size="11" ss:Color="#111827"/><NumberFormat ss:Format="\u00a3#,##0.00"/><Interior ss:Color="#F9FAFB" ss:Pattern="Solid"/><Alignment ss:Horizontal="Right" ss:Vertical="Center"/></Style>
  <Style ss:ID="group"><Font ss:Bold="1" ss:Size="10" ss:Color="#111827"/><Interior ss:Color="#F8FAFC" ss:Pattern="Solid"/></Style>
  <Style ss:ID="subgroup"><Font ss:Bold="1" ss:Italic="1" ss:Size="10" ss:Color="#334155"/></Style>
  <Style ss:ID="task"><Font ss:Italic="1" ss:Size="10" ss:Color="#475569"/><Alignment ss:WrapText="1"/></Style>
  <Style ss:ID="item"><Font ss:Size="10" ss:Color="#111827"/><Alignment ss:Vertical="Center"/></Style>
  <Style ss:ID="cell"><Font ss:Size="10" ss:Color="#111827"/></Style>
  <Style ss:ID="cellWrap"><Font ss:Size="10" ss:Color="#111827"/><Alignment ss:WrapText="1" ss:Vertical="Top"/></Style>
  <Style ss:ID="muted"><Font ss:Italic="1" ss:Size="10" ss:Color="#64748B"/></Style>
 </Styles>
 ${sheets.map(worksheetXml).join("\n")}
</Workbook>`;
}

export function buildCeWorkbookXml(payload: WorkbookPayload) {
  const staff = payload.resources.filter((x) => x.category === "staff" || (x.category === "labour" && looksLikeStaff(x.item_name, x.notes)));
  const labour = payload.resources.filter((x) => x.category === "labour" && !looksLikeStaff(x.item_name, x.notes));
  const plant = payload.resources.filter((x) => x.category === "plant" || x.category === "equipment");
  const material = payload.resources.filter((x) => x.category === "material" || x.category === "materials");
  const charges = payload.resources.filter((x) => x.category === "subcontract" || x.category === "charge" || x.category === "charges");

  const sheets: Sheet[] = [
    buildSummarySheet(payload),
    buildBasisSheet(payload),
    buildSheetFromLines("1.1 People (Staff)", staff, "Role"),
    buildSheetFromLines("1.2 People (Labour)", labour, "Role"),
    buildSheetFromLines("2.0 Equipment", plant, "Plant item"),
    buildSheetFromLines("3.0 Plant & Materials", material, "Material"),
    buildSheetFromLines("4.0 Charges", charges, "Charge / subcontract"),
    buildPrelimsSheet(payload),
    buildTimeRiskSheet(payload),
    buildAuditSheet(payload),
  ];

  return workbookXml(sheets);
}

export function downloadCeWorkbook(payload: WorkbookPayload) {
  const xml = buildCeWorkbookXml(payload);
  const blob = new Blob(["\ufeff", xml], { type: "application/vnd.ms-excel;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const slug = (payload.meta.title || "ce-pack")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "") || "ce-pack";
  a.href = url;
  a.download = `${slug}-pack.xls`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
