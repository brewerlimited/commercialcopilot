"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import { getRequiredUser, isAuthErrorMessage } from "@/lib/security";
import { COMMON_IMPORT_LIBRARY, getResourceLibrary } from "@/lib/resourceLibrary";

type Category = "labour" | "plant" | "materials";

type RateCard = {
  id: string;
  user_id: string;
  category: Category;
  name: string;
  unit: string;
  rate: number;
  notes: string | null;
  active: boolean;
  project_name?: string | null;
  main_contractor?: string | null;
  created_at?: string;
  updated_at?: string;
};

type ProjectOption = {
  key: string;
  project_name: string;
  main_contractor: string;
  contract_type?: string | null;
};

const c = {
  bg: "#f6f7fb",
  card: "#ffffff",
  border: "rgba(15,23,42,0.08)",
  text: "#0f172a",
  sub: "#475569",
  black: "#111827",
  soft: "#f8fafc",
  activeBg: "rgba(17,24,39,0.08)",
  redBg: "#fef2f2",
  redBd: "#fecaca",
  redTx: "#991b1b",
};

const CATEGORY_TABS: { key: Category; label: string; hint: string }[] = [
  { key: "labour", label: "Labour", hint: "Operatives and supervision rates used in deterministic pricing." },
  { key: "plant", label: "Plant", hint: "Machines, attachments, wagons and tools." },
  { key: "materials", label: "Materials", hint: "Supply items used in resource build-ups." },
];

const UNITS = ["hour", "day", "week", "each", "m", "m2", "m3", "t", "kg", "l"] as const;

function money(n: number) {
  if (!isFinite(n)) return "£0.00";
  return new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n);
}

function cleanNumber(v: string) {
  const x = Number(String(v).replace(/[^\d.-]/g, ""));
  return isFinite(x) ? x : 0;
}

function contractLabel(v?: string | null) {
  if (!v) return "Contract not set";
  const tokens = String(v)
    .trim()
    .replace(/[_-]+/g, " ")
    .split(/\s+/)
    .filter(Boolean);

  const map: Record<string, string> = {
    nec: "NEC",
    nec3: "NEC3",
    nec4: "NEC4",
    ecs: "ECS",
    ecc: "ECC",
    psc: "PSC",
    jct: "JCT",
    sbc: "SBC",
    db: "D&B",
    dnb: "D&B",
  };

  return tokens
    .map((token) => {
      const lower = token.toLowerCase();
      if (map[lower]) return map[lower];
      return token.charAt(0).toUpperCase() + token.slice(1).toLowerCase();
    })
    .join(" ");
}

function projectDisplay(project?: string | null, contractor?: string | null) {
  const p = project?.trim();
  const mc = contractor?.trim();
  if (p && mc) return `${p} — ${mc}`;
  if (p) return p;
  if (mc) return mc;
  return "Select a project";
}

function Pill({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "8px 12px",
        borderRadius: 999,
        border: `1px solid ${active ? c.black : c.border}`,
        background: active ? c.black : "#fff",
        color: active ? "#fff" : c.black,
        fontWeight: 700,
        cursor: "pointer",
      }}
    >
      {label}
    </button>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label style={{ display: "grid", gap: 6 }}>
      <span style={{ fontSize: 12, fontWeight: 700, color: c.sub }}>{label}</span>
      {children}
    </label>
  );
}

export default function RateCardsPage() {
  const router = useRouter();

  const [tab, setTab] = useState<Category>("labour");
  const [rows, setRows] = useState<RateCard[]>([]);
  const [projects, setProjects] = useState<ProjectOption[]>([]);
  const [selectedProjectKey, setSelectedProjectKey] = useState("");
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [showInactive, setShowInactive] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<RateCard | null>(null);
  const [saving, setSaving] = useState(false);
  const [nameSuggestOpen, setNameSuggestOpen] = useState(false);
  const [nameSuggestIndex, setNameSuggestIndex] = useState(0);

  const [form, setForm] = useState<{
    category: Category;
    name: string;
    unit: string;
    rate: string;
    notes: string;
    active: boolean;
  }>({
    category: "labour",
    name: "",
    unit: "hour",
    rate: "0",
    notes: "",
    active: true,
  });

  const selectedProject = useMemo(
    () => projects.find((project) => project.key === selectedProjectKey) ?? null,
    [projects, selectedProjectKey]
  );

  function resetForm(category: Category) {
    setEditing(null);
    setForm({
      category,
      name: "",
      unit: category === "materials" ? "each" : "hour",
      rate: "0",
      notes: "",
      active: true,
    });
  }

  function openNew() {
    resetForm(tab);
    setOpen(true);
  }

  function openEdit(r: RateCard) {
    setEditing(r);
    setForm({
      category: r.category,
      name: r.name,
      unit: r.unit || "hour",
      rate: String(r.rate ?? 0),
      notes: r.notes ?? "",
      active: r.active ?? true,
    });
    setOpen(true);
  }

  async function load() {
    setErr(null);
    setLoading(true);
    const supabase = supabaseBrowser();

    try {
      const user = await getRequiredUser(supabase);
      const [{ data: rateData, error: rateError }, { data: eventData, error: eventError }] = await Promise.all([
        supabase
          .from("rate_cards")
          .select("id,user_id,category,name,unit,rate,notes,active,project_name,main_contractor,created_at,updated_at")
          .eq("user_id", user.id)
          .order("category", { ascending: true })
          .order("name", { ascending: true }),
        supabase
          .from("events")
          .select("project_name,main_contractor,contract_type,updated_at")
          .eq("user_id", user.id)
          .not("project_name", "is", null)
          .order("updated_at", { ascending: false }),
      ]);

      if (rateError) throw rateError;
      if (eventError) throw eventError;

      const nextRows = (rateData ?? []) as RateCard[];
      const seen = new Set<string>();
      const nextProjects: ProjectOption[] = [];

      for (const event of (eventData ?? []) as Array<{ project_name?: string | null; main_contractor?: string | null; contract_type?: string | null }>) {
        const project_name = String(event.project_name ?? "").trim();
        const main_contractor = String(event.main_contractor ?? "").trim();
        if (!project_name) continue;
        const key = `${project_name}__${main_contractor}`;
        if (seen.has(key)) continue;
        seen.add(key);
        nextProjects.push({ key, project_name, main_contractor, contract_type: event.contract_type ?? null });
      }

      setRows(nextRows);
      setProjects(nextProjects);
      setSelectedProjectKey((current) => {
        if (current && nextProjects.some((project) => project.key === current)) return current;
        return nextProjects[0]?.key ?? "";
      });
    } catch (e: any) {
      if (isAuthErrorMessage(e?.message)) {
        router.push("/login");
        return;
      }
      setErr(e?.message ?? "Failed to load rate cards");
      setRows([]);
      setProjects([]);
    }

    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    const search = q.trim().toLowerCase();
    return rows
      .filter((row) => row.category === tab)
      .filter((row) => {
        if (!selectedProject) return false;
        return (row.project_name ?? "") === selectedProject.project_name && (row.main_contractor ?? "") === selectedProject.main_contractor;
      })
      .filter((row) => (showInactive ? true : row.active))
      .filter((row) => (search ? (row.name ?? "").toLowerCase().includes(search) : true));
  }, [rows, selectedProject, showInactive, q, tab]);

  const activeCount = useMemo(
    () => filtered.filter((row) => row.active).length,
    [filtered]
  );

  const modalSuggestions = useMemo(() => {
    const query = form.name.trim().toLowerCase();
    const fromLibrary = getResourceLibrary(form.category).map((item) => ({
      name: item.name,
      unit: item.unit,
      source: "library" as const,
    }));
    const fromRows = rows
      .filter((row) => row.category === form.category)
      .map((row) => ({ name: row.name, unit: row.unit, source: "rate_card" as const }));
    const merged = [...fromRows, ...fromLibrary];
    const seen = new Set<string>();

    return merged
      .filter((item) => {
        const key = item.name.toLowerCase();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .filter((item) => (!query ? true : item.name.toLowerCase().includes(query)))
      .sort((a, b) => {
        const aStarts = query ? a.name.toLowerCase().startsWith(query) : false;
        const bStarts = query ? b.name.toLowerCase().startsWith(query) : false;
        if (aStarts !== bStarts) return aStarts ? -1 : 1;
        if (a.source !== b.source) return a.source === "rate_card" ? -1 : 1;
        return a.name.localeCompare(b.name);
      })
      .slice(0, query ? 10 : 8);
  }, [form.category, form.name, rows]);

  async function importCommonForTab() {
    setErr(null);
    setSaving(true);
    try {
      if (!selectedProject) {
        setErr("Select a project before editing rate cards.");
        return;
      }
      const supabase = supabaseBrowser();
      const user = await getRequiredUser(supabase);
      const existing = rows
        .filter((row) => row.category === tab)
        .filter((row) => (row.project_name ?? "") === selectedProject.project_name && (row.main_contractor ?? "") === selectedProject.main_contractor)
        .map((row) => row.name.trim().toLowerCase());
      const items = (COMMON_IMPORT_LIBRARY as Record<string, Array<{ name: string; unit: string }>>)[tab] || [];
      const payload = items
        .filter((item) => !existing.includes(item.name.trim().toLowerCase()))
        .map((item) => ({
          user_id: user.id,
          project_name: selectedProject.project_name,
          main_contractor: selectedProject.main_contractor,
          category: tab,
          name: item.name,
          unit: item.unit,
          rate: 0,
          notes: "Imported common starter item",
          active: true,
        }));

      if (payload.length > 0) {
        const { error } = await supabase.from("rate_cards").insert(payload);
        if (error) throw error;
      }

      await load();
    } catch (e: any) {
      setErr(e?.message ?? "Failed to import starter items");
    } finally {
      setSaving(false);
    }
  }

  async function saveModal() {
    setErr(null);

    const name = form.name.trim();
    if (!name) {
      setErr("Name is required.");
      return;
    }

    const rateNum = cleanNumber(form.rate);
    if (rateNum < 0) {
      setErr("Rate cannot be negative.");
      return;
    }

    setSaving(true);
    try {
      if (!selectedProject) {
        setErr("Select a project before saving rate cards.");
        return;
      }

      const supabase = supabaseBrowser();
      const user = await getRequiredUser(supabase);
      const payload: any = {
        project_name: selectedProject.project_name,
        main_contractor: selectedProject.main_contractor,
        category: form.category,
        name,
        unit: form.unit,
        rate: rateNum,
        notes: form.notes.trim() ? form.notes.trim() : null,
        active: form.active,
        updated_at: new Date().toISOString(),
      };

      if (!editing) {
        payload.user_id = user.id;
        const { error } = await supabase.from("rate_cards").insert(payload);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("rate_cards")
          .update(payload)
          .eq("id", editing.id)
          .eq("user_id", user.id);
        if (error) throw error;
      }

      setOpen(false);
      setEditing(null);
      await load();
    } catch (e: any) {
      setErr(e?.message ?? "Save failed");
    } finally {
      setSaving(false);
    }
  }

  async function setActive(row: RateCard, next: boolean) {
    setErr(null);
    const supabase = supabaseBrowser();
    const { error } = await supabase
      .from("rate_cards")
      .update({ active: next, updated_at: new Date().toISOString() })
      .eq("id", row.id)
      .eq("user_id", row.user_id);

    if (error) {
      setErr(error.message);
      return;
    }
    setRows((prev) => prev.map((item) => (item.id === row.id ? { ...item, active: next } : item)));
  }

  async function duplicate(row: RateCard) {
    setErr(null);
    try {
      const supabase = supabaseBrowser();
      const user = await getRequiredUser(supabase);
      const payload: any = {
        user_id: user.id,
        project_name: row.project_name ?? selectedProject?.project_name ?? null,
        main_contractor: row.main_contractor ?? selectedProject?.main_contractor ?? null,
        category: row.category,
        name: `${row.name} (copy)`,
        unit: row.unit,
        rate: row.rate,
        notes: row.notes,
        active: true,
        updated_at: new Date().toISOString(),
      };
      const { error } = await supabase.from("rate_cards").insert(payload);
      if (error) throw error;
      await load();
    } catch (e: any) {
      setErr(e?.message ?? "Duplicate failed");
    }
  }

  const Card = ({ title, hint, children }: { title: string; hint?: string; children: React.ReactNode }) => (
    <section
      style={{
        background: c.card,
        border: `1px solid ${c.border}`,
        borderRadius: 22,
        padding: 24,
        boxShadow: "0 1px 2px rgba(15,23,42,0.03)",
      }}
    >
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 10 }}>
        <div style={{ minWidth: 0 }}>
          <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: c.black }}>{title}</h2>
          {hint ? <div style={{ marginTop: 6, color: c.sub, fontWeight: 500, fontSize: 13, lineHeight: 1.55 }}>{hint}</div> : null}
        </div>
      </div>
      <div style={{ marginTop: 16 }}>{children}</div>
    </section>
  );

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <Card title="Rate cards" hint="Manage project-specific labour, plant and material rates used in deterministic pricing.">
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "minmax(320px, 1.2fr) minmax(240px, 0.8fr)",
            gap: 14,
            alignItems: "end",
          }}
        >
          <Field label="Project">
            <select
              value={selectedProjectKey}
              onChange={(e) => {
                setSelectedProjectKey(e.target.value);
                setQ("");
              }}
              style={{
                width: "100%",
                padding: "13px 14px",
                borderRadius: 14,
                border: `1px solid ${c.border}`,
                background: "#fff",
                fontWeight: 700,
                color: c.text,
                outline: "none",
              }}
            >
              {projects.length === 0 ? <option value="">No projects found</option> : null}
              {projects.map((project) => (
                <option key={project.key} value={project.key}>
                  {projectDisplay(project.project_name, project.main_contractor)}
                </option>
              ))}
            </select>
          </Field>

          <div
            style={{
              border: `1px solid ${c.border}`,
              borderRadius: 14,
              padding: "12px 14px",
              background: c.soft,
              minHeight: 52,
              display: "grid",
              alignContent: "center",
              gap: 4,
            }}
          >
            <div style={{ fontSize: 12, fontWeight: 700, color: c.sub }}>Contract</div>
            <div style={{ fontSize: 14, fontWeight: 700, color: c.black }}>{contractLabel(selectedProject?.contract_type)}</div>
          </div>
        </div>

        <div style={{ marginTop: 14, display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 12 }}>
          <div style={{ border: `1px solid ${c.border}`, borderRadius: 14, padding: "12px 14px", background: "#fff" }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: c.sub }}>Active project</div>
            <div style={{ marginTop: 4, fontSize: 14, fontWeight: 700, color: c.black }}>{projectDisplay(selectedProject?.project_name, selectedProject?.main_contractor)}</div>
          </div>
          <div style={{ border: `1px solid ${c.border}`, borderRadius: 14, padding: "12px 14px", background: "#fff" }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: c.sub }}>Category</div>
            <div style={{ marginTop: 4, fontSize: 14, fontWeight: 700, color: c.black }}>{CATEGORY_TABS.find((item) => item.key === tab)?.label}</div>
          </div>
          <div style={{ border: `1px solid ${c.border}`, borderRadius: 14, padding: "12px 14px", background: "#fff" }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: c.sub }}>Active items</div>
            <div style={{ marginTop: 4, fontSize: 14, fontWeight: 700, color: c.black }}>{activeCount}</div>
          </div>
        </div>

        <div style={{ marginTop: 18, display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          {CATEGORY_TABS.map((item) => (
            <Pill
              key={item.key}
              label={item.label}
              active={tab === item.key}
              onClick={() => {
                setTab(item.key);
                setQ("");
              }}
            />
          ))}

          <div style={{ flex: 1 }} />

          <button
            onClick={importCommonForTab}
            disabled={saving || !selectedProject}
            style={{
              padding: "10px 12px",
              borderRadius: 12,
              border: `1px solid ${c.border}`,
              background: "#fff",
              color: c.black,
              fontWeight: 700,
              cursor: saving || !selectedProject ? "not-allowed" : "pointer",
              whiteSpace: "nowrap",
              opacity: saving || !selectedProject ? 0.6 : 1,
            }}
          >
            Load common {CATEGORY_TABS.find((item) => item.key === tab)?.label?.toLowerCase()}
          </button>

          <button
            onClick={openNew}
            disabled={!selectedProject}
            style={{
              padding: "10px 12px",
              borderRadius: 12,
              border: `1px solid ${c.black}`,
              background: c.black,
              color: "#fff",
              fontWeight: 700,
              cursor: !selectedProject ? "not-allowed" : "pointer",
              whiteSpace: "nowrap",
              opacity: !selectedProject ? 0.6 : 1,
            }}
          >
            + Add {CATEGORY_TABS.find((item) => item.key === tab)?.label}
          </button>
        </div>

        <div style={{ marginTop: 14, display: "grid", gridTemplateColumns: "1fr auto", gap: 10 }}>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={`Search ${tab}…`}
            style={{
              width: "100%",
              padding: 12,
              borderRadius: 14,
              border: `1px solid ${c.border}`,
              outline: "none",
              background: "#fff",
              color: c.text,
              fontWeight: 700,
            }}
          />

          <button
            onClick={() => setShowInactive((prev) => !prev)}
            style={{
              padding: "10px 12px",
              borderRadius: 12,
              border: `1px solid ${c.border}`,
              background: "#fff",
              fontWeight: 700,
              cursor: "pointer",
              whiteSpace: "nowrap",
            }}
            title="Show or hide inactive items"
          >
            {showInactive ? "Hide inactive" : "Show inactive"}
          </button>
        </div>

        {err ? (
          <div
            style={{
              marginTop: 12,
              background: c.redBg,
              border: `1px solid ${c.redBd}`,
              color: c.redTx,
              padding: 12,
              borderRadius: 14,
              fontWeight: 700,
              fontSize: 13,
            }}
          >
            {err}
          </div>
        ) : null}

        {!selectedProject ? (
          <div
            style={{
              marginTop: 12,
              border: `1px solid ${c.border}`,
              borderRadius: 16,
              padding: 16,
              background: c.soft,
              color: c.sub,
              fontWeight: 700,
            }}
          >
            Create a CE with a project and main contractor first, then manage project-specific rates here.
          </div>
        ) : null}

        <div style={{ marginTop: 14, border: `1px solid ${c.border}`, borderRadius: 18, overflow: "hidden" }}>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "minmax(0,1.35fr) 110px 120px 240px",
              background: "rgba(17,24,39,0.04)",
              padding: "10px 12px",
              fontSize: 12,
              fontWeight: 700,
              color: c.sub,
              alignItems: "center",
            }}
          >
            <div>Name</div>
            <div>Unit</div>
            <div style={{ textAlign: "right" }}>Rate</div>
            <div style={{ textAlign: "right" }}>Actions</div>
          </div>

          {loading ? (
            <div style={{ padding: 14, color: c.sub, fontWeight: 700 }}>Loading…</div>
          ) : filtered.length === 0 ? (
            <div style={{ padding: 14, color: c.sub, fontWeight: 700 }}>
              {selectedProject ? `No items yet for this project. Click “Add” to create your first ${tab} rate.` : "Select a project to view rate cards."}
            </div>
          ) : (
            filtered.map((row) => (
              <div
                key={row.id}
                style={{
                  display: "grid",
                  gridTemplateColumns: "minmax(0,1.35fr) 110px 120px 240px",
                  padding: "14px 12px",
                  borderTop: `1px solid ${c.border}`,
                  alignItems: "center",
                  background: row.active ? "#fff" : "rgba(17,24,39,0.02)",
                }}
              >
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontWeight: 700, color: c.black, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }} title={row.name}>
                    {row.name}
                  </div>
                  {row.notes ? <div style={{ marginTop: 4, fontSize: 12, color: c.sub, fontWeight: 700 }}>{row.notes}</div> : null}
                  {!row.active ? <div style={{ marginTop: 6, fontSize: 12, color: c.sub, fontWeight: 700 }}>Inactive</div> : null}
                </div>

                <div style={{ color: c.sub, fontWeight: 700 }}>{row.unit}</div>
                <div style={{ textAlign: "right", fontWeight: 700, color: c.black }}>{money(Number(row.rate ?? 0))}</div>

                <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", flexWrap: "wrap" }}>
                  <button
                    onClick={() => openEdit(row)}
                    style={{ padding: "8px 10px", borderRadius: 12, border: `1px solid ${c.border}`, background: "#fff", fontWeight: 700, cursor: "pointer" }}
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => duplicate(row)}
                    style={{ padding: "8px 10px", borderRadius: 12, border: `1px solid ${c.border}`, background: "#fff", fontWeight: 700, cursor: "pointer" }}
                  >
                    Duplicate
                  </button>
                  <button
                    onClick={() => setActive(row, !row.active)}
                    style={{
                      padding: "8px 10px",
                      borderRadius: 12,
                      border: `1px solid ${c.border}`,
                      background: row.active ? "#fff" : c.black,
                      color: row.active ? c.black : "#fff",
                      fontWeight: 700,
                      cursor: "pointer",
                    }}
                  >
                    {row.active ? "Deactivate" : "Activate"}
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </Card>

      {open && (
        <div
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) setOpen(false);
          }}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15,23,42,0.35)",
            backdropFilter: "blur(4px)",
            zIndex: 60,
            display: "grid",
            placeItems: "center",
            padding: 18,
          }}
        >
          <div
            style={{
              width: "min(720px, 100%)",
              background: "#fff",
              border: `1px solid ${c.border}`,
              borderRadius: 22,
              padding: 18,
            }}
          >
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: 16, color: c.black }}>{editing ? "Edit rate card item" : "Add rate card item"}</div>
                <div style={{ marginTop: 6, color: c.sub, fontWeight: 700, fontSize: 13 }}>
                  {selectedProject ? `Project: ${projectDisplay(selectedProject.project_name, selectedProject.main_contractor)}` : "Select a project first."}
                </div>
              </div>

              <button
                onClick={() => setOpen(false)}
                style={{ padding: "10px 12px", borderRadius: 12, border: `1px solid ${c.border}`, background: "#fff", fontWeight: 700, cursor: "pointer" }}
              >
                Close
              </button>
            </div>

            {err ? (
              <div
                style={{
                  marginTop: 12,
                  background: c.redBg,
                  border: `1px solid ${c.redBd}`,
                  color: c.redTx,
                  padding: 12,
                  borderRadius: 14,
                  fontWeight: 700,
                  fontSize: 13,
                }}
              >
                {err}
              </div>
            ) : null}

            <div style={{ marginTop: 14, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <Field label="Category">
                <select
                  value={form.category}
                  onChange={(e) => setForm((prev) => ({ ...prev, category: e.target.value as Category }))}
                  style={{ width: "100%", padding: 12, borderRadius: 14, border: `1px solid ${c.border}`, background: "#fff", fontWeight: 700, color: c.text }}
                  disabled={!!editing}
                >
                  <option value="labour">Labour</option>
                  <option value="plant">Plant</option>
                  <option value="materials">Materials</option>
                </select>
              </Field>

              <Field label="Unit">
                <select
                  value={form.unit}
                  onChange={(e) => setForm((prev) => ({ ...prev, unit: e.target.value }))}
                  style={{ width: "100%", padding: 12, borderRadius: 14, border: `1px solid ${c.border}`, background: "#fff", fontWeight: 700, color: c.text }}
                >
                  {UNITS.map((unit) => (
                    <option key={unit} value={unit}>
                      {unit}
                    </option>
                  ))}
                </select>
              </Field>

              <Field label="Name">
                <div style={{ position: "relative" }}>
                  <input
                    value={form.name}
                    onFocus={() => setNameSuggestOpen(true)}
                    onChange={(e) => {
                      setForm((prev) => ({ ...prev, name: e.target.value }));
                      setNameSuggestOpen(true);
                      setNameSuggestIndex(0);
                    }}
                    onKeyDown={(e) => {
                      if (!nameSuggestOpen || modalSuggestions.length === 0) return;
                      if (e.key === "ArrowDown") {
                        e.preventDefault();
                        setNameSuggestIndex((prev) => (prev + 1) % modalSuggestions.length);
                      } else if (e.key === "ArrowUp") {
                        e.preventDefault();
                        setNameSuggestIndex((prev) => (prev - 1 + modalSuggestions.length) % modalSuggestions.length);
                      } else if (e.key === "Tab") {
                        e.preventDefault();
                        const picked = modalSuggestions[nameSuggestIndex] || modalSuggestions[0];
                        if (!picked) return;
                        setForm((prev) => ({ ...prev, name: picked.name, unit: picked.unit || prev.unit || "each" }));
                        setNameSuggestOpen(false);
                      }
                    }}
                    onBlur={() => setTimeout(() => setNameSuggestOpen(false), 120)}
                    placeholder={form.category === "labour" ? "e.g. Groundworker" : form.category === "plant" ? "e.g. 13T Excavator" : "e.g. C32/40 Concrete"}
                    style={{ width: "100%", padding: 12, borderRadius: 14, border: `1px solid ${c.border}`, background: "#fff", fontWeight: 700, color: c.text }}
                  />
                  {nameSuggestOpen && modalSuggestions.length > 0 ? (
                    <div
                      style={{
                        position: "absolute",
                        top: 52,
                        left: 0,
                        right: 0,
                        zIndex: 20,
                        background: "#fff",
                        border: `1px solid ${c.border}`,
                        borderRadius: 14,
                        boxShadow: "0 12px 30px rgba(0,0,0,0.08)",
                        overflow: "hidden",
                      }}
                    >
                      {modalSuggestions.map((item, idx) => (
                        <button
                          key={`${item.source}_${item.name}`}
                          type="button"
                          onMouseDown={(e) => {
                            e.preventDefault();
                            setForm((prev) => ({ ...prev, name: item.name, unit: item.unit || prev.unit || "each" }));
                            setNameSuggestOpen(false);
                          }}
                          onMouseEnter={() => setNameSuggestIndex(idx)}
                          style={{
                            width: "100%",
                            textAlign: "left",
                            padding: 12,
                            border: "none",
                            background: idx === nameSuggestIndex ? c.activeBg : "#fff",
                            cursor: "pointer",
                            display: "flex",
                            justifyContent: "space-between",
                            gap: 10,
                            fontWeight: 700,
                            color: c.black,
                          }}
                        >
                          <span>{item.name}</span>
                          <span style={{ fontSize: 12, color: c.sub }}>{item.unit} · {item.source === "rate_card" ? "saved" : "library"}</span>
                        </button>
                      ))}
                    </div>
                  ) : null}
                </div>
              </Field>

              <Field label="Rate (GBP)">
                <input
                  value={form.rate}
                  onChange={(e) => setForm((prev) => ({ ...prev, rate: e.target.value }))}
                  inputMode="decimal"
                  placeholder="e.g. 25.00"
                  style={{ width: "100%", padding: 12, borderRadius: 14, border: `1px solid ${c.border}`, background: "#fff", fontWeight: 700, color: c.text }}
                />
                <div style={{ marginTop: 6, fontSize: 12, color: c.sub, fontWeight: 700 }}>Preview: {money(cleanNumber(form.rate))} / {form.unit}</div>
              </Field>

              <div style={{ gridColumn: "1 / -1" }}>
                <Field label="Notes (optional)">
                  <textarea
                    value={form.notes}
                    onChange={(e) => setForm((prev) => ({ ...prev, notes: e.target.value }))}
                    rows={3}
                    placeholder="e.g. includes operator / standby minimum / internal reference"
                    style={{ width: "100%", padding: 12, borderRadius: 14, border: `1px solid ${c.border}`, background: "#fff", fontWeight: 700, color: c.text, resize: "vertical" }}
                  />
                </Field>
              </div>

              <div style={{ gridColumn: "1 / -1", display: "flex", alignItems: "center", gap: 10 }}>
                <input id="active" type="checkbox" checked={form.active} onChange={(e) => setForm((prev) => ({ ...prev, active: e.target.checked }))} />
                <label htmlFor="active" style={{ fontWeight: 700, color: c.black }}>
                  Active (shows in assisted typing)
                </label>
              </div>
            </div>

            <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 16 }}>
              <button
                onClick={() => setOpen(false)}
                style={{ padding: "10px 12px", borderRadius: 12, border: `1px solid ${c.border}`, background: "#fff", fontWeight: 700, cursor: "pointer" }}
              >
                Cancel
              </button>

              <button
                onClick={saveModal}
                disabled={saving}
                style={{
                  padding: "10px 12px",
                  borderRadius: 12,
                  border: `1px solid ${c.black}`,
                  background: c.black,
                  color: "#fff",
                  fontWeight: 700,
                  cursor: saving ? "not-allowed" : "pointer",
                  opacity: saving ? 0.7 : 1,
                }}
              >
                {saving ? "Saving…" : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
