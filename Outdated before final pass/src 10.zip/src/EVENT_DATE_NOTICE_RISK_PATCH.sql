-- Commercial Co-Pilot — Event Date / Notice Risk Persistence Patch
-- Run this in Supabase SQL Editor before testing the event date field.
-- Safe to run more than once.

alter table public.events
  add column if not exists event_date date,
  add column if not exists notice_period_days integer,
  add column if not exists notification_deadline date,
  add column if not exists payment_status text default 'not_applied',
  add column if not exists updated_at timestamptz default now();

-- Set a sensible default for existing NEC projects so notice deadlines calculate immediately.
update public.events
set notice_period_days = 56
where notice_period_days is null
  and lower(coalesce(contract_type, '')) like '%nec%';

-- Backfill deadlines for existing events where an event date has already been entered.
update public.events
set notification_deadline = event_date + notice_period_days
where event_date is not null
  and notice_period_days is not null;

-- Keep deadline in sync whenever event date or notice period changes.
create or replace function public.set_event_notification_deadline()
returns trigger
language plpgsql
as $$
begin
  if new.event_date is not null and new.notice_period_days is not null then
    new.notification_deadline := new.event_date + new.notice_period_days;
  else
    new.notification_deadline := null;
  end if;

  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists trg_set_event_notification_deadline on public.events;
create trigger trg_set_event_notification_deadline
before insert or update of event_date, notice_period_days
on public.events
for each row
execute function public.set_event_notification_deadline();

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'events_notice_period_days_non_negative'
  ) then
    alter table public.events
      add constraint events_notice_period_days_non_negative
      check (notice_period_days is null or notice_period_days >= 0) not valid;
  end if;

  if not exists (
    select 1 from pg_constraint where conname = 'events_payment_status_allowed'
  ) then
    alter table public.events
      add constraint events_payment_status_allowed
      check (payment_status is null or payment_status in ('not_applied', 'applied', 'assessed', 'paid', 'overdue')) not valid;
  end if;
end $$;

create index if not exists events_user_status_idx on public.events (user_id, status);
create index if not exists events_user_notification_deadline_idx on public.events (user_id, notification_deadline);
create index if not exists events_user_payment_status_idx on public.events (user_id, payment_status);
