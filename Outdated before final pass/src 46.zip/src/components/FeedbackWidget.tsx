
"use client";

import { useState } from "react";

export default function FeedbackWidget() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        style={{
          position: "fixed",
          bottom: "24px",
          right: "24px",
          zIndex: 9999,
          width: "52px",
          height: "52px",
          borderRadius: "999px",
          border: "1px solid #d1d5db",
          background: "#0f172a",
          color: "white",
          fontSize: "20px",
          cursor: "pointer",
          boxShadow: "0 10px 25px rgba(0,0,0,0.15)"
        }}
      >
        💬
      </button>

      {open && (
        <div
          style={{
            position: "fixed",
            bottom: "88px",
            right: "24px",
            zIndex: 9999,
            width: "360px",
            background: "white",
            border: "1px solid #e5e7eb",
            borderRadius: "16px",
            padding: "16px",
            boxShadow: "0 20px 40px rgba(0,0,0,0.15)"
          }}
        >
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"12px"}}>
            <h3 style={{margin:0,fontSize:"16px",fontWeight:600}}>Send feedback</h3>
            <button onClick={() => setOpen(false)} style={{border:"none",background:"transparent",cursor:"pointer"}}>✕</button>
          </div>

          <select style={{width:"100%",padding:"10px",marginBottom:"12px",borderRadius:"10px",border:"1px solid #d1d5db"}}>
            <option>Bug</option>
            <option>Feature idea</option>
            <option>Confusing</option>
            <option>General feedback</option>
          </select>

          <textarea
            placeholder="Tell us what happened..."
            style={{
              width:"100%",
              minHeight:"120px",
              padding:"12px",
              borderRadius:"10px",
              border:"1px solid #d1d5db",
              resize:"vertical",
              marginBottom:"12px"
            }}
          />

          <button
            style={{
              width:"100%",
              padding:"12px",
              borderRadius:"12px",
              border:"none",
              background:"#0f172a",
              color:"white",
              fontWeight:600,
              cursor:"pointer"
            }}
          >
            Submit feedback
          </button>
        </div>
      )}
    </>
  );
}
