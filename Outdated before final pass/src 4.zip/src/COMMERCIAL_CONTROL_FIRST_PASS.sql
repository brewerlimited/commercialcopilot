-- Commercial Co-Pilot — First-pass commercial control migration
-- Adds dashboard/status/time-bar/payment tracking fields used by the updated src.

alter table public.events
  add column if not exists event_date date,
  add column if not exists notice_period_days integer,
  add column if not exists notification_deadline date,
  add column if not exists payment_status text default 'not_applied',
  add column if not exists updated_at timestamptz default now();

-- Keep existing events usable immediately. NEC defaults to 8 weeks / 56 days.
update public.events
set notice_period_days = 56
where notice_period_days is null
  and lower(coalesce(contract_type, '')) like '%nec%';

-- Backfill calculated deadlines where an event date already exists.
update public.events
set notification_deadline = event_date + notice_period_days
where event_date is not null
  and notice_period_days is not null
  and notification_deadline is null;

-- Optional integrity checks. Wrapped so the script can be re-run safely.
do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'events_notice_period_days_non_negative'
  ) then
    alter table public.events
      add constraint events_notice_period_days_non_negative
      check (notice_period_days is null or notice_period_days >= 0) not valid;
  end if;

  if not exists (
    select 1 from pg_constraint where conname = 'events_payment_status_allowed'
  ) then
    alter table public.events
      add constraint events_payment_status_allowed
      check (payment_status is null or payment_status in ('not_applied', 'applied', 'assessed', 'paid', 'overdue')) not valid;
  end if;
end $$;

-- Useful indexes for the dashboard/action feed.
create index if not exists events_user_status_idx on public.events (user_id, status);
create index if not exists events_user_notification_deadline_idx on public.events (user_id, notification_deadline);
create index if not exists events_user_payment_status_idx on public.events (user_id, payment_status);
