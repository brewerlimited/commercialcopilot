-- Commercial Co-Pilot: Rebuttal Engine storage
-- Run this in Supabase SQL Editor before using Generate rebuttal.

create extension if not exists pgcrypto;

create table if not exists public.event_rebuttals (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  contractor_response text not null default '',
  rebuttal_subject text not null default '',
  rebuttal_body text not null default '',
  key_points jsonb not null default '[]'::jsonb,
  risk_note text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint event_rebuttals_event_unique unique (event_id)
);

alter table public.event_rebuttals enable row level security;

do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'event_rebuttals' and policyname = 'event_rebuttals_select_own'
  ) then
    create policy event_rebuttals_select_own
      on public.event_rebuttals
      for select
      using (auth.uid() = user_id);
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'event_rebuttals' and policyname = 'event_rebuttals_insert_own'
  ) then
    create policy event_rebuttals_insert_own
      on public.event_rebuttals
      for insert
      with check (auth.uid() = user_id);
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'event_rebuttals' and policyname = 'event_rebuttals_update_own'
  ) then
    create policy event_rebuttals_update_own
      on public.event_rebuttals
      for update
      using (auth.uid() = user_id)
      with check (auth.uid() = user_id);
  end if;
end $$;

create index if not exists event_rebuttals_event_id_idx on public.event_rebuttals(event_id);
create index if not exists event_rebuttals_user_id_idx on public.event_rebuttals(user_id);
