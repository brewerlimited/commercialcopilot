-- Optional Pass 1 migration for Commercial Co-Pilot payment tracking.
-- Safe to run in Supabase SQL editor; existing columns are left untouched.

alter table public.events
  add column if not exists submitted_date date,
  add column if not exists expected_payment_date date;

comment on column public.events.submitted_date is 'Internal dashboard tracking date used when a CE is marked as submitted.';
comment on column public.events.expected_payment_date is 'Internal dashboard tracking date used to derive overdue unpaid CEs.';
