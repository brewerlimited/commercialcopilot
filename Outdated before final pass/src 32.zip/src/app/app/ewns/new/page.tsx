"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";

const c = {
  card: "#ffffff",
  border: "#e5e7eb",
  sub: "#475569",
  black: "#111827",
  soft: "#f8fafc",
  amberBg: "#fffbeb",
  amberBorder: "#fde68a",
  amberText: "#92400e",
  greenBg: "#ecfdf5",
  greenBorder: "#a7f3d0",
  greenText: "#065f46",
  redBg: "#fef2f2",
  redBorder: "#fecaca",
  redText: "#991b1b",
};

type GeneratedEwn = {
  narrative: string;
  consequences: string[];
  mitigation: string[];
};

function Label({ children }: { children: React.ReactNode }) {
  return <span style={{ fontWeight: 700, fontSize: 12, color: c.sub }}>{children}</span>;
}

function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      style={{
        width: "100%",
        padding: "12px 12px",
        borderRadius: 14,
        border: `1px solid ${c.border}`,
        outline: "none",
        background: "#fff",
        color: c.black,
        fontSize: 14,
        lineHeight: 1.5,
        ...(props.style ?? {}),
      }}
    />
  );
}

function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      style={{
        width: "100%",
        minHeight: 112,
        padding: "12px 12px",
        borderRadius: 14,
        border: `1px solid ${c.border}`,
        outline: "none",
        resize: "vertical",
        background: "#fff",
        color: c.black,
        fontSize: 14,
        lineHeight: 1.55,
        fontFamily: "inherit",
        ...(props.style ?? {}),
      }}
    />
  );
}

function makeGeneratedEwn(input: {
  title: string;
  whatHappened: string;
  when: string;
  where: string;
  impact: string;
  requiredAction: string;
  evidence: string;
}): GeneratedEwn {
  const dateText = input.when.trim() ? ` on ${input.when.trim()}` : "";
  const locationText = input.where.trim() ? ` at ${input.where.trim()}` : "";
  const actionText = input.requiredAction.trim() || "confirmation of the required next steps";
  const impactText = input.impact.trim() || "potential delay, disruption and/or additional cost to the Subcontract Works";
  const evidenceText = input.evidence.trim() || "site records, photographs, allocation sheets and associated correspondence";

  return {
    narrative: `M O’Brien gives early warning of ${input.whatHappened.trim()}${locationText}${dateText}. This matter may affect progress, productivity and/or the commercial position of the Subcontract Works. The current known impact is ${impactText}. We request ${actionText} so that the matter can be reviewed, mitigated and progressed without avoidable delay. Supporting records currently include ${evidenceText}.`,
    consequences: [
      impactText,
      "Possible disruption to planned sequence and productivity if the matter is not resolved promptly.",
      "Potential requirement for further commercial notification should the matter result in a Compensation Event.",
    ],
    mitigation: [
      `MOB requires ${actionText} from the Contractor/design team as soon as practicable.`,
      "MOB will continue to maintain records of labour, plant, materials, site constraints and instructions relating to the matter.",
      "Where practical, MOB will seek to mitigate delay and disruption without waiving entitlement to recover resulting cost or time impact.",
    ],
  };
}

function readLocalEwns() {
  try {
    const raw = localStorage.getItem("cc.ewns");
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveLocalEwn(row: any) {
  const existing = readLocalEwns().filter((x: any) => x.id !== row.id);
  localStorage.setItem("cc.ewns", JSON.stringify([row, ...existing]));
}

export default function NewEwnPage() {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [projectName, setProjectName] = useState("");
  const [mainContractor, setMainContractor] = useState("");
  const [whatHappened, setWhatHappened] = useState("");
  const [when, setWhen] = useState("");
  const [where, setWhere] = useState("");
  const [impact, setImpact] = useState("");
  const [requiredAction, setRequiredAction] = useState("");
  const [evidence, setEvidence] = useState("");
  const [generated, setGenerated] = useState<GeneratedEwn | null>(null);
  const [savedId, setSavedId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const canGenerate = useMemo(() => title.trim() && whatHappened.trim() && !saving, [title, whatHappened, saving]);

  async function generateAndSave() {
    setErr(null);
    setSaving(true);
    try {
      const supabase = supabaseBrowser();
      const { data } = await supabase.auth.getSession();
      const token = data.session?.access_token;

      if (token) {
        const res = await fetch("/api/generate-ewn", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            id: savedId,
            title,
            projectName,
            mainContractor,
            whatHappened,
            when,
            where,
            impact,
            requiredAction,
            evidence,
          }),
        });

        const payload = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(payload?.error || "Failed to generate EWN");

        setGenerated(payload.generated_output as GeneratedEwn);
        setSavedId(payload.id as string);
        return;
      }

      const output = makeGeneratedEwn({ title, whatHappened, when, where, impact, requiredAction, evidence });
      setGenerated(output);

      const row = {
        id: savedId || crypto.randomUUID(),
        title: title.trim(),
        project_name: projectName.trim(),
        main_contractor: mainContractor.trim(),
        what_happened: whatHappened.trim(),
        event_date: when || null,
        location: where.trim(),
        impact: impact.trim(),
        required_action: requiredAction.trim(),
        evidence_summary: evidence.trim(),
        generated_output: output,
        status: "open",
        created_at: new Date().toISOString(),
      };

      saveLocalEwn(row);
      setSavedId(row.id);
    } catch (e: any) {
      setErr(e?.message ?? "Failed to generate EWN");
    } finally {
      setSaving(false);
    }
  }

  function convertHref() {
    const params = new URLSearchParams();
    if (savedId) params.set("from_ewn", savedId);
    params.set("title", title.trim());
    if (projectName.trim()) params.set("project", projectName.trim());
    if (mainContractor.trim()) params.set("main_contractor", mainContractor.trim());
    if (whatHappened.trim()) params.set("what_happened", whatHappened.trim());
    if (impact.trim()) params.set("impact", impact.trim());
    if (when) params.set("event_date", when);
    return `/app/new?${params.toString()}`;
  }

  return (
    <div style={{ display: "grid", gap: 18 }}>
      <div style={{ background: c.card, border: `1px solid ${c.border}`, borderRadius: 22, padding: 28 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 16, alignItems: "flex-start", flexWrap: "wrap" }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 800, color: c.sub, textTransform: "uppercase", letterSpacing: 0.6 }}>Early Warning Notice</div>
            <h1 style={{ fontSize: 24, fontWeight: 700, margin: "6px 0 0", color: c.black }}>New EWN</h1>
            <p style={{ margin: "8px 0 0", color: c.sub, fontSize: 13, lineHeight: 1.55, maxWidth: 780 }}>
              Log the issue quickly, generate a clean early warning narrative, then convert it into a CE if the commercial impact develops.
            </p>
          </div>
          <Link href="/app/ewns" style={{ border: `1px solid ${c.border}`, background: c.soft, color: c.black, borderRadius: 14, padding: "11px 13px", textDecoration: "none", fontWeight: 800, fontSize: 13 }}>
            View EWN register
          </Link>
        </div>

        <div style={{ display: "grid", gap: 16, marginTop: 22 }}>
          <label style={{ display: "grid", gap: 6 }}>
            <Label>EWN title</Label>
            <TextInput value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Existing services clash at Newlay" />
          </label>

          <div style={{ display: "grid", gap: 14, gridTemplateColumns: "repeat(2, minmax(0, 1fr))" }}>
            <label style={{ display: "grid", gap: 6 }}>
              <Label>Project / job</Label>
              <TextInput value={projectName} onChange={(e) => setProjectName(e.target.value)} placeholder="e.g. Calder Road" />
            </label>
            <label style={{ display: "grid", gap: 6 }}>
              <Label>Main contractor</Label>
              <TextInput value={mainContractor} onChange={(e) => setMainContractor(e.target.value)} placeholder="e.g. BAM Nuttall" />
            </label>
          </div>

          <label style={{ display: "grid", gap: 6 }}>
            <Label>What happened</Label>
            <TextArea value={whatHappened} onChange={(e) => setWhatHappened(e.target.value)} placeholder="Describe the issue in plain site language." />
          </label>

          <div style={{ display: "grid", gap: 14, gridTemplateColumns: "repeat(2, minmax(0, 1fr))" }}>
            <label style={{ display: "grid", gap: 6 }}>
              <Label>When</Label>
              <TextInput type="date" value={when} onChange={(e) => setWhen(e.target.value)} />
            </label>
            <label style={{ display: "grid", gap: 6 }}>
              <Label>Where</Label>
              <TextInput value={where} onChange={(e) => setWhere(e.target.value)} placeholder="Location, chainage, phase or work area" />
            </label>
          </div>

          <label style={{ display: "grid", gap: 6 }}>
            <Label>Impact</Label>
            <TextArea value={impact} onChange={(e) => setImpact(e.target.value)} placeholder="Delay, disruption, resequencing, standing time, extra supervision, restricted working etc." />
          </label>

          <label style={{ display: "grid", gap: 6 }}>
            <Label>Required action</Label>
            <TextArea value={requiredAction} onChange={(e) => setRequiredAction(e.target.value)} placeholder="What confirmation, instruction, design response or access is required?" />
          </label>

          <label style={{ display: "grid", gap: 6 }}>
            <Label>Evidence</Label>
            <TextArea value={evidence} onChange={(e) => setEvidence(e.target.value)} placeholder="Photos, diaries, allocation sheets, correspondence, drawings, instructions etc." />
          </label>

          {err ? <div style={{ border: `1px solid ${c.redBorder}`, background: c.redBg, color: c.redText, padding: 12, borderRadius: 14, fontSize: 13, fontWeight: 700 }}>{err}</div> : null}

          <button onClick={generateAndSave} disabled={!canGenerate} style={{ padding: "12px 14px", borderRadius: 14, border: `1px solid ${c.black}`, background: c.black, color: "#fff", fontWeight: 700, cursor: !canGenerate ? "not-allowed" : "pointer", opacity: !canGenerate ? 0.6 : 1 }}>
            {saving ? "Generating…" : savedId ? "Regenerate EWN" : "Generate EWN"}
          </button>
        </div>
      </div>

      {generated ? (
        <div style={{ background: c.card, border: `1px solid ${c.border}`, borderRadius: 22, padding: 28, display: "grid", gap: 18 }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 16, alignItems: "center", flexWrap: "wrap" }}>
            <div>
              <h2 style={{ fontSize: 18, fontWeight: 800, margin: 0, color: c.black }}>Generated EWN output</h2>
              <p style={{ margin: "6px 0 0", color: c.sub, fontSize: 13 }}>Keep the notice clean, factual and commercially useful.</p>
            </div>
            <Link href={convertHref()} style={{ border: `1px solid ${c.black}`, background: c.black, color: "#fff", borderRadius: 14, padding: "12px 14px", textDecoration: "none", fontWeight: 800, fontSize: 13 }}>
              Convert to CE →
            </Link>
          </div>

          <div style={{ display: "grid", gap: 14 }}>
            <section style={{ border: `1px solid ${c.border}`, background: c.soft, borderRadius: 18, padding: 16 }}>
              <div style={{ fontSize: 12, color: c.sub, fontWeight: 800, marginBottom: 8 }}>Narrative</div>
              <p style={{ margin: 0, color: c.black, fontSize: 14, lineHeight: 1.65 }}>{generated.narrative}</p>
            </section>
            <div style={{ display: "grid", gap: 14, gridTemplateColumns: "repeat(2, minmax(0, 1fr))" }}>
              <section style={{ border: `1px solid ${c.border}`, background: c.soft, borderRadius: 18, padding: 16 }}>
                <div style={{ fontSize: 12, color: c.sub, fontWeight: 800, marginBottom: 8 }}>Consequences</div>
                <ul style={{ margin: 0, paddingLeft: 18, color: c.black, fontSize: 14, lineHeight: 1.65 }}>{generated.consequences.map((x) => <li key={x}>{x}</li>)}</ul>
              </section>
              <section style={{ border: `1px solid ${c.border}`, background: c.soft, borderRadius: 18, padding: 16 }}>
                <div style={{ fontSize: 12, color: c.sub, fontWeight: 800, marginBottom: 8 }}>Mitigation</div>
                <ul style={{ margin: 0, paddingLeft: 18, color: c.black, fontSize: 14, lineHeight: 1.65 }}>{generated.mitigation.map((x) => <li key={x}>{x}</li>)}</ul>
              </section>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
