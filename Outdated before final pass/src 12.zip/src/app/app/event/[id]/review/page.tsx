"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import { getOwnedEventOrThrow, getRequiredUser, isAuthErrorMessage, isOwnershipErrorMessage } from "@/lib/security";
import CEProgress from "@/components/CEProgress";
import { downloadCeWorkbook } from "@/lib/exportWorkbook";
import { COMPANY_PROFILE_SELECT, cleanCompanyProfile } from "@/lib/companyProfile";
import { getContractFamily, getContractLabel, getCostLabel, getFeeBasisLabel } from "@/lib/contracts";
import { getDraftTemplateForContractType } from "@/lib/draftTemplates";
import { recalculateEventFinancialSummary } from "@/lib/financialSummary";
import { getCommercialStatusLabel, normaliseCommercialStatus } from "@/lib/commercialControl";

type Unit = "day" | "week";

type Basis = {
  happened_summary: string;
  cause_type: string | null;
  cause_summary: string;
  difference_from_plan: string;
  mechanism_tags: string[];
  time_impact_toggle: string;
  mitigation_summary: string;
};

type ValuationSettings = {
  fee_percent: number;
  fee_basis: "defined_cost" | "defined_cost_plus_prelims";
  work_days_per_week: number;
};

type ReviewSettings = {
  include_basis: boolean;
  include_entitlement: boolean;
  include_time_impact: boolean;
  include_evidence_register: boolean;
  include_cost_summary: boolean;
  include_prelims_fee: boolean;
  include_risk_notes: boolean;
  include_commercial_pushback: boolean;
  include_excel: boolean;
  include_pdf: boolean;
  qualifications_notes: string;
};

type CheckStatus = "pass" | "warning" | "missing";
type CheckGroup = "Contract readiness" | "Basis readiness" | "Evidence readiness" | "Cost readiness";

type CheckItem = {
  group: CheckGroup;
  label: string;
  status: CheckStatus;
  detail?: string;
  blocker?: boolean;
};

type RebuttalDraft = {
  rebuttal_subject: string;
  rebuttal_body: string;
  key_points: string[];
  risk_note: string;
  updated_at?: string | null;
};

const c = {
  bg: "#f6f7fb",
  card: "#ffffff",
  border: "#e5e7eb",
  sub: "#475569",
  black: "#111827",
  soft: "#f8fafc",
  redBg: "#fef2f2",
  redBorder: "#fecaca",
  redText: "#991b1b",
  greenBg: "#ecfdf5",
  greenBorder: "#a7f3d0",
  greenText: "#065f46",
  amberBg: "#fffbeb",
  amberBorder: "#fde68a",
  amberText: "#92400e",
  blueBg: "#eff6ff",
  blueBorder: "#bfdbfe",
  blueText: "#1d4ed8",
  lightGrey: "#f3f4f6",
};

const defaultBasis: Basis = {
  happened_summary: "",
  cause_type: null,
  cause_summary: "",
  difference_from_plan: "",
  mechanism_tags: [],
  time_impact_toggle: "unsure",
  mitigation_summary: "",
};

const defaultReviewSettings: ReviewSettings = {
  include_basis: true,
  include_entitlement: true,
  include_time_impact: true,
  include_evidence_register: true,
  include_cost_summary: true,
  include_prelims_fee: true,
  include_risk_notes: true,
  include_commercial_pushback: true,
  include_excel: true,
  include_pdf: true,
  qualifications_notes: "",
};


function splitSentencesForPushback(value: unknown) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .split(/(?<=[.!?])\s+/)
    .map((part) => part.trim())
    .filter(Boolean)
    .slice(0, 3);
}

function extractGeneratedCommercialPushback(aiDraft: any): Array<{ heading: string; note: string }> {
  const direct = aiDraft?.commercial_pushback;
  if (Array.isArray(direct)) {
    return direct
      .map((item: any, index: number) => ({
        heading: String(item?.challenge || item?.heading || `Generated challenge ${index + 1}`).trim(),
        note: String(item?.defence_note || item?.note || item?.response || "").trim(),
      }))
      .filter((item) => item.heading || item.note)
      .slice(0, 3);
  }

  const source = aiDraft?.risks_and_qualifications || aiDraft?.assumptions || "";
  const parts = splitSentencesForPushback(source);
  if (parts.length === 0) return [];
  return parts.map((note, index) => ({
    heading: index === 0 ? "Generated commercial pushback" : `Additional challenge ${index + 1}`,
    note,
  }));
}

function isMissingRebuttalTable(error: any) {
  const msg = String(error?.message || "").toLowerCase();
  return msg.includes("event_rebuttals") || msg.includes("schema cache") || msg.includes("does not exist");
}

function formatRebuttalDate(value?: string | null) {
  if (!value) return "";
  try {
    return new Date(value).toLocaleString();
  } catch {
    return "";
  }
}

function isUuid(v: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(v);
}

function clampNum(v: any, fallback: number) {
  const n = typeof v === "number" ? v : parseFloat(String(v));
  return Number.isFinite(n) ? n : fallback;
}

function getForceGenerateMode() {
  if (typeof window === "undefined") return false;
  try {
    return window.localStorage.getItem("cc_force_generate_mode") === "1";
  } catch {
    return false;
  }
}

function money(n: number) {
  if (!Number.isFinite(n)) return "£0.00";
  return new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency: "GBP",
  }).format(n);
}

function downloadJsonFile(filename: string, data: unknown) {
  if (typeof window === "undefined") return;
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function safeFileName(value: string) {
  return (value || "commercial-co-pilot")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80) || "commercial-co-pilot";
}

function calcPrelimsDaily(
  lines: Array<{ qty: number; unit: "day" | "week"; rate: number }>,
  workDaysPerWeek: number
) {
  const wd = Math.max(1, Math.min(7, workDaysPerWeek || 5));
  return lines.reduce((sum, l) => {
    const qty = l.qty || 0;
    const rate = l.rate || 0;
    const daily = l.unit === "week" ? rate / wd : rate;
    return sum + qty * daily;
  }, 0);
}

function SmallBtn(props: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...props}
      style={{
        padding: "10px 12px",
        borderRadius: 12,
        border: `1px solid ${c.border}`,
        background: "#fff",
        fontWeight: 700,
        cursor: props.disabled ? "not-allowed" : "pointer",
        opacity: props.disabled ? 0.6 : 1,
        ...(props.style ?? {}),
      }}
    />
  );
}

function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      style={{
        width: "100%",
        padding: 12,
        borderRadius: 14,
        border: `1px solid ${c.border}`,
        outline: "none",
        background: "#fff",
        color: c.black,
        fontSize: 14,
        lineHeight: 1.55,
        resize: "vertical",
        ...(props.style ?? {}),
      }}
    />
  );
}

function Card({
  title,
  hint,
  children,
}: {
  title: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <section
      style={{
        background: c.card,
        border: `1px solid ${c.border}`,
        borderRadius: 18,
        padding: 20,
      }}
    >
      <h2
        style={{
          fontSize: 16,
          fontWeight: 700,
          margin: 0,
          color: c.black,
        }}
      >
        {title}
      </h2>

      {hint ? (
        <p
          style={{
            marginTop: 8,
            marginBottom: 0,
            fontSize: 13,
            lineHeight: 1.55,
            color: c.sub,
          }}
        >
          {hint}
        </p>
      ) : null}

      <div style={{ marginTop: 16 }}>{children}</div>
    </section>
  );
}

function SidebarCard({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div
      style={{
        background: c.card,
        border: `1px solid ${c.border}`,
        borderRadius: 18,
        padding: "18px 20px",
      }}
    >
      <div
        style={{
          fontSize: 14,
          fontWeight: 700,
          color: c.black,
          marginBottom: 12,
        }}
      >
        {title}
      </div>

      <div
        style={{
          fontSize: 13,
          lineHeight: 1.55,
          color: c.sub,
        }}
      >
        {children}
      </div>
    </div>
  );
}

function Row({
  label,
  value,
  strong = false,
}: {
  label: React.ReactNode;
  value: React.ReactNode;
  strong?: boolean;
}) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
      <div
        style={{
          color: strong ? c.black : c.sub,
          fontWeight: strong ? 700 : 500,
          fontSize: 13,
        }}
      >
        {label}
      </div>
      <div
        style={{
          color: c.black,
          fontWeight: strong ? 800 : 700,
          fontSize: 13,
          textAlign: "right",
        }}
      >
        {value}
      </div>
    </div>
  );
}

function statusPill(status: CheckStatus) {
  if (status === "pass") {
    return {
      bg: c.greenBg,
      bd: c.greenBorder,
      tx: c.greenText,
      label: "Pass",
    };
  }
  if (status === "warning") {
    return {
      bg: c.amberBg,
      bd: c.amberBorder,
      tx: c.amberText,
      label: "Warning",
    };
  }
  return {
    bg: c.redBg,
    bd: c.redBorder,
    tx: c.redText,
    label: "Missing",
  };
}

export default function ReviewPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const searchParams = useSearchParams();
  const eventId = (params?.id ?? "").toString();
  const initialMode = searchParams?.get("mode");

  const [loaded, setLoaded] = useState(false);
  const [title, setTitle] = useState("Loading…");
  const [contractType, setContractType] = useState<string | null>(null);
  const [contractSource, setContractSource] = useState<string | null>(null);
  const [delayDays, setDelayDays] = useState(0);
  const [commercialStatus, setCommercialStatus] = useState("draft");
  const [paymentStatus, setPaymentStatus] = useState("not_applied");
  const [statusSaving, setStatusSaving] = useState(false);

  const [basis, setBasis] = useState<Basis>(defaultBasis);

  const [instructionCount, setInstructionCount] = useState(0);
  const [photosCount, setPhotosCount] = useState(0);
  const [siteRecordsCount, setSiteRecordsCount] = useState(0);
  const [programmeCount, setProgrammeCount] = useState(0);
  const [costSupportCount, setCostSupportCount] = useState(0);

  const [resourceCount, setResourceCount] = useState(0);
  const [labourTotal, setLabourTotal] = useState(0);
  const [plantTotal, setPlantTotal] = useState(0);
  const [materialTotal, setMaterialTotal] = useState(0);
  const [definedCost, setDefinedCost] = useState(0);

  const [prelimLineCount, setPrelimLineCount] = useState(0);
  const [prelimLines, setPrelimLines] = useState<Array<{ qty: number; unit: Unit; rate: number }>>([]);

  const [valuation, setValuation] = useState<ValuationSettings>({
    fee_percent: 12.5,
    fee_basis: "defined_cost",
    work_days_per_week: 5,
  });

  const [contractUploadCount, setContractUploadCount] = useState(0);

  const [reviewSettings, setReviewSettings] = useState<ReviewSettings>(defaultReviewSettings);

  const [status, setStatus] = useState<"not_saved" | "saved" | "unsaved" | "saving" | "error">(
    "not_saved"
  );
  const [saveErr, setSaveErr] = useState<string | null>(null);
  useEffect(() => {
    const sync = () => setForceGenerateMode(getForceGenerateMode());
    sync();
    window.addEventListener("storage", sync);
    window.addEventListener("cc:force-generate-changed", sync as EventListener);
    return () => {
      window.removeEventListener("storage", sync);
      window.removeEventListener("cc:force-generate-changed", sync as EventListener);
    };
  }, []);

  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generationStage, setGenerationStage] = useState("Preparing generation…");
  const progressTimerRef = useRef<ReturnType<typeof window.setInterval> | null>(null);
  const [hasGeneratedPack, setHasGeneratedPack] = useState(false);
  const [forceGenerateMode, setForceGenerateMode] = useState(false);
  const [billingGateLoaded, setBillingGateLoaded] = useState(false);
  const [creditsRemaining, setCreditsRemaining] = useState(0);
  const [isAdminUnlimited, setIsAdminUnlimited] = useState(false);
  const [lastSavedAt, setLastSavedAt] = useState<number | null>(null);
  const [showReadinessDetails, setShowReadinessDetails] = useState(false);
  const [generatedCommercialPushback, setGeneratedCommercialPushback] = useState<Array<{ heading: string; note: string }>>([]);
  const [contractorResponse, setContractorResponse] = useState("");
  const [generatedRebuttal, setGeneratedRebuttal] = useState<RebuttalDraft | null>(null);
  const [isGeneratingRebuttal, setIsGeneratingRebuttal] = useState(false);
  const [rebuttalErr, setRebuttalErr] = useState<string | null>(null);
  const [rebuttalTableMissing, setRebuttalTableMissing] = useState(false);
  const [showRebuttalPanel, setShowRebuttalPanel] = useState(initialMode === "rebuttal");


  useEffect(() => {
    if (initialMode === "rebuttal" || commercialStatus === "rejected") {
      setShowRebuttalPanel(true);
    }
  }, [initialMode, commercialStatus]);

  const lastSavedSnapshotRef = useRef<string>("");
  const [lastSavedSnapshot, setLastSavedSnapshot] = useState("");
  const savingRef = useRef(false);

  function clearGenerationProgressTimer() {
    if (progressTimerRef.current) {
      window.clearInterval(progressTimerRef.current);
      progressTimerRef.current = null;
    }
  }

  function startGenerationProgress() {
    clearGenerationProgressTimer();
    setGenerationProgress(3);
    setGenerationStage("Analysing event data…");

    progressTimerRef.current = window.setInterval(() => {
      setGenerationProgress((current) => {
        const next = current < 35 ? current + 4 : current < 65 ? current + 3 : current < 84 ? current + 2 : current < 91 ? current + 1 : current;

        if (next < 30) setGenerationStage("Analysing event data…");
        else if (next < 58) setGenerationStage("Generating contract-aware narrative…");
        else if (next < 82) setGenerationStage("Building workbook sections…");
        else setGenerationStage("Finalising download…");

        return Math.min(next, 91);
      });
    }, 700);
  }

  async function finishGenerationProgress() {
    clearGenerationProgressTimer();
    setGenerationStage("Finalising download…");
    setGenerationProgress(100);
    await new Promise((resolve) => window.setTimeout(resolve, 450));
  }

  useEffect(() => {
    return () => clearGenerationProgressTimer();
  }, []);

  const prelimsDaily = useMemo(
    () => calcPrelimsDaily(prelimLines, valuation.work_days_per_week || 5),
    [prelimLines, valuation.work_days_per_week]
  );

  const prelimsTotal = useMemo(() => prelimsDaily * (delayDays || 0), [prelimsDaily, delayDays]);

  const feeBase = useMemo(() => {
    return valuation.fee_basis === "defined_cost_plus_prelims"
      ? definedCost + prelimsTotal
      : definedCost;
  }, [definedCost, prelimsTotal, valuation.fee_basis]);

  const feeAmount = useMemo(
    () => feeBase * ((valuation.fee_percent || 0) / 100),
    [feeBase, valuation.fee_percent]
  );

  const ceTotal = useMemo(
    () => definedCost + prelimsTotal + feeAmount,
    [definedCost, prelimsTotal, feeAmount]
  );

  const contractFamily = useMemo(() => getContractFamily(contractType), [contractType]);
  const contractLabel = useMemo(() => getContractLabel(contractType), [contractType]);
  const costLabel = useMemo(() => getCostLabel(contractType), [contractType]);
  const feeBasisLabel = useMemo(() => getFeeBasisLabel(contractType, valuation.fee_basis), [contractType, valuation.fee_basis]);
  const draftTemplate = useMemo(() => getDraftTemplateForContractType(contractType), [contractType]);
  const checks = useMemo<CheckItem[]>(() => {
    const list: CheckItem[] = [];

    list.push({
      group: "Contract readiness",
      label: "Contract type selected",
      status: contractType ? "pass" : "missing",
      blocker: !contractType,
    });

    list.push({
      group: "Contract readiness",
      label: "Contract source selected",
      status: contractSource ? "pass" : "missing",
      blocker: !contractSource,
    });

    if (contractSource === "upload_contract") {
      list.push({
        group: "Contract readiness",
        label: "Uploaded contract present",
        status: contractUploadCount > 0 ? "pass" : "missing",
        detail: contractUploadCount > 0 ? `${contractUploadCount} file(s)` : "No contract files found",
        blocker: contractUploadCount === 0,
      });
    } else {
      list.push({
        group: "Contract readiness",
        label: "Uploaded contract present",
        status: "warning",
        detail: "Using standard contract logic",
      });
    }

    list.push({
      group: "Basis readiness",
      label: "What happened completed",
      status: basis.happened_summary.trim() ? "pass" : "missing",
      blocker: !basis.happened_summary.trim(),
    });

    list.push({
      group: "Basis readiness",
      label: "Cause completed",
      status: basis.cause_type && basis.cause_summary.trim() ? "pass" : "missing",
      blocker: !(basis.cause_type && basis.cause_summary.trim()),
    });

    list.push({
      group: "Basis readiness",
      label: "Difference from plan completed",
      status: basis.difference_from_plan.trim() ? "pass" : "missing",
      blocker: !basis.difference_from_plan.trim(),
    });

    list.push({
      group: "Basis readiness",
      label: "Mechanism selected",
      status: basis.mechanism_tags.length > 0 ? "pass" : "missing",
      blocker: basis.mechanism_tags.length === 0,
    });

    list.push({
      group: "Basis readiness",
      label: "Time impact assessed",
      status: basis.time_impact_toggle && basis.time_impact_toggle !== "unsure" ? "pass" : "warning",
      detail:
        basis.time_impact_toggle === "yes"
          ? "Programme impact marked yes"
          : basis.time_impact_toggle === "no"
          ? "Programme impact marked no"
          : "Still marked unsure",
    });

    list.push({
      group: "Basis readiness",
      label: "Mitigation completed",
      status: basis.mitigation_summary.trim() ? "pass" : "warning",
      detail: basis.mitigation_summary.trim()
        ? "Mitigation recorded"
        : "No mitigation or limitation note entered",
    });

    list.push({
      group: "Evidence readiness",
      label: "Instruction / communication evidence",
      status: instructionCount > 0 ? "pass" : "warning",
      detail: `${instructionCount} file(s)`,
    });

    list.push({
      group: "Evidence readiness",
      label: "Photos",
      status: photosCount > 0 ? "pass" : "warning",
      detail: `${photosCount} file(s)`,
    });

    list.push({
      group: "Evidence readiness",
      label: "Site records",
      status: siteRecordsCount > 0 ? "pass" : "warning",
      detail: `${siteRecordsCount} file(s)`,
    });

    list.push({
      group: "Evidence readiness",
      label: "Programme support",
      status: programmeCount > 0 ? "pass" : "warning",
      detail:
        programmeCount > 0
          ? `${programmeCount} file(s)`
          : delayDays > 0
          ? "Delay days entered but no programme evidence uploaded"
          : "No programme files uploaded",
    });

    list.push({
      group: "Evidence readiness",
      label: "Cost support",
      status: costSupportCount > 0 ? "pass" : "warning",
      detail: `${costSupportCount} file(s)`,
    });

    list.push({
      group: "Cost readiness",
      label: "Resource lines added",
      status: resourceCount > 0 ? "pass" : "missing",
      detail: `${resourceCount} line(s)`,
      blocker: resourceCount === 0,
    });

    list.push({
      group: "Cost readiness",
      label: "Delay days set",
      status:
        basis.time_impact_toggle === "yes" && delayDays <= 0
          ? "missing"
          : delayDays > 0
          ? "pass"
          : "warning",
      detail: `${delayDays} day(s)`,
      blocker: basis.time_impact_toggle === "yes" && delayDays <= 0,
    });

    list.push({
      group: "Cost readiness",
      label: "Fee settings completed",
      status: valuation.fee_percent >= 0 ? "pass" : "missing",
      detail: `${valuation.fee_percent}%`,
    });

    list.push({
      group: "Cost readiness",
      label: "Prelim lines reviewed",
      status: prelimLineCount > 0 ? "pass" : "warning",
      detail: `${prelimLineCount} line(s)`,
    });

    return list;
  }, [
    basis,
    contractType,
    contractSource,
    contractUploadCount,
    instructionCount,
    photosCount,
    siteRecordsCount,
    programmeCount,
    costSupportCount,
    resourceCount,
    delayDays,
    valuation,
    prelimLineCount,
  ]);

  const blockers = useMemo(
    () => checks.filter((x) => x.status === "missing" && x.blocker).length,
    [checks]
  );

  const warnings = useMemo(
    () => checks.filter((x) => x.status === "warning").length,
    [checks]
  );

  const generationCreditLocked = billingGateLoaded && !isAdminUnlimited && creditsRemaining <= 0 && !hasGeneratedPack;
  const generateDisabled = blockers > 0 || isGenerating || generationCreditLocked;
  const generateButtonLabel = generationCreditLocked
    ? "No credits remaining"
    : forceGenerateMode
    ? "Generate pack"
    : hasGeneratedPack
    ? "Download pack"
    : "Generate pack";

  const readiness = useMemo(() => {
    const total = checks.length || 1;
    const score = checks.reduce((acc, item) => {
      if (item.status === "pass") return acc + 1;
      if (item.status === "warning") return acc + 0.5;
      return acc;
    }, 0);
    return Math.round((score / total) * 100);
  }, [checks]);

  const groupedChecks = useMemo(() => {
    return {
      contract: checks.filter((x) => x.group === "Contract readiness"),
      basis: checks.filter((x) => x.group === "Basis readiness"),
      evidence: checks.filter((x) => x.group === "Evidence readiness"),
      cost: checks.filter((x) => x.group === "Cost readiness"),
    };
  }, [checks]);

  const currentSnapshot = useMemo(
    () =>
      JSON.stringify({
        reviewSettings,
      }),
    [reviewSettings]
  );

  const isDirty = useMemo(() => {
    if (!loaded) return false;
    return currentSnapshot !== lastSavedSnapshot;
  }, [currentSnapshot, loaded]);

  useEffect(() => {
    if (!loaded || !eventId || !isUuid(eventId)) return;
    try {
      const stored = window.localStorage.getItem(`ccp-review-pushback-${eventId}`);
      if (stored === null) return;
      const parsed = stored === "true";
      setReviewSettings((prev) => ({ ...prev, include_commercial_pushback: parsed }));
    } catch {}
  }, [loaded, eventId]);

  useEffect(() => {
    if (!loaded || !eventId || !isUuid(eventId)) return;
    try {
      window.localStorage.setItem(
        `ccp-review-pushback-${eventId}`,
        String(reviewSettings.include_commercial_pushback)
      );
    } catch {}
  }, [loaded, eventId, reviewSettings.include_commercial_pushback]);

  const evidenceCount = useMemo(
    () => instructionCount + photosCount + siteRecordsCount + programmeCount + costSupportCount,
    [instructionCount, photosCount, siteRecordsCount, programmeCount, costSupportCount]
  );

  const pushbackItems = useMemo(() => {
    const items: Array<{ heading: string; note: string }> = [];

    if (programmeCount === 0 && delayDays > 0) {
      items.push({
        heading: "Time impact evidence",
        note: "Expect pushback if delay days are included without programme support showing the path from event to time effect.",
      });
    }

    if (photosCount === 0 && instructionCount === 0 && siteRecordsCount === 0) {
      items.push({
        heading: "Event substantiation",
        note: "The event narrative may be challenged if there is little visible instruction, site or photographic evidence behind the change.",
      });
    }

    if (basis.mechanism_tags.length === 0) {
      items.push({
        heading: "Commercial mechanism",
        note: "Without a clear mechanism of impact, the submission risks reading as a cost statement rather than a cause-and-effect entitlement case.",
      });
    }

    if (resourceCount === 0) {
      items.push({
        heading: "Cost build-up",
        note: "Any total without supporting resource lines is likely to attract immediate challenge on valuation basis.",
      });
    }

    if (prelimLineCount === 0 && delayDays > 0) {
      items.push({
        heading: "Prelim prolongation",
        note: "Where time impact is included, expect questions on why prolonged prelims are or are not part of the valuation.",
      });
    }

    if (!reviewSettings.qualifications_notes.trim()) {
      items.push({
        heading: "Reservations / assumptions",
        note: "If anything remains provisional, add a qualification note now to reduce avoidable back-and-forth after issue.",
      });
    }

    return items.slice(0, 4);
  }, [
    programmeCount,
    delayDays,
    photosCount,
    instructionCount,
    siteRecordsCount,
    basis.mechanism_tags,
    resourceCount,
    prelimLineCount,
    reviewSettings.qualifications_notes,
  ]);

  const badge = useMemo(() => {
    if (status === "error") {
      return { bg: c.redBg, bd: c.redBorder, tx: c.redText, label: "Save failed" };
    }
    if (status === "saving") {
      return { bg: c.amberBg, bd: c.amberBorder, tx: c.amberText, label: "Saving…" };
    }
    if (status === "unsaved") {
      return { bg: c.amberBg, bd: c.amberBorder, tx: c.amberText, label: "Unsaved" };
    }
    if (status === "saved") {
      return { bg: c.greenBg, bd: c.greenBorder, tx: c.greenText, label: "Saved" };
    }
    return { bg: "#fff", bd: c.border, tx: c.sub, label: "Not saved" };
  }, [status]);

  useEffect(() => {
    if (!loaded) return;
    if (status === "saving" || status === "error") return;
    setStatus(isDirty ? "unsaved" : lastSavedAt ? "saved" : "not_saved");
  }, [isDirty, loaded, lastSavedAt]);

  useEffect(() => {
    (async () => {
      setSaveErr(null);
      if (!eventId || !isUuid(eventId)) return;

      const supabase = supabaseBrowser();

      try {
        const user = await getRequiredUser(supabase);
        let eventData: any;
        try {
          eventData = await getOwnedEventOrThrow(
            supabase,
            eventId,
            user.id,
            "id,title,status,payment_status,delay_days,contract_type,contract_source,user_id"
          );
        } catch (eventLoadError: any) {
          const message = String(eventLoadError?.message || "");
          const optionalColumnMissing = /payment_status/i.test(message);
          if (!optionalColumnMissing) throw eventLoadError;
          eventData = await getOwnedEventOrThrow(
            supabase,
            eventId,
            user.id,
            "id,title,status,delay_days,contract_type,contract_source,user_id"
          );
        }

        setTitle(eventData.title ?? "");
        setDelayDays(clampNum(eventData.delay_days, 0));
        setCommercialStatus(normaliseCommercialStatus(eventData.status));
        setPaymentStatus(eventData.payment_status ?? "not_applied");
        setContractType(eventData.contract_type ?? null);
        setContractSource(eventData.contract_source ?? null);

        const basisRes = await supabase
          .from("event_basis")
          .select(
            "happened_summary,cause_type,cause_summary,difference_from_plan,mechanism_tags,time_impact_toggle,mitigation_summary"
          )
          .eq("event_id", eventId)
          .maybeSingle();

        if (basisRes.data) {
          setBasis({
            happened_summary: basisRes.data.happened_summary ?? "",
            cause_type: basisRes.data.cause_type ?? null,
            cause_summary: basisRes.data.cause_summary ?? "",
            difference_from_plan: basisRes.data.difference_from_plan ?? "",
            mechanism_tags: Array.isArray(basisRes.data.mechanism_tags)
              ? basisRes.data.mechanism_tags
              : [],
            time_impact_toggle: basisRes.data.time_impact_toggle ?? "unsure",
            mitigation_summary: basisRes.data.mitigation_summary ?? "",
          });
        }

        const filesRes = await supabase
          .from("event_files")
          .select("category")
          .eq("event_id", eventId);

        const fileRows = (filesRes.data ?? []) as Array<{ category: string }>;
        setInstructionCount(fileRows.filter((x) => x.category === "instructions").length);
        setPhotosCount(fileRows.filter((x) => x.category === "photos").length);
        setSiteRecordsCount(fileRows.filter((x) => x.category === "site_records").length);
        setProgrammeCount(fileRows.filter((x) => x.category === "programme").length);
        setCostSupportCount(fileRows.filter((x) => x.category === "cost_support").length);

        const resourceRes = await supabase
          .from("event_resource_lines")
          .select("category,total")
          .eq("event_id", eventId);

        const resourceRows = (resourceRes.data ?? []) as Array<{ category: string; total: number }>;
        setResourceCount(resourceRows.length);

        const labour = resourceRows
          .filter((x) => x.category === "labour")
          .reduce((sum, x) => sum + clampNum(x.total, 0), 0);
        const plant = resourceRows
          .filter((x) => x.category === "plant")
          .reduce((sum, x) => sum + clampNum(x.total, 0), 0);
        const material = resourceRows
          .filter((x) => x.category === "material")
          .reduce((sum, x) => sum + clampNum(x.total, 0), 0);

        setLabourTotal(labour);
        setPlantTotal(plant);
        setMaterialTotal(material);
        setDefinedCost(labour + plant + material);

        const valuationRes = await supabase
          .from("event_valuation_settings")
          .select("fee_percent,fee_basis,work_days_per_week")
          .eq("event_id", eventId)
          .maybeSingle();

        setValuation({
          fee_percent: clampNum(valuationRes.data?.fee_percent, 12.5),
          fee_basis:
            (valuationRes.data?.fee_basis as "defined_cost" | "defined_cost_plus_prelims") ||
            "defined_cost",
          work_days_per_week: clampNum(valuationRes.data?.work_days_per_week, 5),
        });

        const prelimRes = await supabase
          .from("event_prelim_lines")
          .select("qty,unit,rate,prelim_type")
          .eq("event_id", eventId);

        const prelimRows =
          ((prelimRes.data ?? []) as Array<{ qty: number; unit: Unit; rate: number }>) || [];
        setPrelimLineCount(prelimRows.length);
        setPrelimLines(prelimRows);

        if (eventData.contract_source === "upload_contract") {
          const contractFilesRes = await supabase
            .from("event_contract_files")
            .select("id")
            .eq("event_id", eventId);
          setContractUploadCount((contractFilesRes.data ?? []).length);
        } else {
          setContractUploadCount(0);
        }

        const reviewRes = await supabase
          .from("event_review_settings")
          .select(
            "include_basis,include_entitlement,include_time_impact,include_evidence_register,include_cost_summary,include_prelims_fee,include_risk_notes,include_commercial_pushback,include_excel,include_pdf,qualifications_notes"
          )
          .eq("event_id", eventId)
          .maybeSingle();

        const mergedReview: ReviewSettings = {
          ...defaultReviewSettings,
          ...(reviewRes.data ?? {}),
          qualifications_notes: reviewRes.data?.qualifications_notes ?? "",
        };

        setReviewSettings(mergedReview);

        const existingPackId = await getExistingPackId(supabase, user.id);
        setHasGeneratedPack(Boolean(existingPackId) && !getForceGenerateMode());

        try {
          const rebuttalRes = await supabase
            .from("event_rebuttals")
            .select("contractor_response,rebuttal_subject,rebuttal_body,key_points,risk_note,updated_at")
            .eq("event_id", eventId)
            .maybeSingle();

          if (rebuttalRes.error) throw rebuttalRes.error;
          if (rebuttalRes.data) {
            setContractorResponse(String((rebuttalRes.data as any).contractor_response || ""));
            setGeneratedRebuttal({
              rebuttal_subject: String((rebuttalRes.data as any).rebuttal_subject || ""),
              rebuttal_body: String((rebuttalRes.data as any).rebuttal_body || ""),
              key_points: Array.isArray((rebuttalRes.data as any).key_points) ? (rebuttalRes.data as any).key_points : [],
              risk_note: String((rebuttalRes.data as any).risk_note || ""),
              updated_at: (rebuttalRes.data as any).updated_at || null,
            });
          }
          setRebuttalTableMissing(false);
        } catch (rebuttalLoadError: any) {
          if (isMissingRebuttalTable(rebuttalLoadError)) {
            setRebuttalTableMissing(true);
          } else {
            console.warn("Failed to load rebuttal", rebuttalLoadError?.message || rebuttalLoadError);
          }
        }

        const [creditGateRes, profileGateRes] = await Promise.all([
          supabase
            .from("user_credits")
            .select("credits_remaining")
            .eq("user_id", user.id)
            .maybeSingle(),
          supabase
            .from("profiles")
            .select("is_admin_unlimited, credits_remaining")
            .eq("id", user.id)
            .maybeSingle(),
        ]);

        if (creditGateRes.error) throw creditGateRes.error;
        if (profileGateRes.error && !/relation .*profiles.* does not exist/i.test(profileGateRes.error.message || "")) throw profileGateRes.error;

        setCreditsRemaining(clampNum((creditGateRes.data as any)?.credits_remaining ?? (profileGateRes.data as any)?.credits_remaining, 0));
        setIsAdminUnlimited(Boolean((profileGateRes.data as any)?.is_admin_unlimited));
        setBillingGateLoaded(true);

        const snapshot = JSON.stringify({
          reviewSettings: mergedReview,
        });
        lastSavedSnapshotRef.current = snapshot;
        setLastSavedSnapshot(snapshot);
        setLastSavedAt(Date.now());
        setStatus("saved");
        await recalculateEventFinancialSummary(supabase, eventId, user.id);
        setLoaded(true);
      } catch (e: any) {
        if (isAuthErrorMessage(e?.message)) {
          router.push("/login");
          return;
        }
        if (isOwnershipErrorMessage(e?.message)) {
          setTitle("Event not found");
          setLoaded(true);
          return;
        }
        console.error(e);
        setStatus("error");
        setSaveErr(e?.message ?? "Failed to load review");
        setLoaded(true);
      }
    })();
  }, [eventId, router]);

  useEffect(() => {
    if (!loaded) return;
    if (!isDirty) return;
    if (savingRef.current) return;

    const t = setTimeout(() => {
      void saveNow();
    }, 900);

    return () => clearTimeout(t);
  }, [isDirty, loaded, currentSnapshot]);

  async function saveNow() {
    if (!eventId || !isUuid(eventId)) return;
    if (savingRef.current) return;

    const snap = JSON.stringify({
      reviewSettings,
    });

    if (snap === lastSavedSnapshotRef.current) return;

    savingRef.current = true;
    setStatus("saving");
    setSaveErr(null);

    try {
      const supabase = supabaseBrowser();
      const user = await getRequiredUser(supabase);
      await getOwnedEventOrThrow(supabase, eventId, user.id);

      const { include_commercial_pushback, ...reviewPayload } = reviewSettings;

      const { error } = await supabase.from("event_review_settings").upsert(
        {
          event_id: eventId,
          ...reviewPayload,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "event_id" }
      );

      if (error) throw error;

      lastSavedSnapshotRef.current = snap;
      setLastSavedSnapshot(snap);
      setLastSavedAt(Date.now());
      setStatus("saved");
    } catch (e: any) {
      console.error(e);
      setStatus("error");
      setSaveErr(e?.message ?? "Save failed");
    } finally {
      savingRef.current = false;
    }
  }

  async function getExistingPackId(supabase: ReturnType<typeof supabaseBrowser>, userId: string) {
    if (forceGenerateMode) return null;
    const res = await supabase
      .from("event_packs")
      .select("id")
      .eq("event_id", eventId)
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (res.error) throw res.error;
    return res.data?.id ?? null;
  }

  async function buildWorkbookPayload(supabase: ReturnType<typeof supabaseBrowser>, userId: string) {
    let eventData: any;
    try {
      eventData = await getOwnedEventOrThrow(
        supabase,
        eventId,
        userId,
        "id,title,status,payment_status,delay_days,contract_type,contract_source,user_id"
      );
    } catch (eventLoadError: any) {
      const message = String(eventLoadError?.message || "");
      const optionalColumnMissing = /payment_status/i.test(message);
      if (!optionalColumnMissing) throw eventLoadError;
      eventData = await getOwnedEventOrThrow(
        supabase,
        eventId,
        userId,
        "id,title,status,delay_days,contract_type,contract_source,user_id"
      );
    }

    const eventRes = { data: eventData } as any;

    const [basisRes, resourceRes, prelimRes, filesRes, valuationRes, companyProfileRes] = await Promise.all([
      supabase
        .from("event_basis")
        .select("happened_summary,cause_type,cause_summary,difference_from_plan,mechanism_tags,time_impact_toggle,mitigation_summary")
        .eq("event_id", eventId)
        .maybeSingle(),
      supabase
        .from("event_resource_lines")
        .select("category,item_name,unit,hours,qty,rate,total,notes,start_date,end_date,linked_event")
        .eq("event_id", eventId)
        .order("start_date", { ascending: true }),
      supabase
        .from("event_prelim_lines")
        .select("name,qty,unit,rate,notes,prelim_type")
        .eq("event_id", eventId),
      supabase
        .from("event_files")
        .select("id,category,file_name,description,relates_to,evidence_date,file_path")
        .eq("event_id", eventId),
      supabase
        .from("event_valuation_settings")
        .select("fee_percent,fee_basis,work_days_per_week")
        .eq("event_id", eventId)
        .maybeSingle(),
      supabase
        .from("company_profiles")
        .select(COMPANY_PROFILE_SELECT)
        .eq("user_id", userId)
        .maybeSingle(),
    ]);

    if (basisRes.error) throw basisRes.error;
    if (resourceRes.error) throw resourceRes.error;
    if (prelimRes.error) throw prelimRes.error;
    if (filesRes.error) throw filesRes.error;
    if (valuationRes.error) throw valuationRes.error;
    if (companyProfileRes.error) console.warn("Company profile unavailable for workbook export:", companyProfileRes.error);

    const fileRows = (filesRes.data ?? []) as Array<{
      id: string;
      category: string;
      file_name: string | null;
      description: string | null;
      relates_to: string | null;
      evidence_date: string | null;
      file_path: string | null;
    }>;
    const counts = {
      instructions: fileRows.filter((x) => x.category === "instructions").length,
      photos: fileRows.filter((x) => x.category === "photos").length,
      site_records: fileRows.filter((x) => x.category === "site_records").length,
      programme: fileRows.filter((x) => x.category === "programme").length,
      cost_support: fileRows.filter((x) => x.category === "cost_support").length,
    };

    const origin = (process.env.NEXT_PUBLIC_APP_URL || (typeof window !== "undefined" ? window.location.origin : ""))?.replace(/\/$/, "") || "";
    const evidence = await Promise.all(
      fileRows.map(async (file) => {
        let downloadUrl: string | null = null;

        if (file.id && origin) {
          const existing = await supabase
            .from("event_file_share_links")
            .select("token")
            .eq("event_file_id", file.id)
            .eq("is_active", true)
            .maybeSingle();

          let token = existing.data?.token ?? null;
          if (!token) {
            token = crypto.randomUUID().replace(/-/g, "") + crypto.randomUUID().replace(/-/g, "");
            const inserted = await supabase.from("event_file_share_links").insert({
              event_id: eventId,
              event_file_id: file.id,
              token,
              issued_file_name: file.file_name ?? "evidence-file",
              is_active: true,
            });

            if (inserted.error && !String(inserted.error.message || "").toLowerCase().includes("duplicate")) {
              throw inserted.error;
            }

            if (inserted.error) {
              const retry = await supabase
                .from("event_file_share_links")
                .select("token")
                .eq("event_file_id", file.id)
                .eq("is_active", true)
                .maybeSingle();
              token = retry.data?.token ?? null;
            }
          }

          if (token) {
            downloadUrl = `${origin}/api/evidence-download/${token}`;
          }
        }

        return {
          file_name: file.file_name ?? "Untitled file",
          category: file.category,
          description: file.description,
          relates_to: file.relates_to,
          evidence_date: file.evidence_date,
          signed_url: downloadUrl,
        };
      })
    );

    return {
      payload: {
        companyProfile: cleanCompanyProfile(companyProfileRes.data || null),
        meta: {
          title: eventRes.data.title ?? title,
          contractType: eventRes.data.contract_type ?? contractType,
          contractSource: eventRes.data.contract_source ?? contractSource,
          delayDays: clampNum(eventRes.data.delay_days, delayDays),
          generatedAt: new Date().toISOString(),
        },
        basis: basisRes.data ?? basis,
        resources: (resourceRes.data ?? []) as any,
        prelims: (prelimRes.data ?? []) as any,
        valuation: {
          fee_percent: clampNum(valuationRes.data?.fee_percent, valuation.fee_percent),
          fee_basis: (valuationRes.data?.fee_basis as any) || valuation.fee_basis,
          work_days_per_week: clampNum(valuationRes.data?.work_days_per_week, valuation.work_days_per_week),
        },
        review: reviewSettings,
        fileCounts: counts,
        evidence,
        readiness,
        warnings,
        blockers,
      },
    };
  }

  function updateReview<K extends keyof ReviewSettings>(key: K, value: ReviewSettings[K]) {
    setReviewSettings((prev) => ({
      ...prev,
      [key]: value,
    }));
  }

  async function handleGenerateRebuttal() {
    if (!eventId || !isUuid(eventId)) return;
    const cleanResponse = contractorResponse.trim();
    if (cleanResponse.length < 20) {
      setRebuttalErr("Paste the contractor rejection or assessment response before generating a rebuttal.");
      return;
    }

    setIsGeneratingRebuttal(true);
    setRebuttalErr(null);

    try {
      const supabase = supabaseBrowser();
      const sessionRes = await supabase.auth.getSession();
      if (sessionRes.error) throw sessionRes.error;
      const accessToken = sessionRes.data.session?.access_token;
      if (!accessToken) throw new Error("AUTH_REQUIRED");

      const res = await fetch("/api/generate-rebuttal", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          eventId,
          contractorResponse: cleanResponse,
        }),
      });

      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(data?.error || "Failed to generate rebuttal");
      }

      setGeneratedRebuttal(data.rebuttal || null);
      setRebuttalTableMissing(false);
    } catch (e: any) {
      console.error(e);
      const message = e?.message || "Failed to generate rebuttal";
      setRebuttalErr(message.includes("event_rebuttals") ? "Run the rebuttal SQL patch before generating rebuttals." : message);
    } finally {
      setIsGeneratingRebuttal(false);
    }
  }

  async function handleGeneratePack() {
    if (!eventId || !isUuid(eventId)) return;

    setIsGenerating(true);
    startGenerationProgress();
    setSaveErr(null);

    try {
      const supabase = supabaseBrowser();
      const user = await getRequiredUser(supabase);

      const { payload } = await buildWorkbookPayload(supabase, user.id);
      await recalculateEventFinancialSummary(supabase, eventId, user.id);

      const sessionRes = await supabase.auth.getSession();
      if (sessionRes.error) throw sessionRes.error;
      const accessToken = sessionRes.data.session?.access_token;
      if (!accessToken) throw new Error("AUTH_REQUIRED");

      const generateRes = await fetch("/api/generate-pack", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          eventId,
          forceGenerateMode,
          forceAiGeneration: true,
          pack: {
            delay_days: delayDays || 0,
            defined_cost: definedCost || 0,
            prelim_cost: prelimsTotal || 0,
            fee_amount: feeAmount || 0,
            total_value: ceTotal || 0,
            readiness_score: readiness || 0,
            pack_version: 1,
          },
        }),
      });

      const generateData = await generateRes.json().catch(() => ({}));
      if (!generateRes.ok) {
        throw new Error(generateData?.error || "Failed to generate pack");
      }

      await finishGenerationProgress();

      downloadCeWorkbook(payload, generateData?.aiDraft);

      const generatedPushback = reviewSettings.include_commercial_pushback
        ? extractGeneratedCommercialPushback(generateData?.aiDraft)
        : [];
      const displayedGeneratedPushback =
        reviewSettings.include_commercial_pushback && generatedPushback.length === 0
          ? [
              {
                heading: "Commercial pushback generated",
                note: "The AI did not identify a specific challenge theme from the generated pack output.",
              },
            ]
          : generatedPushback;
      setGeneratedCommercialPushback(displayedGeneratedPushback);

      const generatedDraftWithInternalPushback =
        generateData?.aiDraft && reviewSettings.include_commercial_pushback
          ? {
              ...generateData.aiDraft,
              commercial_pushback: generatedPushback.map((item) => ({
                challenge: item.heading,
                defence_note: item.note,
              })),
            }
          : generateData?.aiDraft;

      if (generateData?.draftPayload) {
        downloadJsonFile(
          `${safeFileName(title || "ce-pack")}-ai-payload.json`,
          generateData.draftPayload
        );
      }

      if (generatedDraftWithInternalPushback) {
        downloadJsonFile(
          `${safeFileName(title || "ce-pack")}-ai-draft.json`,
          generatedDraftWithInternalPushback
        );
      }

      if (typeof generateData?.creditsRemaining === "number") {
        setCreditsRemaining(generateData.creditsRemaining);
      }

      setHasGeneratedPack(!forceGenerateMode);
    } catch (e: any) {
      clearGenerationProgressTimer();
      setGenerationProgress(0);
      setGenerationStage("Preparing generation…");
      console.error(e);
      setSaveErr(e?.message ?? "Failed to generate Excel pack");
    } finally {
      setIsGenerating(false);
    }
  }
  if (!eventId || !isUuid(eventId)) {
    return <div style={{ padding: 28 }}>Invalid event id.</div>;
  }

  if (!loaded) {
    return (
      <div style={{ background: c.bg, minHeight: "100vh" }}>
        <div style={{ padding: "22px 18px", maxWidth: 1280, margin: "0 auto" }}>
          <div
            style={{
              background: c.card,
              border: `1px solid ${c.border}`,
              borderRadius: 22,
              padding: 20,
              color: c.sub,
            }}
          >
            Loading…
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ background: c.bg, minHeight: "100vh", position: "relative" }}>
      {isGenerating ? (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(246,247,251,0.84)",
            backdropFilter: "blur(2px)",
            display: "grid",
            placeItems: "center",
            zIndex: 50,
            padding: 24,
          }}
        >
          <div
            style={{
              width: "min(460px, 100%)",
              background: c.card,
              border: `1px solid ${c.border}`,
              borderRadius: 24,
              padding: 24,
              boxShadow: "0 10px 30px rgba(15,23,42,0.08)",
            }}
          >
            <div style={{ fontSize: 22, fontWeight: 700, color: c.black }}>Generating Excel pack</div>
            <div style={{ fontSize: 13, lineHeight: 1.6, color: c.sub, marginTop: 8 }}>
              Building the workbook, grouping activities, and preparing the cost sheets for download.
            </div>
            <div style={{ marginTop: 18, height: 10, borderRadius: 999, overflow: "hidden", background: c.lightGrey }}>
              <div
                style={{
                  width: `${generationProgress}%`,
                  height: "100%",
                  background: c.black,
                  transition: "width 650ms ease",
                }}
              />
            </div>
            <div
              style={{
                marginTop: 10,
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                gap: 12,
                fontSize: 12,
                color: c.sub,
                fontWeight: 650,
              }}
            >
              <span>{generationStage}</span>
              <span style={{ color: c.black }}>{Math.round(generationProgress)}% complete</span>
            </div>
          </div>
        </div>
      ) : null}
      <div style={{ padding: "22px 18px", maxWidth: 1280, margin: "0 auto" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: 20, alignItems: "start" }}>
          <div style={{ display: "grid", gap: 18 }}>
            <div
              style={{
                background: c.card,
                border: `1px solid ${c.border}`,
                borderRadius: 18,
                padding: 20,
              }}
            >
              <div style={{ fontSize: 12, color: c.sub, marginBottom: 6, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                {title ? `“${title}”` : "Working event"}
              </div>
              <div
                style={{
                  fontSize: 24,
                  fontWeight: 600,
                  color: c.black,
                  letterSpacing: -0.2,
                }}
              >
                Review
              </div>
              <div
                style={{
                  fontSize: 13,
                  color: c.sub,
                  marginTop: 6,
                  lineHeight: 1.55,
                  maxWidth: 760,
                }}
              >
                Sense-check the submission, confirm readiness and choose what goes into the final pack.
              </div>

              <div
                style={{
                  display: "flex",
                  gap: 10,
                  alignItems: "center",
                  flexWrap: "wrap",
                  marginTop: 12,
                }}
              >
                <span
                  style={{
                    padding: "6px 10px",
                    borderRadius: 999,
                    border: `1px solid ${badge.bd}`,
                    background: badge.bg,
                    color: badge.tx,
                    fontSize: 12,
                    fontWeight: 700,
                  }}
                >
                  {badge.label}
                </span>

                <span
                  style={{
                    padding: "6px 10px",
                    borderRadius: 999,
                    border: `1px solid ${c.border}`,
                    background: "#fff",
                    color: c.sub,
                    fontSize: 12,
                    fontWeight: 700,
                  }}
                >
                  Readiness: {readiness}%
                </span>
              </div>
            </div>

            {saveErr ? (
              <div
                style={{
                  background: c.redBg,
                  border: `1px solid ${c.redBorder}`,
                  color: c.redText,
                  padding: 12,
                  borderRadius: 14,
                  fontWeight: 700,
                  fontSize: 13,
                }}
              >
                {saveErr}
              </div>
            ) : null}

            <Card
              title="Submission readiness"
              hint="Commercial completeness check based on the current inputs."
            >
              <div
                style={{
                  border: `1px solid ${c.border}`,
                  borderRadius: 16,
                  padding: 16,
                  background: "#fff",
                }}
              >
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center" }}>
                    <div>
                      <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: 0.2, textTransform: "uppercase", color: c.sub }}>Readiness score</div>
                      <div style={{ fontSize: 28, fontWeight: 700, color: c.black, letterSpacing: -0.4, marginTop: 4 }}>{readiness}%</div>
                    </div>
                    <div
                      style={{
                        minWidth: 118,
                        padding: "8px 10px",
                        borderRadius: 999,
                        border: `1px solid ${blockers > 0 ? c.redBorder : warnings > 0 ? c.amberBorder : c.greenBorder}`,
                        background: blockers > 0 ? c.redBg : warnings > 0 ? c.amberBg : c.greenBg,
                        color: blockers > 0 ? c.redText : warnings > 0 ? c.amberText : c.greenText,
                        textAlign: "center",
                        fontSize: 12,
                        fontWeight: 700,
                      }}
                    >
                      {blockers > 0 ? "Needs attention" : warnings > 0 ? "Review advised" : "Ready to issue"}
                    </div>
                  </div>

                  <div
                    style={{
                      height: 8,
                      borderRadius: 999,
                      background: c.lightGrey,
                      overflow: "hidden",
                      marginTop: 14,
                    }}
                  >
                    <div
                      style={{
                        width: `${readiness}%`,
                        height: "100%",
                        borderRadius: 999,
                        background: blockers > 0 ? c.redBorder : warnings > 0 ? c.amberBorder : c.greenBorder,
                      }}
                    />
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 10, marginTop: 14 }}>
                    {[
                      ["Issues", String(blockers + warnings), blockers > 0 ? c.redText : warnings > 0 ? c.amberText : c.greenText, blockers > 0 ? c.redBg : warnings > 0 ? c.amberBg : c.greenBg, blockers > 0 ? c.redBorder : warnings > 0 ? c.amberBorder : c.greenBorder],
                      ["Estimated total", money(ceTotal), c.black, "#fff", c.border],
                      ["Status", getCommercialStatusLabel(commercialStatus), c.black, "#fff", c.border],
                    ].map(([label, value, color, bg, border]) => (
                      <div
                        key={String(label)}
                        style={{
                          border: `1px solid ${String(border)}`,
                          borderRadius: 14,
                          padding: 12,
                          background: String(bg),
                        }}
                      >
                        <div style={{ fontSize: 12, color: c.sub }}>{label}</div>
                        <div style={{ fontSize: 18, fontWeight: 700, color: String(color), marginTop: 6 }}>{value}</div>
                      </div>
                    ))}
                  </div>

                  <div style={{ marginTop: 14, display: "flex", justifyContent: "flex-start" }}>
                    <button
                      type="button"
                      onClick={() => setShowReadinessDetails((p) => !p)}
                      style={{
                        height: 38,
                        padding: "0 13px",
                        borderRadius: 12,
                        border: `1px solid ${c.border}`,
                        background: "#fff",
                        color: c.black,
                        fontSize: 13,
                        fontWeight: 700,
                        cursor: "pointer",
                        boxShadow: "0 1px 2px rgba(15,23,42,0.03)",
                      }}
                    >
                      {showReadinessDetails ? "Hide check" : "Run readiness check"}
                    </button>
                  </div>

                  {showReadinessDetails ? (
                    <div style={{ display: "grid", gap: 10, marginTop: 14 }}>
                      {checks
                        .filter((item) => item.status !== "pass")
                        .slice(0, 3)
                        .map((item) => (
                          <div
                            key={`${item.group}-${item.label}`}
                            style={{
                              border: `1px solid ${item.status === "missing" ? c.redBorder : c.amberBorder}`,
                              background: item.status === "missing" ? c.redBg : c.amberBg,
                              borderRadius: 14,
                              padding: 12,
                              fontSize: 13,
                              lineHeight: 1.5,
                              color: c.black,
                            }}
                          >
                            <strong>{item.label}</strong>
                            {item.detail ? <span style={{ color: c.sub }}> — {item.detail}</span> : null}
                          </div>
                        ))}
                      {checks.filter((item) => item.status !== "pass").length === 0 ? (
                        <div style={{ border: `1px solid ${c.greenBorder}`, background: c.greenBg, color: c.greenText, borderRadius: 14, padding: 12, fontSize: 13, fontWeight: 700 }}>
                          No obvious readiness issues. Generate the pack to produce the submission documents.
                        </div>
                      ) : null}
                      <div style={{ fontSize: 12, color: c.sub, lineHeight: 1.5 }}>
                        This check is intentionally brief: it identifies weakness areas only. Full wording, commercial argument and exportable narrative remain inside Generate Pack.
                      </div>
                    </div>
                  ) : null}
                </div>

            </Card>

            <Card
              title="Commercial pushback & defence"
              hint="Commercial pushback is generated when the pack is generated. It only appears here when the internal pushback option is selected in Pack contents."
            >
              <div style={{ display: "grid", gap: 10 }}>
                {generatedCommercialPushback.length > 0 ? (
                  generatedCommercialPushback.map((item) => (
                    <div key={`${item.heading}-${item.note}`} style={{ border: `1px solid ${c.border}`, borderRadius: 14, padding: 12, background: "#fff" }}>
                      <div style={{ fontSize: 13, fontWeight: 650, color: c.black }}>{item.heading}</div>
                      {item.note ? <div style={{ marginTop: 5, fontSize: 12.5, lineHeight: 1.55, color: c.sub }}>{item.note}</div> : null}
                    </div>
                  ))
                ) : hasGeneratedPack ? (
                  <div
                    style={{
                      border: `1px solid ${c.border}`,
                      borderRadius: 14,
                      padding: 14,
                      background: c.soft,
                    }}
                  >
                    <div style={{ fontSize: 13, fontWeight: 650, color: c.black }}>
                      Commercial pushback has not been generated for this view
                    </div>
                    <div style={{ marginTop: 6, fontSize: 12.5, lineHeight: 1.55, color: c.sub }}>
                      Select “Commercial pushback (internal)” in Pack contents, then generate the pack to show the AI-generated defence points here.
                    </div>
                  </div>
                ) : (
                  <div
                    style={{
                      border: `1px solid ${c.border}`,
                      borderRadius: 14,
                      padding: 14,
                      background: c.soft,
                    }}
                  >
                    <div style={{ fontSize: 13, fontWeight: 650, color: c.black }}>
                      Commercial pushback will appear here after generation
                    </div>
                    <div style={{ marginTop: 6, fontSize: 12.5, lineHeight: 1.55, color: c.sub }}>
                      The response is created when Generate Pack is pressed and stays internal unless the commercial pushback option is selected in Pack contents.
                    </div>
                  </div>
                )}
              </div>
            </Card>

            {showRebuttalPanel ? (
              <Card
                title="Rebuttal generator"
                hint="Use this after a CE is rejected or reduced. Paste the contractor response and generate a measured commercial reply. This stays internal until you copy or issue it."
              >
                <div style={{ display: "grid", gap: 14 }}>
                  {commercialStatus !== "rejected" ? (
                    <div style={{ border: `1px solid ${c.amberBorder}`, background: c.amberBg, color: c.amberText, borderRadius: 14, padding: 12, fontSize: 12.5, lineHeight: 1.5 }}>
                      This panel is available now, but it is normally used once the CE status is marked as Rejected in the CE register.
                    </div>
                  ) : null}

                  {rebuttalTableMissing ? (
                    <div style={{ border: `1px solid ${c.redBorder}`, background: c.redBg, color: c.redText, borderRadius: 14, padding: 12, fontSize: 12.5, lineHeight: 1.5, fontWeight: 650 }}>
                      Rebuttal storage is not installed yet. Run REBUTTAL_ENGINE_PATCH.sql in Supabase, then refresh this page.
                    </div>
                  ) : null}

                  <label style={{ display: "grid", gap: 7 }}>
                    <span style={{ fontSize: 12, fontWeight: 700, color: c.sub }}>Contractor rejection / assessment response</span>
                    <textarea
                      value={contractorResponse}
                      onChange={(e) => setContractorResponse(e.target.value)}
                      rows={6}
                      placeholder="Paste the contractor's rejection, assessment, or pay less reasoning here."
                      style={{
                        width: "100%",
                        border: `1px solid ${c.border}`,
                        borderRadius: 16,
                        padding: 12,
                        fontSize: 13.5,
                        lineHeight: 1.55,
                        resize: "vertical",
                        outline: "none",
                        color: c.black,
                        background: "#fff",
                      }}
                    />
                  </label>

                  {rebuttalErr ? (
                    <div style={{ border: `1px solid ${c.redBorder}`, background: c.redBg, color: c.redText, borderRadius: 14, padding: 12, fontSize: 12.5, fontWeight: 650 }}>
                      {rebuttalErr}
                    </div>
                  ) : null}

                  <div style={{ display: "flex", justifyContent: "space-between", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                    <div style={{ fontSize: 12, color: c.sub, lineHeight: 1.5 }}>
                      Uses the saved CE facts, evidence, valuation and the pasted contractor response. No new facts are invented.
                    </div>
                    <button
                      type="button"
                      disabled={isGeneratingRebuttal || rebuttalTableMissing}
                      onClick={handleGenerateRebuttal}
                      style={{
                        height: 40,
                        padding: "0 14px",
                        borderRadius: 12,
                        border: `1px solid ${isGeneratingRebuttal || rebuttalTableMissing ? c.border : c.black}`,
                        background: isGeneratingRebuttal || rebuttalTableMissing ? c.lightGrey : c.black,
                        color: isGeneratingRebuttal || rebuttalTableMissing ? c.sub : "#fff",
                        fontSize: 13,
                        fontWeight: 700,
                        cursor: isGeneratingRebuttal || rebuttalTableMissing ? "not-allowed" : "pointer",
                      }}
                    >
                      {isGeneratingRebuttal ? "Generating…" : generatedRebuttal ? "Regenerate rebuttal" : "Generate rebuttal"}
                    </button>
                  </div>

                  {generatedRebuttal ? (
                    <div style={{ border: `1px solid ${c.border}`, borderRadius: 16, background: c.soft, padding: 14, display: "grid", gap: 12 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "start" }}>
                        <div>
                          <div style={{ fontSize: 12, fontWeight: 700, color: c.sub, textTransform: "uppercase", letterSpacing: 0.45 }}>Generated rebuttal</div>
                          {generatedRebuttal.updated_at ? (
                            <div style={{ marginTop: 4, fontSize: 12, color: c.sub }}>Saved {formatRebuttalDate(generatedRebuttal.updated_at)}</div>
                          ) : null}
                        </div>
                        <button
                          type="button"
                          onClick={() => navigator.clipboard?.writeText(`${generatedRebuttal.rebuttal_subject}\n\n${generatedRebuttal.rebuttal_body}`)}
                          style={{ height: 34, border: `1px solid ${c.border}`, background: "#fff", borderRadius: 11, padding: "0 10px", fontSize: 12, fontWeight: 700, color: c.black, cursor: "pointer" }}
                        >
                          Copy
                        </button>
                      </div>

                      <div style={{ border: `1px solid ${c.border}`, borderRadius: 14, background: "#fff", padding: 12 }}>
                        <div style={{ fontSize: 12, color: c.sub, fontWeight: 700 }}>Subject</div>
                        <div style={{ marginTop: 5, fontSize: 13.5, color: c.black, fontWeight: 650 }}>{generatedRebuttal.rebuttal_subject}</div>
                      </div>

                      <div style={{ border: `1px solid ${c.border}`, borderRadius: 14, background: "#fff", padding: 12 }}>
                        <div style={{ fontSize: 12, color: c.sub, fontWeight: 700 }}>Response body</div>
                        <div style={{ marginTop: 7, whiteSpace: "pre-wrap", fontSize: 13.2, lineHeight: 1.65, color: c.black }}>{generatedRebuttal.rebuttal_body}</div>
                      </div>

                      {generatedRebuttal.key_points?.length ? (
                        <div style={{ display: "grid", gap: 7 }}>
                          {generatedRebuttal.key_points.slice(0, 5).map((point, index) => (
                            <div key={`${point}-${index}`} style={{ border: `1px solid ${c.border}`, borderRadius: 12, background: "#fff", padding: "9px 10px", fontSize: 12.5, color: c.sub, lineHeight: 1.45 }}>
                              {point}
                            </div>
                          ))}
                        </div>
                      ) : null}

                      {generatedRebuttal.risk_note ? (
                        <div style={{ border: `1px solid ${c.amberBorder}`, borderRadius: 14, background: c.amberBg, padding: 12, fontSize: 12.5, color: c.amberText, lineHeight: 1.5 }}>
                          {generatedRebuttal.risk_note}
                        </div>
                      ) : null}
                    </div>
                  ) : null}
                </div>
              </Card>
            ) : null}

            <Card
              title="Commercial summary"
              hint="This is the final commercial sense-check before you generate the pack."
            >
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
                  gap: 16,
                }}
              >
                <div
                  style={{
                    border: `1px solid ${c.border}`,
                    borderRadius: 14,
                    padding: 14,
                    background: "#fff",
                  }}
                >
                  <div style={{ display: "grid", gap: 10 }}>
                    <Row
                      label="Contract type"
                      value={contractLabel}
                    />
                    <Row
                      label="Contract source"
                      value={
                        contractSource === "standard_logic"
                          ? "Standard contract logic"
                          : contractSource === "upload_contract"
                          ? "Uploaded contract"
                          : "—"
                      }
                    />
                    <Row label="Contract family" value={contractFamily} />
                    <Row label="Draft template" value={draftTemplate.title} />
                    <Row label={costLabel} value={money(definedCost)} />
                    <Row label="Prelims (daily)" value={money(prelimsDaily)} />
                    <Row label="Delay days" value={`${delayDays}`} />
                  </div>
                </div>

                <div
                  style={{
                    border: `1px solid ${c.border}`,
                    borderRadius: 14,
                    padding: 14,
                    background: "#fff",
                  }}
                >
                  <div style={{ display: "grid", gap: 10 }}>
                    <Row label="Draft sections queued" value={`${draftTemplate.sections.length}`} />
                    <Row label="Prelims total" value={money(prelimsTotal)} />
                    <Row label={`Fee %`} value={`${valuation.fee_percent}%`} />
                    <Row
                      label="Fee basis"
                      value={feeBasisLabel}
                    />
                    <Row label="Fee amount" value={money(feeAmount)} />
                    <div style={{ height: 1, background: c.border, margin: "2px 0" }} />
                    <Row label="CE total" value={money(ceTotal)} strong />
                  </div>
                </div>
              </div>
              <div
                style={{
                  marginTop: 16,
                  border: `1px solid ${c.border}`,
                  borderRadius: 14,
                  padding: 14,
                  background: c.soft,
                }}
              >
                <div style={{ fontSize: 12, fontWeight: 700, color: c.black, marginBottom: 8 }}>
                  Draft sections queued
                </div>
                <div style={{ display: "grid", gap: 6 }}>
                  {draftTemplate.sections.map((section) => (
                    <div key={section.key} style={{ fontSize: 12, color: c.sub }}>• {section.label}</div>
                  ))}
                </div>
              </div>
            </Card>

            <Card
              title="Pack contents to generate"
              hint="Choose what should be included in the CE pack. These options can map into the same output under the hood later, but the user intent should be explicit now."
            >
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
                  gap: 12,
                }}
              >
                {[
                  ["include_basis", "Basis of Change narrative"],
                  ["include_entitlement", "Clause / entitlement reasoning"],
                  ["include_time_impact", "Time impact summary"],
                  ["include_evidence_register", "Evidence register"],
                  ["include_cost_summary", "Cost summary"],
                  ["include_prelims_fee", "Prelims + Fee summary"],
                  ["include_risk_notes", "Risk / qualification notes"],
                  ["include_commercial_pushback", "Commercial pushback (internal)"],
                  ["include_excel", "Excel workbook"],
                  ["include_pdf", "PDF pack"],
                ].map(([key, label]) => {
                  const checked = reviewSettings[key as keyof ReviewSettings] as boolean;
                  return (
                    <label
                      key={key}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 10,
                        border: `1px solid ${c.border}`,
                        borderRadius: 14,
                        padding: "12px 14px",
                        background: "#fff",
                        cursor: "pointer",
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={(e) =>
                          updateReview(key as keyof ReviewSettings, e.target.checked as any)
                        }
                      />
                      <span style={{ fontSize: 13, fontWeight: 600, color: c.black }}>{label}</span>
                    </label>
                  );
                })}
              </div>
            </Card>


            <Card
              title="Quality checks"
              hint="These checks tell you what is strong, what is weak, and what may undermine the final output."
            >
              <div style={{ display: "grid", gap: 14 }}>
                {[
                  ["Contract readiness", groupedChecks.contract],
                  ["Basis readiness", groupedChecks.basis],
                  ["Evidence readiness", groupedChecks.evidence],
                  ["Cost readiness", groupedChecks.cost],
                ].map(([heading, items]) => (
                  <div key={heading}>
                    <div
                      style={{
                        fontSize: 13,
                        fontWeight: 700,
                        color: c.black,
                        marginBottom: 10,
                      }}
                    >
                      {heading}
                    </div>

                    <div style={{ display: "grid", gap: 10 }}>
                      {(items as CheckItem[]).map((item) => {
                        const pill = statusPill(item.status);
                        return (
                          <div
                            key={`${heading}-${item.label}`}
                            style={{
                              border: `1px solid ${c.border}`,
                              borderRadius: 14,
                              padding: 12,
                              background: "#fff",
                              display: "flex",
                              justifyContent: "space-between",
                              gap: 14,
                              alignItems: "flex-start",
                            }}
                          >
                            <div style={{ minWidth: 0 }}>
                              <div
                                style={{
                                  fontSize: 13,
                                  fontWeight: 700,
                                  color: c.black,
                                }}
                              >
                                {item.label}
                              </div>
                              {item.detail ? (
                                <div
                                  style={{
                                    marginTop: 4,
                                    fontSize: 12,
                                    color: c.sub,
                                    lineHeight: 1.45,
                                  }}
                                >
                                  {item.detail}
                                </div>
                              ) : null}
                            </div>

                            <span
                              style={{
                                flexShrink: 0,
                                padding: "6px 10px",
                                borderRadius: 999,
                                border: `1px solid ${pill.bd}`,
                                background: pill.bg,
                                color: pill.tx,
                                fontSize: 12,
                                fontWeight: 700,
                              }}
                            >
                              {pill.label}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card
              title="Generation notes / qualifications"
              hint="Use this for reservations, assumptions, pending substantiation, limitations, or commercial wording you want reflected in the generated pack."
            >
              <Textarea
                rows={8}
                value={reviewSettings.qualifications_notes}
                onChange={(e) => updateReview("qualifications_notes", e.target.value)}
                placeholder="e.g. Programme impact remains subject to final accepted programme review. Valuation excludes unresolved downstream effects and any further instructed change not yet priced."
              />
            </Card>

            <Card
              title="Missing items / prompts"
              hint="These prompts highlight the gaps most likely to weaken your submission."
            >
              <div style={{ display: "grid", gap: 10 }}>
                {[
                  programmeCount === 0 && delayDays > 0
                    ? "Add at least one programme-support document because delay days are entered."
                    : null,
                  photosCount === 0
                    ? "Add photographic evidence if the change involved a physical restriction, condition or encountered issue."
                    : null,
                  basis.mitigation_summary.trim() === ""
                    ? "Add a mitigation note or explain why mitigation was not reasonably possible."
                    : null,
                  prelimLineCount === 0
                    ? "Review whether time-related prelims should be included."
                    : null,
                  contractSource === "upload_contract" && contractUploadCount === 0
                    ? "Upload the contract documents before generation."
                    : null,
                  reviewSettings.qualifications_notes.trim() === ""
                    ? "Consider adding qualifications / assumptions if anything remains subject to review."
                    : null,
                ]
                  .filter(Boolean)
                  .map((text) => (
                    <div
                      key={text}
                      style={{
                        border: `1px solid ${c.border}`,
                        borderRadius: 14,
                        padding: 12,
                        background: "#fff",
                        fontSize: 13,
                        color: c.sub,
                        lineHeight: 1.55,
                      }}
                    >
                      {text}
                    </div>
                  ))}

                {[
                  programmeCount === 0 && delayDays > 0
                    ? "Add at least one programme-support document because delay days are entered."
                    : null,
                  photosCount === 0
                    ? "Add photographic evidence if the change involved a physical restriction, condition or encountered issue."
                    : null,
                  basis.mitigation_summary.trim() === ""
                    ? "Add a mitigation note or explain why mitigation was not reasonably possible."
                    : null,
                  prelimLineCount === 0
                    ? "Review whether time-related prelims should be included."
                    : null,
                  contractSource === "upload_contract" && contractUploadCount === 0
                    ? "Upload the contract documents before generation."
                    : null,
                  reviewSettings.qualifications_notes.trim() === ""
                    ? "Consider adding qualifications / assumptions if anything remains subject to review."
                    : null,
                ].filter(Boolean).length === 0 ? (
                  <div
                    style={{
                      border: `1px solid ${c.greenBorder}`,
                      background: c.greenBg,
                      color: c.greenText,
                      borderRadius: 14,
                      padding: 12,
                      fontSize: 13,
                      fontWeight: 700,
                    }}
                  >
                    No obvious prompts at this stage. The pack looks commercially well-prepared.
                  </div>
                ) : null}
              </div>
            </Card>
          </div>

          <div
            style={{
              position: "sticky",
              top: 20,
              alignSelf: "start",
              display: "flex",
              flexDirection: "column",
              gap: 14,
            }}
          >
            <div
              style={{
                background: c.card,
                border: `1px solid ${c.border}`,
                borderRadius: 18,
                padding: 12,
              }}
            >
              <CEProgress eventId={eventId} currentStep="review" />
            </div>

            <SidebarCard title="Guidance">
              <div style={{ display: "grid", gap: 10 }}>
                <div>Review is your final commercial check before generation.</div>
                <div>Missing inputs reduce narrative quality and clause confidence.</div>
                <div>Generation uses deterministic totals only.</div>
                <div>Commercial pushback lets you surface likely challenge points before issue.</div>
                <div>Contract choice affects entitlement wording and clause references.</div>
                {lastSavedAt ? (
                  <div>Last saved at {new Date(lastSavedAt).toLocaleTimeString()}</div>
                ) : (
                  <div>Changes save automatically shortly after you stop typing.</div>
                )}
              </div>
            </SidebarCard>

            <SidebarCard title="Generate pack">
              <div style={{ display: "grid", gap: 10 }}>
                <div
                  style={{
                    border: `1px solid ${c.border}`,
                    borderRadius: 14,
                    padding: 12,
                    background: "#fff",
                  }}
                >
                  <div style={{ display: "grid", gap: 8 }}>
                    <Row label="Readiness" value={`${readiness}%`} />
                    <Row label="Blockers" value={String(blockers)} />
                    <Row label="Warnings" value={String(warnings)} />
                  </div>
                </div>

                <div
                  style={{
                    border: `1px solid ${c.border}`,
                    borderRadius: 14,
                    padding: 12,
                    background: "#fff",
                  }}
                >
                  <div style={{ fontSize: 12, fontWeight: 700, color: c.black, marginBottom: 8 }}>Selected outputs</div>
                  <div style={{ display: "grid", gap: 6 }}>
                    {[
                      reviewSettings.include_pdf ? "PDF" : null,
                      reviewSettings.include_excel ? "Excel" : null,
                      reviewSettings.include_basis ? "Basis" : null,
                      reviewSettings.include_entitlement ? "Entitlement" : null,
                      reviewSettings.include_time_impact ? "Time impact" : null,
                      reviewSettings.include_evidence_register ? "Evidence" : null,
                      reviewSettings.include_prelims_fee ? "Prelims + fee" : null,
                      reviewSettings.include_commercial_pushback ? "Commercial pushback" : null,
                    ].filter(Boolean).map((item) => (
                      <div key={String(item)} style={{ fontSize: 12, color: c.sub }}>• {item}</div>
                    ))}
                  </div>
                </div>

                <div style={{ fontSize: 12, color: c.amberText, background: c.amberBg, border: `1px solid ${c.amberBorder}`, borderRadius: 12, padding: 10 }}>
                  Testing mode: Download Pack will also download the AI payload JSON for prompt validation.
                </div>

                <button
                  onClick={handleGeneratePack}
                  disabled={generateDisabled}
                  style={{
                    width: "100%",
                    background: c.black,
                    color: "#fff",
                    padding: "12px",
                    borderRadius: 12,
                    fontWeight: 700,
                    border: "none",
                    cursor: generateDisabled ? "not-allowed" : "pointer",
                    opacity: generateDisabled ? 0.6 : 1,
                  }}
                >
                  {generateButtonLabel}
                </button>

                {generationCreditLocked ? (
                  <div style={{ fontSize: 12, color: c.redText, background: c.redBg, border: `1px solid ${c.redBorder}`, borderRadius: 12, padding: 10 }}>
                    You have no credits remaining. Open Billing to upgrade or buy additional credits before generating another pack.
                  </div>
                ) : null}

                {forceGenerateMode ? (
                  <div style={{ fontSize: 12, color: c.blueText, background: c.blueBg, border: `1px solid ${c.blueBorder}`, borderRadius: 12, padding: 10 }}>
                    Force Generate is on. This event will keep showing Generate pack during testing.
                  </div>
                ) : null}

                <SmallBtn onClick={() => router.push(`/app/event/${eventId}/prelims`)}>
                  Back to prelims
                </SmallBtn>

                <SmallBtn
                  onClick={() => router.push(`/app`)}
                  style={{ background: c.lightGrey }}
                >
                  Back to dashboard
                </SmallBtn>

                {blockers > 0 ? (
                  <div
                    style={{
                      border: `1px solid ${c.redBorder}`,
                      background: c.redBg,
                      color: c.redText,
                      borderRadius: 14,
                      padding: 12,
                      fontSize: 12,
                      fontWeight: 700,
                    }}
                  >
                    Resolve the blocker items in Quality checks before generating the pack.
                  </div>
                ) : null}
              </div>
            </SidebarCard>
          </div>
        </div>
      </div>
    </div>
  );
}
