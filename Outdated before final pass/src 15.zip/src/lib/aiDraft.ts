export type AiDraftSections = {
  background: string;
  change_to_contract_basis: string;
  effect_on_defined_cost: string;
  effect_on_programme: string;
  commercial_impact: string;
  contractual_position: string;
  assumptions: string;
  risks_and_qualifications: string;
  conclusion: string;
};

export type CommercialPushbackItem = {
  likely_challenge: string;
  defence_position: string;
};

export type InternalCommercialIntelligence = {
  commercial_pushback: CommercialPushbackItem[];
  evidence_gaps: string[];
  strength_summary: string;
  internal_risk_notes: string[];
};

export type AiDraftResponse = AiDraftSections & {
  client_output?: AiDraftSections;
  internal_commercial_intelligence?: InternalCommercialIntelligence;
  commercial_pushback?: CommercialPushbackItem[];
  evidence_gaps?: string[];
  strength_summary?: string;
  internal_risk_notes?: string[];
};

export const AI_DRAFT_REQUIRED_KEYS: Array<keyof AiDraftSections> = [
  "background",
  "change_to_contract_basis",
  "effect_on_defined_cost",
  "effect_on_programme",
  "commercial_impact",
  "contractual_position",
  "assumptions",
  "risks_and_qualifications",
  "conclusion",
];

export const COMMERCIAL_COPILOT_DRAFT_PROMPT = `You are Commercial Co-Pilot, a senior UK construction commercial manager specialising in NEC and JCT contracts.

Your role is to produce a detailed, submission-ready Compensation Event / claim draft using all provided project, contract, and event data.

You must think like an experienced Quantity Surveyor and commercial manager preparing a formal submission.

----------------------------------------
STRICT OUTPUT RULES
----------------------------------------

- Return JSON only.
- Do not use markdown.
- Do not wrap the JSON in backticks.
- Do not include commentary before or after the JSON.
- Do not invent facts.
- Only use the facts provided.
- If information is missing, explicitly state the limitation in the relevant section.
- Do not alter any monetary values.
- Do not perform calculations.
- Use the provided totals exactly as given.
- Use professional UK commercial / QS language.
- Write in a clear, structured, submission-ready tone.

----------------------------------------
CONTRACT AWARENESS
----------------------------------------

You must analyse:
- the selected contract family (NEC or JCT)
- the contract form (e.g. NEC4 ECS Option B)
- any uploaded contract text (including amendments)

You must:

- Consider the full contract context when determining entitlement
- Identify relevant clauses where the event facts clearly support them
- Only reference clauses that are consistent with:
  - the contract form
  - the event facts
  - the contract text (if provided)

Do NOT:
- invent clauses
- guess clause numbers without clear justification
- quote clause wording unless it exists in the provided contract text
- present clause summaries as exact contractual wording

If clause applicability is uncertain:
- reference it cautiously OR
- place it under risks and qualifications

----------------------------------------
CLAUSE HANDLING RULES
----------------------------------------

- Use high-level clause references (e.g. "Clause 60.1(2)")
- Where referencing a clause, provide a brief, accurate summary of its intent in plain language
- The summary must:
  - reflect the general meaning of the clause
  - be consistent with the contract form selected
  - be directly relevant to the event facts

Do NOT:
- quote clause wording unless it exists in the provided contract text
- invent or fabricate clause wording
- provide overly detailed legal explanations
- reference clauses that are not clearly supported by the facts

If the clause application is uncertain:
- either qualify the reference clearly, OR
- include it within risks_and_qualifications instead of the main contractual_position

----------------------------------------
REASONING APPROACH
----------------------------------------

You must:

1. Understand the event
2. Compare it to the planned contract basis
3. Identify the contractual mechanism
4. Assess programme impact
5. Assess Defined Cost (NEC) or Loss and Expense (JCT) impact
6. Form a commercially sound entitlement position
7. Highlight risks, assumptions, and evidential gaps

----------------------------------------
OUTPUT STRUCTURE (MUST MATCH EXACTLY)
----------------------------------------

Return one JSON object with two separate parts:

{
  "client_output": {
    "background": "",
    "change_to_contract_basis": "",
    "effect_on_defined_cost": "",
    "effect_on_programme": "",
    "commercial_impact": "",
    "contractual_position": "",
    "assumptions": "",
    "risks_and_qualifications": "",
    "conclusion": ""
  },
  "internal_commercial_intelligence": {
    "commercial_pushback": [
      {
        "likely_challenge": "",
        "defence_position": ""
      }
    ],
    "evidence_gaps": [],
    "strength_summary": "",
    "internal_risk_notes": []
  }
}

client_output is the only client-facing output.
internal_commercial_intelligence is internal only and must never be treated as Excel/client submission content.

----------------------------------------
SECTION GUIDANCE
----------------------------------------

background:
- factual context of the project and event
- no argument, just setting the scene

change_to_contract_basis:
- clearly explain how the works differ from what was planned/tendered
- link to contract expectations

effect_on_defined_cost:
- explain HOW cost increased (not calculations)
- include labour, plant, prelims, disruption, inefficiency
- use NEC "Defined Cost" terminology where applicable
- if JCT, use "Loss and Expense" terminology instead

effect_on_programme:
- explain delay, disruption, and sequence impact
- refer to delay days if provided
- do not assume critical path unless supported

commercial_impact:
- summarise cost impact using provided figures
- reinforce that costs arise directly from the event

contractual_position:
- provide the strongest commercial entitlement argument
- clearly link facts → contract → entitlement
- reference relevant clauses where appropriate
- include a brief plain-language explanation of clause intent where used

assumptions:
- clearly state assumptions made due to missing or unclear data

risks_and_qualifications:
- highlight:
  - missing or weak evidence
  - uncertainty in clause applicability
  - potential contractor/employer challenges
  - inconsistencies in the provided data

conclusion:
- concise commercial summary
- restate entitlement and impact clearly

internal_commercial_intelligence:
- identify likely contractor challenges before submission
- provide concise defence positions based only on the provided facts
- flag evidence gaps and internal risk notes clearly
- keep this internal, commercially useful, and separate from client_output
- do not include any new facts, invented causation, or unsupported programme/cost assertions

----------------------------------------
DATA USAGE RULES
----------------------------------------

You must use:

- all event data provided
- all evidence references
- all commercial figures
- programme impacts
- mitigation steps
- contract information
- company_profile as the authoritative source for the submitting party identity

Do not ignore any provided data.
Do not infer or invent company names, trading names, addresses, logos or roles. If company_profile is blank or incomplete, state that limitation rather than using a hardcoded or assumed identity.

----------------------------------------
FINAL INSTRUCTION
----------------------------------------

Before returning the final JSON, internally check:
- all outputs are consistent with the CE facts
- no made-up facts have been introduced
- cost/programme statements align with provided data
- contractual position is cautious and not overclaimed
- internal commercial pushback is separate from client-facing output
- final JSON is valid and parseable
- all descriptions accurately reflect the underlying facts without reversing, overstating, or misinterpreting what actually occurred

Produce a detailed, commercially sound, contract-aware draft suitable for submission.

Return JSON only.`;

function cleanStringArray(value: unknown, max = 10) {
  return Array.isArray(value)
    ? value.map((item) => String(item || "").trim()).filter(Boolean).slice(0, max)
    : [];
}

function cleanCommercialPushback(value: unknown): CommercialPushbackItem[] {
  if (!Array.isArray(value)) return [];
  return value
    .map((item: any) => {
      const likely_challenge = String(
        item?.likely_challenge ?? item?.challenge ?? item?.heading ?? item?.issue ?? ""
      ).trim();
      const defence_position = String(
        item?.defence_position ?? item?.defence ?? item?.defence_note ?? item?.note ?? item?.response ?? ""
      ).trim();
      return { likely_challenge, defence_position };
    })
    .filter((item) => item.likely_challenge || item.defence_position)
    .slice(0, 6);
}

export function validateAiDraft(value: any): AiDraftResponse {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error("AI response was not a JSON object.");
  }

  const source = value.client_output && typeof value.client_output === "object" ? value.client_output : value;
  const cleaned: Partial<AiDraftResponse> = {};

  for (const key of AI_DRAFT_REQUIRED_KEYS) {
    const raw = source[key];
    if (typeof raw !== "string") {
      throw new Error(`AI response missing required string key: ${key}`);
    }
    cleaned[key] = raw.trim();
  }

  const internalSource =
    value.internal_commercial_intelligence && typeof value.internal_commercial_intelligence === "object"
      ? value.internal_commercial_intelligence
      : value;

  const internal: InternalCommercialIntelligence = {
    commercial_pushback: cleanCommercialPushback(internalSource.commercial_pushback),
    evidence_gaps: cleanStringArray(internalSource.evidence_gaps, 8),
    strength_summary: String(internalSource.strength_summary || "").trim(),
    internal_risk_notes: cleanStringArray(internalSource.internal_risk_notes, 8),
  };

  cleaned.client_output = cleaned as AiDraftSections;
  cleaned.internal_commercial_intelligence = internal;
  cleaned.commercial_pushback = internal.commercial_pushback;
  cleaned.evidence_gaps = internal.evidence_gaps;
  cleaned.strength_summary = internal.strength_summary;
  cleaned.internal_risk_notes = internal.internal_risk_notes;

  return cleaned as AiDraftResponse;
}

function extractJsonText(content: string) {
  const trimmed = String(content || "").trim();
  if (!trimmed) throw new Error("AI response was empty.");
  if (trimmed.startsWith("```")) {
    return trimmed.replace(/^```(?:json)?\s*/i, "").replace(/```$/i, "").trim();
  }
  return trimmed;
}

export function parseAiDraftJson(content: string) {
  const jsonText = extractJsonText(content);
  return validateAiDraft(JSON.parse(jsonText));
}

export async function generateAiDraftFromPayload(payload: any) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error("OPENAI_API_KEY is not configured.");
  }
  const model = process.env.OPENAI_MODEL || "gpt-4o";
  const userContent = [
    "Generate the claim draft from this application payload.",
    "Use the payload as the source of truth.",
    "Payload JSON:",
    JSON.stringify(payload, null, 2),
  ].join("\n\n");

  async function callOpenAi(extraInstruction?: string) {
    const messages = [
      { role: "system", content: COMMERCIAL_COPILOT_DRAFT_PROMPT },
      { role: "user", content: extraInstruction ? `${extraInstruction}\n\n${userContent}` : userContent },
    ];
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages,
        temperature: 0.2,
        response_format: { type: "json_object" },
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const message = data?.error?.message || `OpenAI request failed with status ${res.status}`;
      throw new Error(message);
    }
    const content = data?.choices?.[0]?.message?.content;
    if (typeof content !== "string") {
      throw new Error("OpenAI did not return text content.");
    }
    return parseAiDraftJson(content);
  }

  try {
    return await callOpenAi();
  } catch (firstError: any) {
    console.warn("AI draft validation failed once, retrying:", firstError?.message || firstError);
    return await callOpenAi("Your previous output failed validation. Return valid JSON only with client_output and internal_commercial_intelligence. client_output must contain exactly the required string keys. No markdown.");
  }
}

export type AiRebuttalDraft = {
  rebuttal_subject: string;
  rebuttal_summary: string;
  key_response_points: string[];
  commercial_position: string;
  requested_action: string;
  email_ready_response: string;
  rebuttal_body: string;
  key_points: string[];
  risk_note: string;
};

export function validateAiRebuttal(value: any): AiRebuttalDraft {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error("AI rebuttal response was not a JSON object.");
  }

  const subject = String(value.rebuttal_subject || "").trim();
  const rebuttal_summary = String(value.rebuttal_summary || "").trim();
  const key_response_points = cleanStringArray(value.key_response_points ?? value.key_points, 6);
  const commercial_position = String(value.commercial_position || "").trim();
  const requested_action = String(value.requested_action || "").trim();
  const email_ready_response = String(value.email_ready_response || value.rebuttal_body || "").trim();
  const riskNote = String(value.risk_note || value.risks_and_qualifications || "").trim();

  if (!subject || !email_ready_response) {
    throw new Error("AI rebuttal response missing subject or email_ready_response.");
  }

  return {
    rebuttal_subject: subject,
    rebuttal_summary,
    key_response_points,
    commercial_position,
    requested_action,
    email_ready_response,
    rebuttal_body: email_ready_response,
    key_points: key_response_points,
    risk_note: riskNote,
  };
}

export function parseAiRebuttalJson(content: string) {
  const jsonText = extractJsonText(content);
  return validateAiRebuttal(JSON.parse(jsonText));
}

export const COMMERCIAL_COPILOT_REBUTTAL_PROMPT = `You are Commercial Co-Pilot, a senior UK construction commercial manager specialising in NEC and JCT subcontract commercial responses.

Your role is to generate a concise, professional rebuttal to a contractor rejection or assessment response.

STRICT OUTPUT RULES:
- Return JSON only.
- Do not use markdown.
- Do not wrap the JSON in backticks.
- Do not include commentary before or after the JSON.
- Do not invent facts.
- Only use the CE facts, uploaded event data, generated pack context and contractor response provided.
- Do not alter monetary values.
- Do not perform calculations.
- Use professional UK QS / commercial language.
- The rebuttal must be suitable to paste into an email, but it must remain factual and commercially measured.
- Do not make aggressive legal threats.
- Where evidence is missing, qualify the position clearly rather than pretending certainty.

CONTRACT HANDLING:
- Reference clauses only where clearly supported by the selected contract form or uploaded contract context.
- Do not invent clause numbers or quote wording unless provided in the payload.
- If clause applicability is uncertain, keep the argument principle-based and flag uncertainty in risk_note.

OUTPUT STRUCTURE:
{
  "rebuttal_subject": "",
  "rebuttal_summary": "",
  "key_response_points": [""],
  "commercial_position": "",
  "requested_action": "",
  "email_ready_response": "",
  "risk_note": ""
}

REBUTTAL CONTEXT RULES:
- Treat generated_pack_output as the established CE submission position.
- Treat internal_commercial_intelligence and commercial_pushback as internal defence material only.
- Respond directly to the contractor position.
- Reinforce entitlement using the provided CE facts, generated pack output and saved commercial pushback.
- Do not introduce new facts.
- Remain commercially firm but professional.
- Avoid overclaiming.
- Structure clearly for email use.

REBUTTAL BODY STYLE:
- Start by acknowledging the contractor's position.
- State why the rejection/assessment is not accepted.
- Link the response back to the facts and commercial impact.
- Use concise paragraphs.
- End with a clear request for reassessment / confirmation.
- Do not include placeholders like [insert date].`;

export async function generateAiRebuttalFromPayload(payload: any, contractorResponse: string) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error("OPENAI_API_KEY is not configured.");
  }
  const model = process.env.OPENAI_MODEL || "gpt-4o";
  const userContent = [
    "Generate a contractor-response rebuttal from this CE payload and contractor rejection/assessment response.",
    "Use the payload, generated pack output, saved commercial pushback and contractor response as the only source of truth.",
    "Contractor response:",
    contractorResponse,
    "CE payload JSON:",
    JSON.stringify(payload, null, 2),
  ].join("\n\n");

  async function callOpenAi(extraInstruction?: string) {
    const messages = [
      { role: "system", content: COMMERCIAL_COPILOT_REBUTTAL_PROMPT },
      { role: "user", content: extraInstruction ? `${extraInstruction}\n\n${userContent}` : userContent },
    ];
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages,
        temperature: 0.2,
        response_format: { type: "json_object" },
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const message = data?.error?.message || `OpenAI request failed with status ${res.status}`;
      throw new Error(message);
    }
    const content = data?.choices?.[0]?.message?.content;
    if (typeof content !== "string") {
      throw new Error("OpenAI did not return text content.");
    }
    return parseAiRebuttalJson(content);
  }

  try {
    return await callOpenAi();
  } catch (firstError: any) {
    console.warn("AI rebuttal validation failed once, retrying:", firstError?.message || firstError);
    return await callOpenAi("Your previous output failed validation. Return valid JSON only with exactly the required keys and no markdown.");
  }
}
