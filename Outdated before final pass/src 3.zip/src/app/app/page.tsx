"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { supabaseBrowser } from "@/lib/supabase/client";
import { getContractLabel } from "@/lib/contracts";
import { readFinalTotal, recalculateEventFinancialSummary } from "@/lib/financialSummary";
import { getRequiredUser, isAuthErrorMessage } from "@/lib/security";
import {
  COMMERCIAL_STATUS_OPTIONS,
  PAYMENT_STATUS_OPTIONS,
  calculateTimeRisk,
  formatDateShort,
  getCommercialStatusLabel,
  getDefaultNoticePeriodDays,
  normaliseCommercialStatus,
} from "@/lib/commercialControl";

type EventRow = {
  id: string;
  title: string | null;
  status: string | null;
  created_at?: string | null;
  contract_type?: string | null;
  project_name?: string | null;
  main_contractor?: string | null;
  event_date?: string | null;
  notice_period_days?: number | null;
  notification_deadline?: string | null;
  payment_status?: string | null;
  event_financial_summary?: unknown;
};

type DashboardAction = {
  id: string;
  eventId: string;
  severity: 1 | 2 | 3 | 4;
  eyebrow: string;
  title: string;
  detail: string;
  value: number | null;
  href: string;
  cta: string;
  tone: "red" | "amber" | "blue" | "neutral";
};

type EventValueMap = Record<string, number | null>;

const c = {
  bg: "#f6f7fb",
  card: "#ffffff",
  border: "#e5e7eb",
  borderStrong: "#d7dce5",
  sub: "#475569",
  text: "#111827",
  black: "#111827",
  soft: "#f8fafc",
  redBg: "#fef2f2",
  redBd: "#fecaca",
  redTx: "#991b1b",
  greenBg: "#ecfdf5",
  greenBd: "#a7f3d0",
  greenTx: "#065f46",
  amberBg: "#fffbeb",
  amberBd: "#fde68a",
  amberTx: "#92400e",
  blueBg: "#eff6ff",
  blueBd: "#bfdbfe",
  blueTx: "#1d4ed8",
};

function money(v: number) {
  return new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency: "GBP",
    maximumFractionDigits: 0,
  }).format(Number.isFinite(v) ? v : 0);
}

function fullMoney(v: number) {
  return new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency: "GBP",
    maximumFractionDigits: 2,
  }).format(Number.isFinite(v) ? v : 0);
}

function niceDate(v?: string | null) {
  return formatDateShort(v);
}

function projectContext(e: EventRow) {
  const project = e.project_name?.trim();
  const contractor = e.main_contractor?.trim();
  if (project && contractor) return `${project} — ${contractor}`;
  if (project) return project;
  if (contractor) return contractor;
  return "Project not set";
}


function getPaymentStatusLabel(status?: string | null) {
  return PAYMENT_STATUS_OPTIONS.find((o) => o.value === status)?.label || "Not applied";
}

function statusTone(status?: string | null) {
  const s = normaliseCommercialStatus(status);
  if (s === "paid" || s === "accepted" || s === "complete") return { bg: c.greenBg, bd: c.greenBd, tx: c.greenTx };
  if (s === "submitted") return { bg: c.blueBg, bd: c.blueBd, tx: c.blueTx };
  if (s === "rejected") return { bg: c.redBg, bd: c.redBd, tx: c.redTx };
  if (s === "review" || s === "ready") return { bg: c.amberBg, bd: c.amberBd, tx: c.amberTx };
  return { bg: "#fff", bd: c.border, tx: c.sub };
}

function actionTone(tone: DashboardAction["tone"]) {
  if (tone === "red") return { bg: c.redBg, bd: c.redBd, tx: c.redTx };
  if (tone === "amber") return { bg: c.amberBg, bd: c.amberBd, tx: c.amberTx };
  if (tone === "blue") return { bg: c.blueBg, bd: c.blueBd, tx: c.blueTx };
  return { bg: "#fff", bd: c.border, tx: c.sub };
}

function SectionCard({ title, hint, children }: { title: string; hint?: string; children: React.ReactNode }) {
  return (
    <section
      style={{
        background: c.card,
        border: `1px solid ${c.border}`,
        borderRadius: 28,
        padding: 24,
        boxShadow: "0 1px 2px rgba(15,23,42,0.03)",
      }}
    >
      <div style={{ display: "grid", gap: 6, marginBottom: 18 }}>
        <div style={{ fontSize: 17, lineHeight: 1.2, fontWeight: 800, color: c.text, letterSpacing: -0.3 }}>{title}</div>
        {hint ? <div style={{ fontSize: 13, lineHeight: 1.55, color: c.sub, maxWidth: 760 }}>{hint}</div> : null}
      </div>
      {children}
    </section>
  );
}

function MetricCard({ label, value, hint, tone = "default" }: { label: string; value: React.ReactNode; hint?: string; tone?: "default" | "red" | "amber" | "blue" | "green" }) {
  const toneMap =
    tone === "red"
      ? { bg: c.redBg, bd: c.redBd }
      : tone === "amber"
      ? { bg: c.amberBg, bd: c.amberBd }
      : tone === "blue"
      ? { bg: c.blueBg, bd: c.blueBd }
      : tone === "green"
      ? { bg: c.greenBg, bd: c.greenBd }
      : { bg: "#fff", bd: c.border };

  return (
    <div
      style={{
        background: toneMap.bg,
        border: `1px solid ${toneMap.bd}`,
        borderRadius: 22,
        padding: 20,
        minHeight: 132,
        display: "grid",
        alignContent: "space-between",
        gap: 14,
      }}
    >
      <div style={{ fontSize: 11, fontWeight: 800, color: c.sub, textTransform: "uppercase", letterSpacing: 0.6 }}>{label}</div>
      <div style={{ display: "grid", gap: 7 }}>
        <div style={{ fontSize: 30, fontWeight: 800, color: c.text, letterSpacing: -0.9, lineHeight: 0.95 }}>{value}</div>
        {hint ? <div style={{ fontSize: 12, lineHeight: 1.45, color: c.sub }}>{hint}</div> : null}
      </div>
    </div>
  );
}

function QuietButton({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link href={href} style={{ textDecoration: "none" }}>
      <button
        style={{
          height: 46,
          padding: "0 15px",
          borderRadius: 15,
          border: `1px solid ${c.border}`,
          background: "#fff",
          color: c.text,
          fontWeight: 700,
          fontSize: 14,
          cursor: "pointer",
        }}
      >
        {children}
      </button>
    </Link>
  );
}

function EmptyState() {
  return (
    <div
      style={{
        border: `1px dashed ${c.borderStrong}`,
        borderRadius: 22,
        padding: 28,
        background: c.soft,
        textAlign: "center",
        display: "grid",
        gap: 10,
        justifyItems: "center",
      }}
    >
      <div style={{ fontSize: 18, fontWeight: 800, color: c.black }}>No live actions yet</div>
      <div style={{ fontSize: 13, lineHeight: 1.55, color: c.sub, maxWidth: 520 }}>
        Create a CE, add the event date and value, then this dashboard will surface the commercial actions that need attention.
      </div>
      <QuietButton href="/app/new">Create first CE</QuietButton>
    </div>
  );
}

export default function AppHome() {
  const [events, setEvents] = useState<EventRow[]>([]);
  const [eventValues, setEventValues] = useState<EventValueMap>({});
  const [loading, setLoading] = useState(true);
  const [showAll, setShowAll] = useState(false);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [renameSavingId, setRenameSavingId] = useState<string | null>(null);

  useEffect(() => {
    let active = true;

    (async () => {
      const supabase = supabaseBrowser();

      try {
        const user = await getRequiredUser(supabase);
        const primary = await supabase
          .from("events")
          .select("id,title,status,created_at,contract_type,project_name,main_contractor,event_date,notice_period_days,notification_deadline,payment_status,event_financial_summary")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false });

        let rows = primary.data;

        if (primary.error) {
          const message = String(primary.error.message || "");
          const missingOptionalColumn = /event_date|notice_period_days|notification_deadline|payment_status|event_financial_summary/i.test(message);
          if (!missingOptionalColumn) throw primary.error;

          const fallback = await supabase
            .from("events")
            .select("id,title,status,created_at,contract_type,project_name,main_contractor")
            .eq("user_id", user.id)
            .order("created_at", { ascending: false });
          if (fallback.error) throw fallback.error;
          rows = fallback.data;
        }

        if (!active) return;
        const eventRows = (rows ?? []) as EventRow[];
        setEvents(eventRows);

        const values: EventValueMap = {};
        for (const event of eventRows) {
          const savedTotal = readFinalTotal(event.event_financial_summary);
          if (savedTotal !== null) {
            values[event.id] = savedTotal;
            continue;
          }

          try {
            const summary = await recalculateEventFinancialSummary(supabase, event.id, user.id);
            values[event.id] = summary.final_total;
          } catch (summaryError) {
            console.warn("Could not calculate CE value for dashboard", event.id, summaryError);
            values[event.id] = null;
          }
        }
        setEventValues(values);
      } catch (e: any) {
        if (isAuthErrorMessage(e?.message)) {
          window.location.href = "/login";
          return;
        }
        console.error("Failed to load commercial dashboard", e);
      } finally {
        if (active) setLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, []);

  const enriched = useMemo(() => {
    return events.map((event) => {
      const value = eventValues[event.id] ?? null;
      const status = normaliseCommercialStatus(event.status);
      const noticePeriodDays = event.notice_period_days ?? getDefaultNoticePeriodDays(event.contract_type);
      const timeRisk = calculateTimeRisk({
        eventDate: event.event_date ?? null,
        noticePeriodDays,
        notificationDeadline: event.notification_deadline ?? null,
      });
      return { event, value, status, timeRisk };
    });
  }, [events, eventValues]);

  const metrics = useMemo(() => {
    let totalValue = 0;
    let atRisk = 0;
    let unpaid = 0;
    let notSubmitted = 0;

    for (const row of enriched) {
      const value = row.value ?? 0;
      totalValue += value;

      if (row.timeRisk.state === "overdue" || row.timeRisk.state === "due_soon") atRisk += value;
      if (["draft", "review", "ready"].includes(row.status)) notSubmitted += value;
      if (["submitted", "accepted"].includes(row.status) && row.event.payment_status !== "paid") unpaid += value;
    }

    return { totalValue, atRisk, unpaid, notSubmitted };
  }, [enriched]);

  const actions = useMemo<DashboardAction[]>(() => {
    const items: DashboardAction[] = [];

    for (const row of enriched) {
      const title = row.event.title || "Untitled CE";
      const value = row.value;
      if (row.timeRisk.state === "overdue") {
        items.push({
          id: `${row.event.id}-time-overdue`,
          eventId: row.event.id,
          severity: 1,
          eyebrow: "Time bar risk",
          title,
          detail: `${row.timeRisk.detail} ${row.timeRisk.deadline ? `Deadline ${formatDateShort(row.timeRisk.deadline)}.` : ""}`,
          value,
          href: `/app/event/${row.event.id}`,
          cta: "Open event",
          tone: "red",
        });
      } else if (row.timeRisk.state === "due_soon") {
        items.push({
          id: `${row.event.id}-time-soon`,
          eventId: row.event.id,
          severity: 2,
          eyebrow: "Notice deadline",
          title,
          detail: `${row.timeRisk.label}. ${row.timeRisk.deadline ? `Deadline ${formatDateShort(row.timeRisk.deadline)}.` : ""}`,
          value,
          href: `/app/event/${row.event.id}`,
          cta: "Review now",
          tone: "amber",
        });
      }

      if (row.status === "rejected") {
        items.push({
          id: `${row.event.id}-rejected`,
          eventId: row.event.id,
          severity: 1,
          eyebrow: "Rejected CE",
          title,
          detail: "Generate rebuttal should be the next commercial action once the contractor response is uploaded.",
          value,
          href: `/app/event/${row.event.id}/review`,
          cta: "Open review",
          tone: "red",
        });
      }

      if (["draft", "review", "ready"].includes(row.status) && value && value > 0) {
        items.push({
          id: `${row.event.id}-not-submitted`,
          eventId: row.event.id,
          severity: row.status === "ready" ? 2 : 3,
          eyebrow: row.status === "ready" ? "Ready to submit" : "Not submitted",
          title,
          detail: row.status === "ready" ? "Value is built but not yet logged as submitted." : "Potential recovery value is still sitting in the workflow.",
          value,
          href: `/app/event/${row.event.id}/review`,
          cta: "Open CE",
          tone: row.status === "ready" ? "blue" : "neutral",
        });
      }
    }

    return items.sort((a, b) => a.severity - b.severity || (b.value ?? 0) - (a.value ?? 0)).slice(0, 8);
  }, [enriched]);

  function startRename(event: EventRow) {
    setRenamingId(event.id);
    setRenameValue(event.title || "");
  }

  function cancelRename() {
    setRenamingId(null);
    setRenameValue("");
  }

  async function saveRename(eventId: string) {
    const nextTitle = renameValue.trim();
    if (!nextTitle) return;

    try {
      setRenameSavingId(eventId);
      const supabase = supabaseBrowser();
      const user = await getRequiredUser(supabase);
      const { error } = await supabase.from("events").update({ title: nextTitle }).eq("id", eventId).eq("user_id", user.id);
      if (error) throw error;
      setEvents((prev) => prev.map((e) => (e.id === eventId ? { ...e, title: nextTitle } : e)));
      cancelRename();
    } catch (err) {
      console.error("Failed to rename CE", err);
    } finally {
      setRenameSavingId(null);
    }
  }


  async function updateRegisterTracking(eventId: string, next: { status?: string; payment_status?: string }) {
    setEvents((prev) => prev.map((e) => (e.id === eventId ? { ...e, ...next } : e)));

    try {
      const supabase = supabaseBrowser();
      const user = await getRequiredUser(supabase);
      const update = await supabase.from("events").update(next).eq("id", eventId).eq("user_id", user.id);

      if (update.error) {
        const message = String(update.error.message || "");
        const paymentColumnMissing = next.payment_status && /payment_status/i.test(message);
        if (!paymentColumnMissing) throw update.error;
        const fallbackNext = { ...next };
        delete fallbackNext.payment_status;
        if (Object.keys(fallbackNext).length > 0) {
          const fallback = await supabase.from("events").update(fallbackNext).eq("id", eventId).eq("user_id", user.id);
          if (fallback.error) throw fallback.error;
        }
      }
    } catch (err) {
      console.error("Failed to update CE register tracking", err);
    }
  }

  return (
    <div style={{ background: c.bg, minHeight: "100vh" }}>
      <div style={{ maxWidth: 1240, margin: "0 auto", padding: "34px 24px 44px" }}>
        <div style={{ display: "grid", gap: 18 }}>
          <section
            style={{
              background: "linear-gradient(180deg, #ffffff 0%, #fbfcff 100%)",
              border: `1px solid ${c.border}`,
              borderRadius: 32,
              padding: 30,
              boxShadow: "0 1px 2px rgba(15,23,42,0.03)",
            }}
          >
            <div style={{ display: "grid", gridTemplateColumns: "minmax(0, 1.35fr) minmax(280px, 0.65fr)", gap: 28, alignItems: "end" }}>
              <div style={{ display: "grid", gap: 14 }}>
                <div style={{ fontSize: 12, fontWeight: 900, color: c.sub, letterSpacing: 0.7, textTransform: "uppercase" }}>Commercial control panel</div>
                <div style={{ fontSize: 30, fontWeight: 850, lineHeight: 1.12, letterSpacing: -0.9, color: c.text, maxWidth: 760 }}>
                  See what money is live, what is at risk, and what needs action next.
                </div>
                <div style={{ fontSize: 14, lineHeight: 1.65, color: c.sub, maxWidth: 720 }}>
                  The dashboard stays deliberately simple: value first, urgent action second, detail only when opened.
                </div>
              </div>

              <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, flexWrap: "wrap" }}>
                <Link href="/app/new" style={{ textDecoration: "none" }}>
                  <button
                    style={{
                      height: 48,
                      padding: "0 17px",
                      borderRadius: 16,
                      border: `1px solid ${c.black}`,
                      background: c.black,
                      color: "#fff",
                      fontWeight: 800,
                      fontSize: 14,
                      cursor: "pointer",
                    }}
                  >
                    New CE
                  </button>
                </Link>
                <QuietButton href="/app/rates">Rate cards</QuietButton>
              </div>
            </div>
          </section>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: 14 }}>
            <MetricCard label="Total CE value" value={loading ? "—" : money(metrics.totalValue)} hint="All saved CE totals." tone="default" />
            <MetricCard label="At risk" value={loading ? "—" : money(metrics.atRisk)} hint="Overdue or near time bar." tone={metrics.atRisk > 0 ? "red" : "green"} />
            <MetricCard label="Unpaid" value={loading ? "—" : money(metrics.unpaid)} hint="Submitted or accepted but not paid." tone={metrics.unpaid > 0 ? "amber" : "default"} />
            <MetricCard label="Not submitted" value={loading ? "—" : money(metrics.notSubmitted)} hint="Draft, review or ready CEs." tone={metrics.notSubmitted > 0 ? "blue" : "default"} />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "minmax(0, 1.15fr) minmax(340px, 0.85fr)", gap: 18, alignItems: "start" }}>
            <SectionCard title="Action feed" hint="Only items that need commercial attention appear here. This keeps the dashboard usable when the CE list grows.">
              {loading ? (
                <div style={{ fontSize: 13, color: c.sub }}>Loading commercial actions…</div>
              ) : actions.length === 0 ? (
                <EmptyState />
              ) : (
                <div style={{ display: "grid", gap: 12 }}>
                  {actions.map((action) => {
                    const tone = actionTone(action.tone);
                    return (
                      <Link key={action.id} href={action.href} style={{ textDecoration: "none" }}>
                        <div
                          style={{
                            border: `1px solid ${tone.bd}`,
                            background: action.tone === "neutral" ? "#fff" : tone.bg,
                            borderRadius: 20,
                            padding: 16,
                            display: "grid",
                            gridTemplateColumns: "minmax(0, 1fr) auto",
                            gap: 16,
                            alignItems: "center",
                          }}
                        >
                          <div style={{ minWidth: 0, display: "grid", gap: 5 }}>
                            <div style={{ fontSize: 11, fontWeight: 900, color: tone.tx, textTransform: "uppercase", letterSpacing: 0.55 }}>{action.eyebrow}</div>
                            <div style={{ fontSize: 15, fontWeight: 850, color: c.text, lineHeight: 1.25, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{action.title}</div>
                            <div style={{ fontSize: 12.5, color: c.sub, lineHeight: 1.5 }}>{action.detail}</div>
                          </div>
                          <div style={{ textAlign: "right", display: "grid", gap: 8, justifyItems: "end" }}>
                            <div style={{ fontSize: 18, fontWeight: 850, color: c.text }}>{action.value === null ? "—" : money(action.value)}</div>
                            <div style={{ fontSize: 12, fontWeight: 850, color: tone.tx }}>{action.cta} →</div>
                          </div>
                        </div>
                      </Link>
                    );
                  })}
                </div>
              )}
            </SectionCard>

            <SectionCard title="Notice risk" hint="Calculated from event date plus the stored contract notice period. For uploaded contracts, AI extraction should populate the contract profile and the user confirms it.">
              <div style={{ display: "grid", gap: 12 }}>
                {enriched.slice(0, 5).map((row) => {
                  const tone = row.timeRisk.state === "overdue" ? actionTone("red") : row.timeRisk.state === "due_soon" ? actionTone("amber") : actionTone("neutral");
                  return (
                    <Link key={row.event.id} href={`/app/event/${row.event.id}`} style={{ textDecoration: "none" }}>
                      <div style={{ border: `1px solid ${tone.bd}`, borderRadius: 18, padding: 14, background: row.timeRisk.state === "safe" ? "#fff" : tone.bg, display: "grid", gap: 6 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                          <div style={{ fontSize: 13, fontWeight: 850, color: c.text, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{row.event.title || "Untitled CE"}</div>
                          <div style={{ fontSize: 12, fontWeight: 850, color: tone.tx, flexShrink: 0 }}>{row.timeRisk.label}</div>
                        </div>
                        <div style={{ fontSize: 12, color: c.sub, lineHeight: 1.45 }}>
                          Deadline: {row.timeRisk.deadline ? formatDateShort(row.timeRisk.deadline) : "not calculated"}
                        </div>
                      </div>
                    </Link>
                  );
                })}
                {!loading && enriched.length === 0 ? <div style={{ fontSize: 13, color: c.sub }}>No CEs created yet.</div> : null}
              </div>
            </SectionCard>
          </div>

          <SectionCard title="CE register" hint="The register stays collapsed by default. Open it when you need CE-level status and payment tracking.">
            <button
              type="button"
              onClick={() => setShowAll((p) => !p)}
              style={{
                width: "100%",
                height: 44,
                borderRadius: 14,
                border: `1px solid ${c.border}`,
                background: "#fff",
                color: c.black,
                fontWeight: 750,
                fontSize: 13,
                cursor: "pointer",
              }}
            >
              {showAll ? "Hide CE register" : `Open CE register (${events.length})`}
            </button>

            {showAll ? (
              <div style={{ marginTop: 14, display: "grid", gap: 12 }}>
                {enriched.map((row) => {
                  const st = statusTone(row.event.status);
                  const timeTone = row.timeRisk.state === "overdue" ? actionTone("red") : row.timeRisk.state === "due_soon" ? actionTone("amber") : actionTone("neutral");
                  return (
                    <div
                      key={row.event.id}
                      style={{
                        border: `1px solid ${c.border}`,
                        borderRadius: 20,
                        padding: 16,
                        background: "#fff",
                        display: "grid",
                        gap: 14,
                      }}
                    >
                      <div style={{ display: "grid", gridTemplateColumns: "minmax(0, 1fr) auto", gap: 16, alignItems: "start" }}>
                        <div style={{ minWidth: 0 }}>
                          {renamingId === row.event.id ? (
                            <div style={{ display: "flex", gap: 8 }}>
                              <input
                                value={renameValue}
                                onChange={(e) => setRenameValue(e.target.value)}
                                style={{ flex: 1, minWidth: 0, border: `1px solid ${c.border}`, borderRadius: 12, padding: "9px 10px", fontSize: 13 }}
                              />
                              <button onClick={() => saveRename(row.event.id)} disabled={renameSavingId === row.event.id} style={{ border: `1px solid ${c.black}`, background: c.black, color: "#fff", borderRadius: 12, padding: "0 10px", fontWeight: 750, cursor: "pointer" }}>Save</button>
                              <button onClick={cancelRename} style={{ border: `1px solid ${c.border}`, background: "#fff", borderRadius: 12, padding: "0 10px", fontWeight: 750, cursor: "pointer" }}>Cancel</button>
                            </div>
                          ) : (
                            <>
                              <Link href={`/app/event/${row.event.id}`} style={{ color: c.text, textDecoration: "none", fontSize: 15, fontWeight: 800, display: "block", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                                {row.event.title || "Untitled CE"}
                              </Link>
                              <div style={{ marginTop: 5, fontSize: 12.5, color: c.sub, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", lineHeight: 1.45 }}>
                                {projectContext(row.event)} • {getContractLabel(row.event.contract_type)}
                              </div>
                            </>
                          )}
                        </div>

                        <div style={{ textAlign: "right", display: "grid", gap: 7, justifyItems: "end" }}>
                          <div style={{ fontSize: 18, fontWeight: 800, color: c.text }}>{row.value === null ? "Not calculated" : fullMoney(row.value)}</div>
                          <div style={{ display: "flex", gap: 7, flexWrap: "wrap", justifyContent: "flex-end" }}>
                            <span style={{ padding: "5px 9px", borderRadius: 999, border: `1px solid ${st.bd}`, background: st.bg, color: st.tx, fontSize: 11.5, fontWeight: 800 }}>
                              {getCommercialStatusLabel(row.event.status)}
                            </span>
                            <span style={{ padding: "5px 9px", borderRadius: 999, border: `1px solid ${timeTone.bd}`, background: row.timeRisk.state === "safe" ? "#fff" : timeTone.bg, color: timeTone.tx, fontSize: 11.5, fontWeight: 800 }}>
                              {row.timeRisk.deadline ? row.timeRisk.label : "No event date"}
                            </span>
                          </div>
                        </div>
                      </div>

                      <details style={{ borderTop: `1px solid ${c.border}`, paddingTop: 12 }}>
                        <summary style={{ cursor: "pointer", color: c.sub, fontSize: 12.5, fontWeight: 800, listStyle: "none" }}>
                          Manage tracking ▾
                        </summary>
                        <div style={{ marginTop: 12, display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: 12, alignItems: "end" }}>
                          <label style={{ display: "grid", gap: 6 }}>
                            <span style={{ fontSize: 11.5, fontWeight: 800, color: c.sub }}>CE status</span>
                            <select
                              value={normaliseCommercialStatus(row.event.status)}
                              onChange={(e) => void updateRegisterTracking(row.event.id, { status: e.target.value })}
                              style={{ width: "100%", height: 40, borderRadius: 12, border: `1px solid ${c.border}`, background: "#fff", padding: "0 10px", fontSize: 13, color: c.text }}
                            >
                              {COMMERCIAL_STATUS_OPTIONS.map((option) => (
                                <option key={option.value} value={option.value}>{option.label}</option>
                              ))}
                            </select>
                          </label>

                          <label style={{ display: "grid", gap: 6 }}>
                            <span style={{ fontSize: 11.5, fontWeight: 800, color: c.sub }}>Payment</span>
                            <select
                              value={row.event.payment_status ?? "not_applied"}
                              onChange={(e) => void updateRegisterTracking(row.event.id, { payment_status: e.target.value })}
                              style={{ width: "100%", height: 40, borderRadius: 12, border: `1px solid ${c.border}`, background: "#fff", padding: "0 10px", fontSize: 13, color: c.text }}
                            >
                              {PAYMENT_STATUS_OPTIONS.map((option) => (
                                <option key={option.value} value={option.value}>{option.label}</option>
                              ))}
                            </select>
                          </label>

                          <div style={{ display: "grid", gap: 6 }}>
                            <span style={{ fontSize: 11.5, fontWeight: 800, color: c.sub }}>Notice deadline</span>
                            <div style={{ height: 40, display: "flex", alignItems: "center", borderRadius: 12, border: `1px solid ${timeTone.bd}`, background: row.timeRisk.state === "safe" ? "#fff" : timeTone.bg, padding: "0 10px", fontSize: 13, color: c.text }}>
                              {row.timeRisk.deadline ? niceDate(row.timeRisk.deadline.toISOString()) : "Add event date"}
                            </div>
                          </div>

                          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
                            <button onClick={() => startRename(row.event)} style={{ height: 40, border: `1px solid ${c.border}`, background: "#fff", borderRadius: 12, padding: "0 11px", fontWeight: 750, cursor: "pointer" }}>Rename</button>
                            <Link href={`/app/event/${row.event.id}/review`} style={{ textDecoration: "none" }}>
                              <button style={{ height: 40, border: `1px solid ${c.black}`, background: c.black, color: "#fff", borderRadius: 12, padding: "0 13px", fontWeight: 800, cursor: "pointer" }}>Review</button>
                            </Link>
                          </div>
                        </div>
                        <div style={{ marginTop: 10, fontSize: 12, color: c.sub, lineHeight: 1.45 }}>
                          Tracking stays internal. It powers the dashboard and does not change the client-facing Excel narrative.
                        </div>
                      </details>
                    </div>
                  );
                })}
              </div>
            ) : null}
          </SectionCard>
        </div>
      </div>
    </div>
  );
}
