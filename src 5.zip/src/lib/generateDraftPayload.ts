import { getContractFamily, getContractLabel } from "@/lib/contracts";
import { getDraftTemplateForContractType } from "@/lib/draftTemplates";
import { COMPANY_PROFILE_SELECT, cleanCompanyProfile, companyDisplayName, companyLegalName } from "@/lib/companyProfile";

type SupabaseAdminClient = any;

function num(value: unknown, fallback = 0) {
  const n = typeof value === "number" ? value : parseFloat(String(value ?? ""));
  return Number.isFinite(n) ? n : fallback;
}

function text(value: unknown) {
  return String(value ?? "").trim();
}

function compactObject<T extends Record<string, any>>(obj: T): T {
  return Object.fromEntries(
    Object.entries(obj).filter(([, value]) => value !== undefined)
  ) as T;
}

function safeArray<T = any>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : [];
}

function sum(lines: any[], predicate: (line: any) => boolean) {
  return lines.filter(predicate).reduce((total, line) => total + num(line.total), 0);
}

function lower(value: unknown) {
  return String(value ?? "").toLowerCase();
}

function isTextLikeFile(file: any) {
  const mime = lower(file?.mime_type);
  const name = lower(file?.file_name);
  return (
    mime.startsWith("text/") ||
    mime.includes("json") ||
    mime.includes("xml") ||
    name.endsWith(".txt") ||
    name.endsWith(".md") ||
    name.endsWith(".csv")
  );
}

async function tryDownloadText(admin: SupabaseAdminClient, file: any) {
  if (!file?.file_path || !isTextLikeFile(file)) return "";

  try {
    const downloaded = await admin.storage.from("contract-files").download(file.file_path);
    if (downloaded.error || !downloaded.data) return "";
    return await downloaded.data.text();
  } catch {
    return "";
  }
}

async function fetchEvent(admin: SupabaseAdminClient, eventId: string, userId: string) {
  const selectWithSummary =
    "id,user_id,title,status,created_at,delay_days,contract_type,contract_source,project_name,main_contractor,event_financial_summary";
  const selectFallback =
    "id,user_id,title,status,created_at,delay_days,contract_type,contract_source,project_name,main_contractor";

  const primary = await admin
    .from("events")
    .select(selectWithSummary)
    .eq("id", eventId)
    .eq("user_id", userId)
    .maybeSingle();

  if (!primary.error) return primary;

  const message = String(primary.error.message || "");
  const missingSummary = /event_financial_summary/i.test(message) && /does not exist|schema cache|column/i.test(message);
  if (!missingSummary) return primary;

  return admin
    .from("events")
    .select(selectFallback)
    .eq("id", eventId)
    .eq("user_id", userId)
    .maybeSingle();
}

export async function buildGenerateDraftPayload(params: {
  admin: SupabaseAdminClient;
  eventId: string;
  userId: string;
}) {
  const { admin, eventId, userId } = params;

  const eventRes = await fetchEvent(admin, eventId, userId);
  if (eventRes.error) throw eventRes.error;
  const event = eventRes.data;
  if (!event) throw new Error("Event not found");

  const [basisRes, evidenceRes, resourcesRes, valuationRes, prelimsRes, contractFilesRes, reviewRes, companyProfileRes] =
    await Promise.all([
      admin
        .from("event_basis")
        .select(
          "happened_summary,cause_type,cause_summary,difference_from_plan,mechanism_tags,time_impact_toggle,mitigation_summary"
        )
        .eq("event_id", eventId)
        .maybeSingle(),
      admin
        .from("event_files")
        .select(
          "id,category,file_name,file_path,file_size,mime_type,description,evidence_date,relates_to,created_at"
        )
        .eq("event_id", eventId)
        .order("created_at", { ascending: true }),
      admin
        .from("event_resource_lines")
        .select(
          "id,category,item_name,unit,hours,qty,rate,total,notes,tags,start_date,end_date,linked_event,created_at"
        )
        .eq("event_id", eventId)
        .order("created_at", { ascending: true }),
      admin
        .from("event_valuation_settings")
        .select("fee_percent,fee_basis,work_days_per_week")
        .eq("event_id", eventId)
        .maybeSingle(),
      admin
        .from("event_prelim_lines")
        .select("id,name,qty,unit,rate,notes,prelim_type,created_at")
        .eq("event_id", eventId)
        .order("created_at", { ascending: true }),
      admin
        .from("event_contract_files")
        .select("id,file_name,file_path,file_size,mime_type,created_at")
        .eq("event_id", eventId)
        .order("created_at", { ascending: true }),
      admin
        .from("event_review_settings")
        .select(
          "include_basis,include_entitlement,include_time_impact,include_evidence_register,include_cost_summary,include_prelims_fee,include_risk_notes,include_excel,include_pdf,qualifications_notes"
        )
        .eq("event_id", eventId)
        .maybeSingle(),
      admin
        .from("company_profiles")
        .select(COMPANY_PROFILE_SELECT)
        .eq("user_id", userId)
        .maybeSingle(),
    ]);

  for (const res of [basisRes, evidenceRes, resourcesRes, valuationRes, prelimsRes, contractFilesRes, reviewRes]) {
    if (res.error) throw res.error;
  }

  if (companyProfileRes.error) {
    console.warn("Company profile unavailable for AI payload:", companyProfileRes.error);
  }

  const basis = basisRes.data || {};
  const companyProfile = cleanCompanyProfile(companyProfileRes.data || null);
  const submittingPartyName = companyDisplayName(companyProfile);
  const submittingPartyLegalName = companyLegalName(companyProfile);
  const evidenceRows = evidenceRes.data || [];
  const resourceRows = resourcesRes.data || [];
  const prelimRows = prelimsRes.data || [];
  const contractFiles = contractFilesRes.data || [];
  const valuation = valuationRes.data || {};
  const review = reviewRes.data || {};

  const contractFamily = getContractFamily(event.contract_type);
  const contractLabel = getContractLabel(event.contract_type);
  const draftTemplate = getDraftTemplateForContractType(event.contract_type);
  const isJct = contractFamily === "JCT";

  const uploadedContractTextParts = await Promise.all(
    contractFiles.map(async (file: any) => {
      const body = await tryDownloadText(admin, file);
      if (!body) return "";
      return [`--- ${file.file_name || "Uploaded contract text"} ---`, body].join("\n");
    })
  );

  const uploadedContractText = uploadedContractTextParts.filter(Boolean).join("\n\n").trim();
  const financialSummary = (event as any).event_financial_summary || {};

  const labourLines = resourceRows.filter((line: any) => line.category === "labour");
  const plantLines = resourceRows.filter((line: any) => line.category === "plant");
  const materialLines = resourceRows.filter((line: any) => line.category === "material");
  const subcontractLines = resourceRows.filter((line: any) => line.category === "subcontract");
  const staffPrelims = prelimRows.filter((line: any) => line.prelim_type === "staff");
  const otherPrelims = prelimRows.filter((line: any) => line.prelim_type !== "staff");

  const resourceTotals = {
    labour_total: num(financialSummary.labour_total, sum(resourceRows, (line) => line.category === "labour")),
    plant_total: num(financialSummary.plant_total, sum(resourceRows, (line) => line.category === "plant")),
    materials_total: num(financialSummary.materials_total, sum(resourceRows, (line) => line.category === "material")),
    subcontract_total: num(financialSummary.subcontract_total, sum(resourceRows, (line) => line.category === "subcontract")),
    defined_cost_total: num(financialSummary.defined_cost_total, sum(resourceRows, (line) => ["labour", "plant", "material", "subcontract"].includes(line.category))),
    prelims_total: num(financialSummary.prelims_total),
    staff_prelims_total: num(financialSummary.staff_prelims_total),
    other_prelims_total: num(financialSummary.other_prelims_total),
    fee_total: num(financialSummary.fee_total),
    final_total: num(financialSummary.final_total),
  };

  const payload = {
    generation_context: {
      purpose: "Generate detailed, submission-ready CE / claim narrative JSON for the selected Excel submission pack sections.",
      output_schema: draftTemplate.sections.map((section) => ({ key: section.key, label: section.label })),
      required_json_keys: draftTemplate.sections.map((section) => section.key),
      currency: "GBP",
      do_not_calculate_costs: true,
      use_provided_totals_only: true,
    },
    contract: {
      family: contractFamily,
      form: contractLabel,
      raw_contract_type: event.contract_type,
      source: event.contract_source || "standard_form_selected",
      uploaded_contract_text: uploadedContractText,
      uploaded_contract_text_status: uploadedContractText
        ? "included_in_payload"
        : contractFiles.length > 0
          ? "contract_files_uploaded_but_text_not_extracted_yet"
          : "no_uploaded_contract_text",
      uploaded_contract_files: contractFiles.map((file: any) => ({
        id: file.id,
        file_name: file.file_name,
        mime_type: file.mime_type,
        file_size: file.file_size,
        uploaded_at: file.created_at,
      })),
      instruction_for_ai: uploadedContractText
        ? "Review the uploaded contract text and selected contract form together. Use clause references only where supported by the contract text and event facts."
        : "No extracted contract text is available. Use the selected standard form cautiously and state any limitations where clause certainty depends on contract amendments.",
    },
    company_profile: {
      company_name: companyProfile.company_name || "",
      trading_name: companyProfile.trading_name || "",
      role: companyProfile.role || "Subcontractor",
      logo_url: companyProfile.logo_url || "",
      address: companyProfile.address || "",
      email: companyProfile.email || "",
      phone: companyProfile.phone || "",
      vat_number: companyProfile.vat_number || "",
      company_registration_number: companyProfile.company_registration_number || "",
      instruction_for_ai: submittingPartyName
        ? "Use company_profile as the authoritative source for the submitting party identity. Do not infer or invent the company name, trading name, address, logo or role."
        : "No company profile has been set. Do not infer the submitting party identity; state this limitation where relevant.",
    },
    project: {
      project_name: event.project_name || "",
      contractor: event.main_contractor || "",
      subcontractor: submittingPartyLegalName || submittingPartyName || "",
    },
    event: {
      id: event.id,
      title: event.title || "",
      status: event.status || "draft",
      created_at: event.created_at || null,
      delay_days: num(event.delay_days, 0),
    },
    basis_of_change: {
      what_happened: basis.happened_summary || "",
      cause_type: basis.cause_type || "",
      cause: basis.cause_summary || "",
      difference_from_planned_basis: basis.difference_from_plan || "",
      mechanism_tags: safeArray<string>(basis.mechanism_tags),
      mitigation: basis.mitigation_summary || "",
      time_impact_toggle: basis.time_impact_toggle || "unsure",
    },
    programme: {
      delay_days: num(event.delay_days, 0),
      programme_impact: basis.time_impact_toggle === "yes" ? `${num(event.delay_days, 0)} days stated in CE basis.` : "Programme impact not confirmed in the CE basis.",
      time_impact_toggle: basis.time_impact_toggle || "unsure",
      sequence_disruption: text(basis.difference_from_plan) || text(basis.happened_summary),
      critical_path_notes: "Use only if supported by programme evidence or user notes. Do not assert critical path impact if not evidenced.",
    },
    evidence: evidenceRows.map((file: any) => ({
      id: file.id,
      category: file.category,
      file_name: file.file_name,
      description: file.description || "",
      evidence_date: file.evidence_date || null,
      relates_to: file.relates_to || "",
      mime_type: file.mime_type || "",
      created_at: file.created_at || null,
    })),
    resources: {
      totals: resourceTotals,
      labour: labourLines,
      plant: plantLines,
      materials: materialLines,
      subcontract: subcontractLines,
      all_lines: resourceRows,
      activity_breakdown: resourceRows.reduce((acc: Record<string, any[]>, line: any) => {
        const key = text(line.linked_event) || "General activity";
        acc[key] = acc[key] || [];
        acc[key].push(compactObject({
          category: line.category,
          item_name: line.item_name,
          unit: line.unit,
          hours: line.hours,
          qty: line.qty,
          rate: line.rate,
          total: line.total,
          notes: line.notes,
          tags: line.tags,
          start_date: line.start_date,
          end_date: line.end_date,
        }));
        return acc;
      }, {}),
    },
    prelims: {
      valuation_settings: {
        fee_percent: num(valuation.fee_percent, 0),
        fee_basis: valuation.fee_basis || "defined_cost",
        work_days_per_week: num(valuation.work_days_per_week, 5),
      },
      delay_days: num(event.delay_days, 0),
      staff_prelims: staffPrelims,
      other_prelims: otherPrelims,
      all_prelim_lines: prelimRows,
    },
    financial_summary: resourceTotals,
    review_settings: {
      include_basis: review.include_basis ?? true,
      include_entitlement: review.include_entitlement ?? true,
      include_time_impact: review.include_time_impact ?? true,
      include_evidence_register: review.include_evidence_register ?? true,
      include_cost_summary: review.include_cost_summary ?? true,
      include_prelims_fee: review.include_prelims_fee ?? true,
      include_risk_notes: review.include_risk_notes ?? true,
      include_excel: review.include_excel ?? true,
      include_pdf: review.include_pdf ?? false,
      qualifications_notes: review.qualifications_notes || "",
    },
    excel_output_mapping: {
      background: ["Basis of Change", "Summary"],
      change_to_contract_basis: ["Basis of Change"],
      effect_on_defined_cost: isJct ? ["Prelims + Fee", "Summary"] : ["Prelims + Fee"],
      effect_on_programme: ["Time Risk"],
      commercial_impact: ["Summary", "Prelims + Fee"],
      contractual_position: ["Basis of Change", "Summary"],
      assumptions: ["Time Risk", "Audit"],
      risks_and_qualifications: ["Time Risk", "Audit"],
      conclusion: ["Summary", "Basis of Change"],
    },
    ai_instructions: {
      contract_language: isJct
        ? "Use JCT-appropriate language. Do not use NEC-specific phrases such as Defined Cost unless explaining why they are not applicable."
        : "Use NEC-appropriate language including Defined Cost and programme effect where supported.",
      clause_instruction: "Consider all relevant clauses in the selected contract form and any uploaded contract text. Reference only clauses that are supported by the facts and contract information. If uncertain, state the limitation in risks_and_qualifications.",
      company_identity_instruction: "Use company_profile as the only source of truth for the submitting party identity. Do not use hardcoded or assumed company names.",
      output_instruction: "Return JSON only, matching the required_json_keys exactly. Do not include markdown or commentary.",
    },
  };

  return payload;
}

export async function tryStoreDraftPayload(params: {
  admin: SupabaseAdminClient;
  eventId: string;
  userId: string;
  packId?: string | null;
  payload: any;
  aiDraft?: any;
}) {
  const { admin, eventId, userId, packId, payload, aiDraft } = params;
  const now = new Date().toISOString();

  try {
    const stored = await admin.from("event_ai_drafts").insert({
      event_id: eventId,
      user_id: userId,
      pack_id: packId || null,
      draft_payload: payload,
      draft_output: aiDraft || null,
      status: aiDraft ? "draft_generated" : "payload_ready",
      created_at: now,
      updated_at: now,
    });
    if (stored?.error) throw stored.error;
  } catch (error) {
    console.warn("AI draft payload storage skipped:", error);
  }
}
