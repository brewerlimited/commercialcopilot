"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import { CONTRACT_TYPE_OPTIONS, getContractFamilyHint, type KnownContractType } from "@/lib/contracts";
import { buildEventReference } from "@/lib/eventReference";
import { getDefaultNoticePeriodDays } from "@/lib/commercialControl";

type ContractType = KnownContractType;

type ContractSource = "standard_logic" | "upload_contract";

const FIELD_GRID_STYLE = {
  display: "grid",
  gap: 14,
  alignItems: "start",
  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
};

const CONTRACT_SOURCE_OPTIONS: { value: ContractSource; label: string }[] = [
  { value: "standard_logic", label: "Use standard contract logic" },
  { value: "upload_contract", label: "Upload contract documents" },
];

const c = {
  card: "var(--surface)",
  input: "var(--surface-input)",
  border: "var(--border)",
  sub: "var(--text-muted)",
  text: "var(--foreground)",
  black: "var(--accent)",
  blackContrast: "var(--accent-contrast)",
  soft: "var(--surface-soft)",
  redBg: "var(--red-bg)",
  redBorder: "var(--red-border)",
  redText: "var(--red-text)",
  amberBg: "var(--amber-bg)",
  amberBorder: "var(--amber-border)",
  amberText: "var(--amber-text)",
};

function Label({ children }: { children: React.ReactNode }) {
  return (
    <span
      style={{
        fontWeight: 700,
        fontSize: 12,
        color: c.sub,
      }}
    >
      {children}
    </span>
  );
}

function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      style={{
        width: "100%",
        padding: "12px 12px",
        borderRadius: 14,
        border: `1px solid ${c.border}`,
        outline: "none",
        background: c.input,
        color: c.black,
        fontSize: 14,
        lineHeight: 1.5,
        ...(props.style ?? {}),
      }}
    />
  );
}

function SelectInput(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      style={{
        width: "100%",
        padding: "12px 12px",
        borderRadius: 14,
        border: `1px solid ${c.border}`,
        outline: "none",
        background: c.input,
        color: c.black,
        fontSize: 14,
        ...(props.style ?? {}),
      }}
    />
  );
}

export default function NewEvent() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [title, setTitle] = useState("");
  const [projectName, setProjectName] = useState("");
  const [mainContractor, setMainContractor] = useState("");
  const [contractType, setContractType] = useState<ContractType>("nec4_ecs_option_b");
  const [contractSource, setContractSource] = useState<ContractSource>("standard_logic");
  const [fromEwnId, setFromEwnId] = useState<string | null>(null);
  const [eventDate, setEventDate] = useState<string | null>(null);
  const [ewnFacts, setEwnFacts] = useState({
    whatHappened: "",
    impact: "",
    requiredAction: "",
    evidence: "",
    location: "",
  });
  const [files, setFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const canCreate = useMemo(() => {
    if (!title.trim()) return false;
    if (!projectName.trim()) return false;
    if (!mainContractor.trim()) return false;
    if (contractSource === "upload_contract" && files.length === 0) return false;
    return !loading;
  }, [title, projectName, mainContractor, contractSource, files, loading]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ewnId = params.get("from_ewn");
    const ewnTitle = params.get("title");
    const project = params.get("project");
    const contractor = params.get("main_contractor");
    const importedEventDate = params.get("event_date");
    const whatHappened = params.get("what_happened") || "";
    const impact = params.get("impact") || "";
    const requiredAction = params.get("required_action") || "";
    const evidence = params.get("evidence") || "";
    const location = params.get("location") || "";

    if (ewnId) setFromEwnId(ewnId);
    if (ewnTitle) setTitle((prev) => prev || ewnTitle);
    if (project) setProjectName((prev) => prev || project);
    if (contractor) setMainContractor((prev) => prev || contractor);
    if (importedEventDate) setEventDate(importedEventDate);
    if (whatHappened || impact || requiredAction || evidence || location) {
      setEwnFacts({ whatHappened, impact, requiredAction, evidence, location });
    }
  }, []);

  function handlePickedFiles(fileList: FileList | null) {
    if (!fileList || fileList.length === 0) return;
    const next = Array.from(fileList);
    setFiles((prev) => {
      const existing = new Map(prev.map((f) => [`${f.name}_${f.size}`, f]));
      for (const f of next) {
        existing.set(`${f.name}_${f.size}`, f);
      }
      return Array.from(existing.values());
    });
  }

  function removeFile(index: number) {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  }

  async function create() {
    setErr(null);
    setLoading(true);

    try {
      const supabase = supabaseBrowser();
      const { data } = await supabase.auth.getSession();

      const user = data.session?.user;
      if (!user) {
        router.push("/login");
        return;
      }

      const cleanProjectName = projectName.trim();
      const cleanMainContractor = mainContractor.trim();

      const existingRefs = await supabase
        .from("events")
        .select("event_number,event_reference")
        .eq("user_id", user.id)
        .eq("project_name", cleanProjectName)
        .order("event_number", { ascending: false })
        .limit(1);

      if (existingRefs.error) throw existingRefs.error;

      const existingNumbers = (existingRefs.data ?? [])
        .map((row: any) => Number(row.event_number))
        .filter((value: number) => Number.isFinite(value));
      const nextEventNumber = existingNumbers.length > 0 ? Math.max(...existingNumbers) + 1 : 1;
      const eventReference = buildEventReference(contractType, nextEventNumber);

      const basePayload = {
        user_id: user.id,
        title: title.trim(),
        project_name: cleanProjectName,
        main_contractor: cleanMainContractor,
        status: "draft",
        contract_type: contractType,
        contract_source: contractSource,
        event_number: nextEventNumber,
        event_reference: eventReference,
        ...(eventDate ? { event_date: eventDate } : {}),
      };

      let insertRes = await supabase
        .from("events")
        .insert([
          {
            ...basePayload,
            notice_period_days: getDefaultNoticePeriodDays(contractType),
          },
        ])
        .select("id")
        .single();

      if (insertRes.error) {
        const message = String(insertRes.error.message || "");
        const optionalColumnMissing = /notice_period_days/i.test(message);
        if (!optionalColumnMissing) throw insertRes.error;

        insertRes = await supabase
          .from("events")
          .insert([basePayload])
          .select("id")
          .single();
      }

      if (insertRes.error) throw insertRes.error;

      const eventId = insertRes.data.id as string;

      if (contractSource === "upload_contract" && files.length > 0) {
        for (const file of files) {
          const safeName = file.name.replace(/[^\w.\- ]+/g, "_");
          const filePath = `${user.id}/${eventId}/${Date.now()}-${safeName}`;

          const upload = await supabase.storage
            .from("contract-files")
            .upload(filePath, file, {
              cacheControl: "3600",
              upsert: false,
            });

          if (upload.error) throw upload.error;

          const fileInsert = await supabase.from("event_contract_files").insert({
            event_id: eventId,
            user_id: user.id,
            file_name: file.name,
            file_path: filePath,
            file_size: file.size,
            mime_type: file.type || null,
          });

          if (fileInsert.error) throw fileInsert.error;
        }
      }

      if (fromEwnId) {
        const happenedSummary = [
          ewnFacts.whatHappened,
          ewnFacts.location ? `Location: ${ewnFacts.location}.` : "",
        ].filter(Boolean).join("\n\n");

        const causeSummary = ewnFacts.impact || "Impact carried forward from the linked EWN. Review and expand before submission.";
        const mitigationSummary = ewnFacts.requiredAction || "Required action carried forward from the linked EWN. Review and expand before submission.";
        const differenceFromPlan = ewnFacts.evidence
          ? `Evidence / records noted in EWN: ${ewnFacts.evidence}`
          : "Created from EWN. Confirm the change from planned or tendered basis before submission.";

        if (happenedSummary || ewnFacts.impact || ewnFacts.requiredAction || ewnFacts.evidence) {
          await supabase.from("event_basis").upsert(
            {
              event_id: eventId,
              happened_summary: happenedSummary,
              cause_type: "other",
              cause_summary: causeSummary,
              difference_from_plan: differenceFromPlan,
              mechanism_tags: [],
              time_impact_toggle: ewnFacts.impact ? "unsure" : "unsure",
              mitigation_summary: mitigationSummary,
              updated_at: new Date().toISOString(),
            },
            { onConflict: "event_id" }
          );
        }

        await supabase.from("ewns").update({ status: "converted", converted_event_id: eventId, converted_at: new Date().toISOString() }).eq("id", fromEwnId);
        try {
          const raw = localStorage.getItem("cc.ewns");
          const parsed = raw ? JSON.parse(raw) : [];
          if (Array.isArray(parsed)) {
            localStorage.setItem(
              "cc.ewns",
              JSON.stringify(parsed.map((x: any) => (x.id === fromEwnId ? { ...x, status: "converted", converted_event_id: eventId } : x)))
            );
          }
        } catch {}
      }

      router.push(`/app/event/${eventId}`);
    } catch (e: any) {
      setErr(e?.message ?? "Failed to create CE draft");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      style={{
        background: c.card,
        border: `1px solid ${c.border}`,
        borderRadius: 22,
        padding: 28,
      }}
    >
      <h1
        style={{
          fontSize: 24,
          fontWeight: 700,
          margin: 0,
          color: c.black,
        }}
      >
        New CE
      </h1>

      <p
        style={{
          marginTop: 8,
          marginBottom: 0,
          color: c.sub,
          fontSize: 13,
          lineHeight: 1.55,
          maxWidth: 760,
        }}
      >
        Start with the CE title, then tie it to the project, main contractor and contract basis so
        the dashboard and outputs stay commercially clear.
      </p>

      {fromEwnId ? (
        <div
          style={{
            marginTop: 18,
            border: `1px solid ${c.amberBorder}`,
            background: c.amberBg,
            color: c.amberText,
            borderRadius: 14,
            padding: 12,
            fontSize: 13,
            fontWeight: 700,
            lineHeight: 1.5,
          }}
        >
          This CE has been started from an EWN. Review the title, project and contract basis before creating the draft.
        </div>
      ) : null}

      {fromEwnId && (ewnFacts.whatHappened || ewnFacts.impact || ewnFacts.requiredAction) ? (
        <div
          style={{
            marginTop: 14,
            border: `1px solid ${c.border}`,
            background: c.soft,
            borderRadius: 14,
            padding: 14,
            display: "grid",
            gap: 8,
          }}
        >
          <div style={{ fontSize: 12, fontWeight: 800, color: c.sub, textTransform: "uppercase", letterSpacing: 0.5 }}>EWN carried into this CE</div>
          {ewnFacts.whatHappened ? <p style={{ margin: 0, color: c.black, fontSize: 13, lineHeight: 1.55 }}>{ewnFacts.whatHappened}</p> : null}
          {ewnFacts.impact ? <p style={{ margin: 0, color: c.sub, fontSize: 13, lineHeight: 1.55 }}>Impact: {ewnFacts.impact}</p> : null}
          {ewnFacts.requiredAction ? <p style={{ margin: 0, color: c.sub, fontSize: 13, lineHeight: 1.55 }}>Required action: {ewnFacts.requiredAction}</p> : null}
        </div>
      ) : null}

      <div style={{ marginTop: 20, display: "grid", gap: 16 }}>
        <label style={{ display: "grid", gap: 6 }}>
          <Label>CE title</Label>
          <TextInput
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Flooding at ST43"
          />
        </label>

        <div style={FIELD_GRID_STYLE}>
          <label style={{ display: "grid", gap: 6 }}>
            <Label>Project / job</Label>
            <TextInput
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              placeholder="e.g. A428 Black Cat to Caxton Gibbet"
            />
          </label>

          <label style={{ display: "grid", gap: 6 }}>
            <Label>Main contractor</Label>
            <TextInput
              value={mainContractor}
              onChange={(e) => setMainContractor(e.target.value)}
              placeholder="e.g. Skanska"
            />
          </label>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              contractSource === "upload_contract"
                ? "minmax(0, 1.2fr) minmax(0, 1.2fr) minmax(0, 1.6fr)"
                : "minmax(0, 1fr) minmax(0, 1fr)",
            gap: 14,
            alignItems: "start",
          }}
        >
          <label style={{ display: "grid", gap: 6 }}>
            <Label>Contract type</Label>
            <SelectInput
              value={contractType}
              onChange={(e) => setContractType(e.target.value as ContractType)}
            >
              {CONTRACT_TYPE_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </SelectInput>
          </label>

          <label style={{ display: "grid", gap: 6 }}>
            <Label>Contract source</Label>
            <SelectInput
              value={contractSource}
              onChange={(e) => {
                const value = e.target.value as ContractSource;
                setContractSource(value);
                if (value === "standard_logic") {
                  setFiles([]);
                }
              }}
            >
              {CONTRACT_SOURCE_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </SelectInput>
          </label>

          {contractSource === "upload_contract" ? (
            <div style={{ display: "grid", gap: 6 }}>
              <Label>Contract documents</Label>

              <input
                ref={fileInputRef}
                type="file"
                multiple
                style={{ display: "none" }}
                onChange={(e) => handlePickedFiles(e.target.files)}
                accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg"
              />

              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  handlePickedFiles(e.dataTransfer.files);
                }}
                style={{
                  border: `1px dashed ${c.border}`,
                  background: c.soft,
                  borderRadius: 14,
                  padding: 12,
                  minHeight: 50,
                }}
              >
                <div
                  style={{
                    display: "flex",
                    gap: 10,
                    justifyContent: "space-between",
                    alignItems: "center",
                    flexWrap: "wrap",
                  }}
                >
                  <div style={{ fontSize: 12, color: c.sub, lineHeight: 1.4 }}>
                    Upload subcontract agreement, Z clauses, amendments, scope extracts or other
                    contract documents.
                  </div>

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    style={{
                      padding: "10px 12px",
                      borderRadius: 12,
                      border: `1px solid ${c.black}`,
                      background: c.black,
                      color: c.blackContrast,
                      fontWeight: 700,
                      cursor: "pointer",
                      whiteSpace: "nowrap",
                    }}
                  >
                    Upload files
                  </button>
                </div>

                {files.length > 0 ? (
                  <div style={{ display: "grid", gap: 8, marginTop: 12 }}>
                    {files.map((file, index) => (
                      <div
                        key={`${file.name}_${file.size}_${index}`}
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          gap: 10,
                          padding: "10px 12px",
                          borderRadius: 12,
                          border: `1px solid ${c.border}`,
                          background: c.input,
                        }}
                      >
                        <div style={{ minWidth: 0 }}>
                          <div
                            style={{
                              fontSize: 13,
                              fontWeight: 700,
                              color: c.black,
                              whiteSpace: "nowrap",
                              overflow: "hidden",
                              textOverflow: "ellipsis",
                            }}
                          >
                            {file.name}
                          </div>
                          <div style={{ fontSize: 12, color: c.sub }}>
                            {(file.size / 1024 / 1024).toFixed(2)} MB
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => removeFile(index)}
                          style={{
                            border: `1px solid ${c.border}`,
                            background: c.input,
                            borderRadius: 10,
                            padding: "8px 10px",
                            fontWeight: 700,
                            cursor: "pointer",
                          }}
                        >
                          Remove
                        </button>
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>
            </div>
          ) : null}
        </div>

        <div
          style={{
            marginTop: 12,
            border: `1px solid ${c.border}`,
            background: c.soft,
            borderRadius: 14,
            padding: 12,
            fontSize: 12,
            color: c.sub,
            lineHeight: 1.5,
          }}
        >
          {getContractFamilyHint(contractType)}
        </div>

        <div
          style={{
            border: `1px solid ${c.border}`,
            background: c.soft,
            borderRadius: 14,
            padding: 14,
            fontSize: 12,
            color: c.sub,
            lineHeight: 1.5,
          }}
        >
          {contractSource === "standard_logic" ? (
            <>
              The CE will start from the standard clause structure for the selected contract type.
              This is best where the contract generally follows the standard NEC wording and there are
              no major bespoke amendments.
            </>
          ) : (
            <>
              Uploaded contract documents will be attached to the CE so later AI drafting can review
              amended clauses, notice requirements, risk allocation, Defined Cost changes, fee changes
              and programme obligations.
            </>
          )}
        </div>

        {err ? (
          <div
            style={{
              border: `1px solid ${c.redBorder}`,
              background: c.redBg,
              color: c.redText,
              padding: 12,
              borderRadius: 14,
              fontSize: 13,
              fontWeight: 700,
            }}
          >
            {err}
          </div>
        ) : null}

        <button
          onClick={create}
          disabled={!canCreate}
          style={{
            padding: "12px 14px",
            borderRadius: 14,
            border: `1px solid ${c.black}`,
            background: c.black,
            color: c.blackContrast,
            fontWeight: 700,
            cursor: !canCreate ? "not-allowed" : "pointer",
            opacity: !canCreate ? 0.6 : 1,
          }}
        >
          {loading ? "Creating…" : "Create draft"}
        </button>
      </div>
    </div>
  );
}
