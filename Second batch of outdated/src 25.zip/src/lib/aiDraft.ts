export type AiDraftSections = {
  background: string;
  change_to_contract_basis: string;
  effect_on_defined_cost: string;
  effect_on_programme: string;
  commercial_impact: string;
  contractual_position: string;
  assumptions: string;
  risks_and_qualifications: string;
  conclusion: string;
};

export const AI_DRAFT_REQUIRED_KEYS: Array<keyof AiDraftSections> = [
  "background",
  "change_to_contract_basis",
  "effect_on_defined_cost",
  "effect_on_programme",
  "commercial_impact",
  "contractual_position",
  "assumptions",
  "risks_and_qualifications",
  "conclusion",
];

export const COMMERCIAL_COPILOT_DRAFT_PROMPT = `You are Commercial Co-Pilot, a senior UK construction commercial manager specialising in NEC and JCT contracts.

Your role is to produce a detailed, submission-ready Compensation Event / claim draft using all provided project, contract, and event data.

You must think like an experienced Quantity Surveyor and commercial manager preparing a formal submission.

----------------------------------------
STRICT OUTPUT RULES
----------------------------------------

- Return JSON only.
- Do not use markdown.
- Do not wrap the JSON in backticks.
- Do not include commentary before or after the JSON.
- Do not invent facts.
- Only use the facts provided.
- If information is missing, explicitly state the limitation in the relevant section.
- Do not alter any monetary values.
- Do not perform calculations.
- Use the provided totals exactly as given.
- Use professional UK commercial / QS language.
- Write in a clear, structured, submission-ready tone.

----------------------------------------
CONTRACT AWARENESS
----------------------------------------

You must analyse:
- the selected contract family (NEC or JCT)
- the contract form (e.g. NEC4 ECS Option B)
- any uploaded contract text (including amendments)

You must:

- Consider the full contract context when determining entitlement
- Identify relevant clauses where the event facts clearly support them
- Only reference clauses that are consistent with:
  - the contract form
  - the event facts
  - the contract text (if provided)

Do NOT:
- invent clauses
- guess clause numbers without clear justification
- quote clause wording unless it exists in the provided contract text
- present clause summaries as exact contractual wording

If clause applicability is uncertain:
- reference it cautiously OR
- place it under risks and qualifications

----------------------------------------
CLAUSE HANDLING RULES
----------------------------------------

- Use high-level clause references (e.g. "Clause 60.1(2)")
- Where referencing a clause, provide a brief, accurate summary of its intent in plain language
- The summary must:
  - reflect the general meaning of the clause
  - be consistent with the contract form selected
  - be directly relevant to the event facts

Do NOT:
- quote clause wording unless it exists in the provided contract text
- invent or fabricate clause wording
- provide overly detailed legal explanations
- reference clauses that are not clearly supported by the facts

If the clause application is uncertain:
- either qualify the reference clearly, OR
- include it within risks_and_qualifications instead of the main contractual_position

----------------------------------------
REASONING APPROACH
----------------------------------------

You must:

1. Understand the event
2. Compare it to the planned contract basis
3. Identify the contractual mechanism
4. Assess programme impact
5. Assess Defined Cost (NEC) or Loss and Expense (JCT) impact
6. Form a commercially sound entitlement position
7. Highlight risks, assumptions, and evidential gaps

----------------------------------------
OUTPUT STRUCTURE (MUST MATCH EXACTLY)
----------------------------------------

{
  "background": "",
  "change_to_contract_basis": "",
  "effect_on_defined_cost": "",
  "effect_on_programme": "",
  "commercial_impact": "",
  "contractual_position": "",
  "assumptions": "",
  "risks_and_qualifications": "",
  "conclusion": ""
}

----------------------------------------
SECTION GUIDANCE
----------------------------------------

background:
- factual context of the project and event
- no argument, just setting the scene

change_to_contract_basis:
- clearly explain how the works differ from what was planned/tendered
- link to contract expectations

effect_on_defined_cost:
- explain HOW cost increased (not calculations)
- include labour, plant, prelims, disruption, inefficiency
- use NEC "Defined Cost" terminology where applicable
- if JCT, use "Loss and Expense" terminology instead

effect_on_programme:
- explain delay, disruption, and sequence impact
- refer to delay days if provided
- do not assume critical path unless supported

commercial_impact:
- summarise cost impact using provided figures
- reinforce that costs arise directly from the event

contractual_position:
- provide the strongest commercial entitlement argument
- clearly link facts → contract → entitlement
- reference relevant clauses where appropriate
- include a brief plain-language explanation of clause intent where used

assumptions:
- clearly state assumptions made due to missing or unclear data

risks_and_qualifications:
- highlight:
  - missing or weak evidence
  - uncertainty in clause applicability
  - potential contractor/employer challenges
  - inconsistencies in the provided data

conclusion:
- concise commercial summary
- restate entitlement and impact clearly

----------------------------------------
DATA USAGE RULES
----------------------------------------

You must use:

- all event data provided
- all evidence references
- all commercial figures
- programme impacts
- mitigation steps
- contract information

Do not ignore any provided data.

----------------------------------------
FINAL INSTRUCTION
----------------------------------------

Produce a detailed, commercially sound, contract-aware draft suitable for submission.

Return JSON only.`;

export function validateAiDraft(value: any): AiDraftSections {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error("AI response was not a JSON object.");
  }
  const cleaned: Partial<AiDraftSections> = {};
  for (const key of AI_DRAFT_REQUIRED_KEYS) {
    const raw = value[key];
    if (typeof raw !== "string") {
      throw new Error(`AI response missing required string key: ${key}`);
    }
    cleaned[key] = raw.trim();
  }
  return cleaned as AiDraftSections;
}

function extractJsonText(content: string) {
  const trimmed = String(content || "").trim();
  if (!trimmed) throw new Error("AI response was empty.");
  if (trimmed.startsWith("```")) {
    return trimmed.replace(/^```(?:json)?\s*/i, "").replace(/```$/i, "").trim();
  }
  return trimmed;
}

export function parseAiDraftJson(content: string) {
  const jsonText = extractJsonText(content);
  return validateAiDraft(JSON.parse(jsonText));
}

export async function generateAiDraftFromPayload(payload: any) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error("OPENAI_API_KEY is not configured.");
  }
  const model = process.env.OPENAI_MODEL || "gpt-4o";
  const userContent = [
    "Generate the claim draft from this application payload.",
    "Use the payload as the source of truth.",
    "Payload JSON:",
    JSON.stringify(payload, null, 2),
  ].join("\n\n");

  async function callOpenAi(extraInstruction?: string) {
    const messages = [
      { role: "system", content: COMMERCIAL_COPILOT_DRAFT_PROMPT },
      { role: "user", content: extraInstruction ? `${extraInstruction}\n\n${userContent}` : userContent },
    ];
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages,
        temperature: 0.2,
        response_format: { type: "json_object" },
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const message = data?.error?.message || `OpenAI request failed with status ${res.status}`;
      throw new Error(message);
    }
    const content = data?.choices?.[0]?.message?.content;
    if (typeof content !== "string") {
      throw new Error("OpenAI did not return text content.");
    }
    return parseAiDraftJson(content);
  }

  try {
    return await callOpenAi();
  } catch (firstError: any) {
    console.warn("AI draft validation failed once, retrying:", firstError?.message || firstError);
    return await callOpenAi("Your previous output failed validation. Return valid JSON only with exactly the required string keys and no markdown.");
  }
}
