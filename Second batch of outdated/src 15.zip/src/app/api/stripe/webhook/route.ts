import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { DEFAULT_MONTHLY_CREDITS } from "@/lib/billing";

export const dynamic = "force-dynamic";

const stripeSecretKey = process.env.STRIPE_SECRET_KEY;
const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

function getStripe() {
  if (!stripeSecretKey) throw new Error("STRIPE_SECRET_KEY is not configured");
  return new Stripe(stripeSecretKey);
}

async function upsertBillingTransaction(admin: any, payload: {
  stripe_event_id?: string | null;
  stripe_invoice_id?: string | null;
  stripe_customer_id?: string | null;
  stripe_subscription_id?: string | null;
  user_id?: string | null;
  amount?: number | null;
  currency?: string | null;
  status?: string | null;
  type?: string | null;
  raw_payload?: any;
}) {
  const insert = {
    stripe_event_id: payload.stripe_event_id || null,
    stripe_invoice_id: payload.stripe_invoice_id || null,
    stripe_customer_id: payload.stripe_customer_id || null,
    stripe_subscription_id: payload.stripe_subscription_id || null,
    user_id: payload.user_id || null,
    amount: payload.amount || 0,
    currency: payload.currency || "gbp",
    status: payload.status || "pending",
    type: payload.type || "subscription",
    raw_payload: payload.raw_payload || null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  const { error } = await admin.from("billing_transactions").upsert(insert, { onConflict: "stripe_event_id" });
  if (error && !/relation .*billing_transactions.* does not exist/i.test(error.message)) throw error;
}

async function ensureCreditsRow(admin: any, userId: string, creditsRemaining: number) {
  const { error } = await admin.from("user_credits").upsert({
    user_id: userId,
    credits_remaining: creditsRemaining,
    updated_at: new Date().toISOString(),
  }, { onConflict: "user_id" });
  if (error) throw error;
}

export async function POST(req: NextRequest) {
  try {
    if (!webhookSecret) {
      return NextResponse.json({ error: "STRIPE_WEBHOOK_SECRET is not configured" }, { status: 500 });
    }

    const stripe = getStripe();
    const body = await req.text();
    const signature = req.headers.get("stripe-signature");
    if (!signature) return NextResponse.json({ error: "Missing Stripe signature" }, { status: 400 });

    const event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
    const admin = supabaseAdmin();

    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const userId = session.metadata?.user_id || session.client_reference_id || null;
        const stripeCustomerId = typeof session.customer === "string" ? session.customer : session.customer?.id || null;
        const stripeSubscriptionId = typeof session.subscription === "string" ? session.subscription : session.subscription?.id || null;

        if (userId) {
          const { error } = await admin
            .from("profiles")
            .upsert({
              id: userId,
              stripe_customer_id: stripeCustomerId,
              stripe_subscription_id: stripeSubscriptionId,
              subscription_status: "active",
              plan_type: "pro_monthly",
              updated_at: new Date().toISOString(),
            }, { onConflict: "id" });
          if (error) throw error;
        }

        await upsertBillingTransaction(admin, {
          stripe_event_id: event.id,
          stripe_customer_id: stripeCustomerId,
          stripe_subscription_id: stripeSubscriptionId,
          user_id: userId,
          status: "checkout_completed",
          type: "subscription_checkout",
          raw_payload: session,
        });
        break;
      }

      case "invoice.paid": {
        const invoice = event.data.object as Stripe.Invoice;
        const stripeCustomerId = typeof invoice.customer === "string" ? invoice.customer : invoice.customer?.id || null;
        const stripeSubscriptionId = typeof invoice.subscription === "string" ? invoice.subscription : invoice.subscription?.id || null;

        const { data: profile, error: profileError } = await admin
          .from("profiles")
          .select("id")
          .eq("stripe_customer_id", stripeCustomerId)
          .maybeSingle();
        if (profileError) throw profileError;

        if (profile?.id) {
          const periodEndUnix = (invoice.lines.data[0]?.period?.end ?? null) as number | null;
          const currentPeriodEnd = periodEndUnix ? new Date(periodEndUnix * 1000).toISOString() : null;

          const { error } = await admin
            .from("profiles")
            .update({
              subscription_status: "active",
              plan_type: "pro_monthly",
              stripe_subscription_id: stripeSubscriptionId,
              current_period_end: currentPeriodEnd,
              updated_at: new Date().toISOString(),
            })
            .eq("id", profile.id);
          if (error) throw error;

          await ensureCreditsRow(admin, profile.id, DEFAULT_MONTHLY_CREDITS);
        }

        await upsertBillingTransaction(admin, {
          stripe_event_id: event.id,
          stripe_invoice_id: invoice.id,
          stripe_customer_id: stripeCustomerId,
          stripe_subscription_id: stripeSubscriptionId,
          user_id: profile?.id || null,
          amount: typeof invoice.amount_paid === "number" ? invoice.amount_paid / 100 : 0,
          currency: invoice.currency || "gbp",
          status: "paid",
          type: "subscription_invoice",
          raw_payload: invoice,
        });
        break;
      }

      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        const stripeCustomerId = typeof subscription.customer === "string" ? subscription.customer : subscription.customer?.id || null;
        const currentPeriodEnd = subscription.current_period_end
          ? new Date(subscription.current_period_end * 1000).toISOString()
          : null;

        const { error } = await admin
          .from("profiles")
          .update({
            subscription_status: subscription.status,
            stripe_customer_id: stripeCustomerId,
            stripe_subscription_id: subscription.id,
            current_period_end: currentPeriodEnd,
            updated_at: new Date().toISOString(),
          })
          .eq("stripe_subscription_id", subscription.id);

        if (error) throw error;

        await upsertBillingTransaction(admin, {
          stripe_event_id: event.id,
          stripe_customer_id: stripeCustomerId,
          stripe_subscription_id: subscription.id,
          status: subscription.status,
          type: event.type,
          raw_payload: subscription,
        });
        break;
      }

      default:
        break;
    }

    return NextResponse.json({ received: true });
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || "Stripe webhook failed" }, { status: 400 });
  }
}
