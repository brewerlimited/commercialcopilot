export type FinancialSummaryResourceRow = {
  category?: string | null;
  total?: number | null;
};

export type FinancialSummaryPrelimRow = {
  qty?: number | null;
  unit?: string | null;
  rate?: number | null;
  prelim_type?: string | null;
};

export type FinancialSummaryValuation = {
  fee_percent?: number | null;
  fee_basis?: "defined_cost" | "defined_cost_plus_prelims" | string | null;
  work_days_per_week?: number | null;
};

export type EventFinancialSummary = {
  labour_total: number;
  plant_total: number;
  material_total: number;
  subcontract_total: number;
  staff_prelims_total: number;
  other_prelims_total: number;
  prelims_total: number;
  defined_cost_total: number;
  fee_percent: number;
  fee_basis: "defined_cost" | "defined_cost_plus_prelims";
  fee_amount: number;
  delay_days: number;
  final_total: number;
};

function num(v: unknown) {
  const n = typeof v === "number" ? v : parseFloat(String(v ?? 0));
  return Number.isFinite(n) ? n : 0;
}

function round2(n: number) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

export function calculateEventFinancialSummary(args: {
  resources?: FinancialSummaryResourceRow[] | null;
  prelims?: FinancialSummaryPrelimRow[] | null;
  valuation?: FinancialSummaryValuation | null;
  delayDays?: number | null;
}) : EventFinancialSummary {
  const resources = args.resources ?? [];
  const prelims = args.prelims ?? [];
  const valuation = args.valuation ?? {};
  const delayDays = Math.max(0, num(args.delayDays));
  const workDaysPerWeek = Math.max(1, Math.min(7, num(valuation.work_days_per_week) || 5));

  const labour_total = resources.filter(r => (r.category ?? '').toLowerCase() === 'labour').reduce((s,r)=> s + num(r.total), 0);
  const plant_total = resources.filter(r => (r.category ?? '').toLowerCase() === 'plant').reduce((s,r)=> s + num(r.total), 0);
  const material_total = resources.filter(r => ['material','materials'].includes((r.category ?? '').toLowerCase())).reduce((s,r)=> s + num(r.total), 0);
  const subcontract_total = resources.filter(r => (r.category ?? '').toLowerCase() === 'subcontract').reduce((s,r)=> s + num(r.total), 0);

  const staff_prelims_total = prelims
    .filter(p => (p.prelim_type ?? '').toLowerCase() === 'staff')
    .reduce((s,p)=> {
      const daily = (p.unit ?? 'day') === 'week' ? num(p.rate) / workDaysPerWeek : num(p.rate);
      return s + (num(p.qty) * daily * delayDays);
    }, 0);

  const other_prelims_total = prelims
    .filter(p => (p.prelim_type ?? '').toLowerCase() !== 'staff')
    .reduce((s,p)=> {
      const daily = (p.unit ?? 'day') === 'week' ? num(p.rate) / workDaysPerWeek : num(p.rate);
      return s + (num(p.qty) * daily * delayDays);
    }, 0);

  const prelims_total = staff_prelims_total + other_prelims_total;
  const defined_cost_total = labour_total + plant_total + material_total + subcontract_total;
  const fee_percent = num(valuation.fee_percent);
  const fee_basis = valuation.fee_basis === 'defined_cost_plus_prelims' ? 'defined_cost_plus_prelims' : 'defined_cost';
  const fee_base = fee_basis === 'defined_cost_plus_prelims' ? defined_cost_total + prelims_total : defined_cost_total;
  const fee_amount = fee_base * (fee_percent / 100);
  const final_total = defined_cost_total + prelims_total + fee_amount;

  return {
    labour_total: round2(labour_total),
    plant_total: round2(plant_total),
    material_total: round2(material_total),
    subcontract_total: round2(subcontract_total),
    staff_prelims_total: round2(staff_prelims_total),
    other_prelims_total: round2(other_prelims_total),
    prelims_total: round2(prelims_total),
    defined_cost_total: round2(defined_cost_total),
    fee_percent: round2(fee_percent),
    fee_basis,
    fee_amount: round2(fee_amount),
    delay_days: round2(delayDays),
    final_total: round2(final_total),
  };
}
