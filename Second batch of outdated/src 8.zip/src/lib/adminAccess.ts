export function normalizeEmail(email?: string | null) {
  return (email || "").trim().toLowerCase();
}

function parseConfiguredEmails(raw?: string | null) {
  return (raw || "")
    .split(",")
    .map((v) => normalizeEmail(v))
    .filter(Boolean);
}

export function getConfiguredAdminEmails() {
  const publicEmails = parseConfiguredEmails(process.env.NEXT_PUBLIC_ADMIN_EMAILS);
  const serverEmails = parseConfiguredEmails(process.env.ADMIN_EMAILS);
  return Array.from(new Set([...publicEmails, ...serverEmails]));
}

export function matchesConfiguredAdminEmail(email?: string | null) {
  const normalized = normalizeEmail(email);
  if (!normalized) return false;
  return getConfiguredAdminEmails().includes(normalized);
}
