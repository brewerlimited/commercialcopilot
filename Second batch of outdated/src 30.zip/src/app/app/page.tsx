"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { supabaseBrowser } from "@/lib/supabase/client";
import { getContractLabel } from "@/lib/contracts";
import { readFinalTotal } from "@/lib/financialSummary";
import { getRequiredUser, isAuthErrorMessage } from "@/lib/security";

type EventRow = {
  id: string;
  title: string | null;
  status: string | null;
  created_at?: string | null;
  contract_type?: string | null;
  project_name?: string | null;
  main_contractor?: string | null;
  event_financial_summary?: unknown;
};

type PipelineTotals = {
  draft: number;
  review: number;
  ready: number;
};

type EventValueMap = Record<string, number | null>;

type RateCardStatus = {
  labour: number;
  plant: number;
  materials: number;
  lastUpdated: string | null;
};

type FocusProgress = {
  basis: boolean;
  evidence: boolean;
  resources: boolean;
  prelims: boolean;
  review: boolean;
};

const c = {
  bg: "#f6f7fb",
  card: "#ffffff",
  border: "#e5e7eb",
  borderStrong: "#d7dce5",
  sub: "#475569",
  text: "#111827",
  black: "#111827",
  soft: "#f8fafc",
  softBlue: "#f5f8ff",
  greenBg: "#ecfdf5",
  greenBd: "#a7f3d0",
  greenTx: "#065f46",
  amberBg: "#fffbeb",
  amberBd: "#fde68a",
  amberTx: "#92400e",
  blueBg: "#eff6ff",
  blueBd: "#bfdbfe",
  blueTx: "#1d4ed8",
};

function niceDate(v?: string | null) {
  if (!v) return "—";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function normaliseStatus(status?: string | null) {
  return (status || "draft").toLowerCase();
}

function money(v: number) {
  return new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency: "GBP",
    maximumFractionDigits: 2,
  }).format(Number.isFinite(v) ? v : 0);
}

function displayCeTotal(value: number | null | undefined) {
  return value === null || value === undefined ? "Not calculated yet" : money(value);
}
function projectContext(e: EventRow) {
  const project = e.project_name?.trim();
  const contractor = e.main_contractor?.trim();
  if (project && contractor) return `${project} — ${contractor}`;
  if (project) return project;
  if (contractor) return contractor;
  return "Project not set";
}

function contractLabel(v?: string | null) {
  return getContractLabel(v);
}

function statusTone(status?: string | null) {
  const s = normaliseStatus(status);

  if (s === "ready" || s === "complete") {
    return {
      bg: c.greenBg,
      bd: c.greenBd,
      tx: c.greenTx,
      label: status || "Ready",
    };
  }

  if (s === "submitted") {
    return {
      bg: c.blueBg,
      bd: c.blueBd,
      tx: c.blueTx,
      label: status || "Submitted",
    };
  }

  if (s === "review") {
    return {
      bg: c.amberBg,
      bd: c.amberBd,
      tx: c.amberTx,
      label: status || "Review",
    };
  }

  return {
    bg: "#fff",
    bd: c.border,
    tx: c.sub,
    label: status || "Draft",
  };
}

function SectionCard({
  title,
  hint,
  children,
}: {
  title: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <section
      style={{
        background: c.card,
        border: `1px solid ${c.border}`,
        borderRadius: 24,
        padding: 24,
        boxShadow: "0 1px 2px rgba(15,23,42,0.03)",
      }}
    >
      <div style={{ display: "grid", gap: 6, marginBottom: 18 }}>
        <div
          style={{
            fontSize: 17,
            lineHeight: 1.2,
            fontWeight: 700,
            color: c.text,
            letterSpacing: -0.3,
          }}
        >
          {title}
        </div>

        {hint ? (
          <div
            style={{
              fontSize: 13,
              lineHeight: 1.55,
              color: c.sub,
              maxWidth: 760,
            }}
          >
            {hint}
          </div>
        ) : null}
      </div>

      {children}
    </section>
  );
}

function StatCard({
  label,
  value,
  tone = "default",
}: {
  label: string;
  value: React.ReactNode;
  tone?: "default" | "green" | "blue" | "amber";
}) {
  const toneMap =
    tone === "green"
      ? { bg: c.greenBg, bd: c.greenBd }
      : tone === "blue"
      ? { bg: c.blueBg, bd: c.blueBd }
      : tone === "amber"
      ? { bg: c.amberBg, bd: c.amberBd }
      : { bg: "#fff", bd: c.border };

  return (
    <div
      style={{
        background: toneMap.bg,
        border: `1px solid ${toneMap.bd}`,
        borderRadius: 18,
        padding: 18,
        minHeight: 118,
        display: "grid",
        alignContent: "space-between",
        gap: 10,
      }}
    >
      <div
        style={{
          fontSize: 11,
          fontWeight: 700,
          color: c.sub,
          textTransform: "uppercase",
          letterSpacing: 0.55,
        }}
      >
        {label}
      </div>

      <div
        style={{
          fontSize: 30,
          fontWeight: 700,
          color: c.text,
          letterSpacing: -0.8,
          lineHeight: 0.95,
        }}
      >
        {value}
      </div>
    </div>
  );
}

function QuietButton({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link href={href} style={{ textDecoration: "none" }}>
      <button
        style={{
          height: 46,
          padding: "0 15px",
          borderRadius: 15,
          border: `1px solid ${c.border}`,
          background: "#fff",
          color: c.text,
          fontWeight: 600,
          fontSize: 14,
          cursor: "pointer",
        }}
      >
        {children}
      </button>
    </Link>
  );
}

export default function AppHome() {
  const [events, setEvents] = useState<EventRow[]>([]);
  const [eventValues, setEventValues] = useState<EventValueMap>({});
  const [loading, setLoading] = useState(true);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [renameSavingId, setRenameSavingId] = useState<string | null>(null);
  const [focusProgress, setFocusProgress] = useState<FocusProgress | null>(null);
  const [focusLoading, setFocusLoading] = useState(false);
  const [pipelineTotals, setPipelineTotals] = useState<PipelineTotals>({ draft: 0, review: 0, ready: 0 });
  const [pipelineLoading, setPipelineLoading] = useState(false);
  const [rateCardStatus, setRateCardStatus] = useState<RateCardStatus>({ labour: 0, plant: 0, materials: 0, lastUpdated: null });

  useEffect(() => {
    let active = true;

    (async () => {
      const supabase = supabaseBrowser();

      try {
        const user = await getRequiredUser(supabase);
        const [eventsResult, { data: rateCardData, error: rateCardError }] = await Promise.all([
          supabase
            .from("events")
            .select("id,title,status,created_at,contract_type,project_name,main_contractor,event_financial_summary")
            .eq("user_id", user.id)
            .order("created_at", { ascending: false }),
          supabase
            .from("rate_cards")
            .select("category,updated_at,active")
            .eq("user_id", user.id)
            .eq("active", true)
            .order("updated_at", { ascending: false }),
        ]);

        let eventsData = eventsResult.data;
        if (eventsResult.error) {
          const message = String(eventsResult.error.message || "");
          const missingSummaryColumn = /event_financial_summary/i.test(message) && /does not exist|schema cache|column/i.test(message);
          if (!missingSummaryColumn) throw eventsResult.error;

          const fallback = await supabase
            .from("events")
            .select("id,title,status,created_at,contract_type,project_name,main_contractor")
            .eq("user_id", user.id)
            .order("created_at", { ascending: false });
          if (fallback.error) throw fallback.error;
          eventsData = fallback.data;
        }

        if (rateCardError) throw rateCardError;

        if (active && eventsData) setEvents(eventsData as EventRow[]);

        if (active) {
          const rows = (rateCardData ?? []) as Array<{ category: string | null; updated_at?: string | null }>;
          const labour = rows.filter((r) => r.category === "labour").length;
          const plant = rows.filter((r) => r.category === "plant").length;
          const materials = rows.filter((r) => r.category === "materials").length;
          setRateCardStatus({
            labour,
            plant,
            materials,
            lastUpdated: rows[0]?.updated_at ?? null,
          });
        }
      } catch (e: any) {
        if (isAuthErrorMessage(e?.message)) {
          window.location.href = "/login";
          return;
        }
        console.error("Failed to load dashboard events", e);
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    })();

    return () => {
      active = false;
    };
  }, []);

  const totals = useMemo(() => {
    const total = events.length;
    const drafts = events.filter((e) => normaliseStatus(e.status) === "draft").length;
    const ready = events.filter((e) => {
      const s = normaliseStatus(e.status);
      return s === "ready" || s === "complete";
    }).length;
    const inReview = events.filter((e) => normaliseStatus(e.status) === "review").length;

    return { total, drafts, ready, inReview };
  }, [events]);

  const latestFive = useMemo(() => events.slice(0, 5), [events]);
  const latestEvent = latestFive[0] ?? null;

  const focusItems = useMemo(() => {
    if (!focusProgress) return [] as Array<{ label: string; done: boolean; kind: "done" | "warning" | "pending" }>;

    return [
      { label: "Basis of Change", done: focusProgress.basis, kind: focusProgress.basis ? "done" : "warning" as const },
      { label: "Evidence", done: focusProgress.evidence, kind: focusProgress.evidence ? "done" : "warning" as const },
      { label: "Resources", done: focusProgress.resources, kind: focusProgress.resources ? "done" : "warning" as const },
      { label: "Prelims", done: focusProgress.prelims, kind: focusProgress.prelims ? "done" : "warning" as const },
      { label: "Review", done: focusProgress.review, kind: focusProgress.review ? "done" : "pending" as const },
    ];
  }, [focusProgress]);

  const nextFocusAction = useMemo(() => {
    if (!latestEvent || !focusProgress) return null;
    if (!focusProgress.basis) return { label: "Continue Basis of Change", href: `/app/event/${latestEvent.id}` };
    if (!focusProgress.evidence) return { label: "Continue Evidence", href: `/app/event/${latestEvent.id}/evidence` };
    if (!focusProgress.resources) return { label: "Continue Resources", href: `/app/event/${latestEvent.id}/resources` };
    if (!focusProgress.prelims) return { label: "Continue Prelims", href: `/app/event/${latestEvent.id}/prelims` };
    if (!focusProgress.review) return { label: "Continue Review", href: `/app/event/${latestEvent.id}/review` };
    return { label: "Open latest CE", href: `/app/event/${latestEvent.id}/review` };
  }, [focusProgress, latestEvent]);

  useEffect(() => {
    let active = true;

    (async () => {
      if (!latestEvent?.id) {
        if (active) {
          setFocusProgress(null);
          setFocusLoading(false);
        }
        return;
      }

      const supabase = supabaseBrowser();
      setFocusLoading(true);

      try {
        const [basisRes, filesRes, contractFilesRes, resourcesRes, prelimsRes, reviewRes] = await Promise.all([
          supabase
            .from("event_basis")
            .select("happened_summary,cause_type,cause_summary,difference_from_plan,mechanism_tags,mitigation_summary")
            .eq("event_id", latestEvent.id)
            .maybeSingle(),
          supabase
            .from("event_files")
            .select("id", { count: "exact", head: true })
            .eq("event_id", latestEvent.id),
          supabase
            .from("event_contract_files")
            .select("id", { count: "exact", head: true })
            .eq("event_id", latestEvent.id),
          supabase
            .from("event_resource_lines")
            .select("id", { count: "exact", head: true })
            .eq("event_id", latestEvent.id),
          supabase
            .from("event_prelim_lines")
            .select("id", { count: "exact", head: true })
            .eq("event_id", latestEvent.id),
          supabase
            .from("event_review_settings")
            .select("id", { count: "exact", head: true })
            .eq("event_id", latestEvent.id),
        ]);

        const basis = basisRes.data as
          | {
              happened_summary?: string | null;
              cause_type?: string | null;
              cause_summary?: string | null;
              difference_from_plan?: string | null;
              mechanism_tags?: string[] | null;
              mitigation_summary?: string | null;
            }
          | null;

        const basisComplete = Boolean(
          basis &&
            ((basis.happened_summary || "").trim() ||
              (basis.cause_summary || "").trim() ||
              (basis.difference_from_plan || "").trim() ||
              (basis.mitigation_summary || "").trim() ||
              basis.cause_type ||
              (basis.mechanism_tags?.length || 0) > 0)
        );

        const nextProgress: FocusProgress = {
          basis: basisComplete,
          evidence: ((filesRes.count || 0) + (contractFilesRes.count || 0)) > 0,
          resources: (resourcesRes.count || 0) > 0,
          prelims: (prelimsRes.count || 0) > 0,
          review: (reviewRes.count || 0) > 0,
        };

        if (active) setFocusProgress(nextProgress);
      } catch (err) {
        console.error("Failed to load dashboard focus progress", err);
        if (active) setFocusProgress(null);
      } finally {
        if (active) setFocusLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, [latestEvent?.id]);

  useEffect(() => {
    let active = true;

    (async () => {
      if (!events.length) {
        if (active) {
          setPipelineTotals({ draft: 0, review: 0, ready: 0 });
          setEventValues({});
          setPipelineLoading(false);
        }
        return;
      }

      setPipelineLoading(true);

      try {
        const next: PipelineTotals = { draft: 0, review: 0, ready: 0 };
        const nextEventValues: EventValueMap = {};

        for (const event of events) {
          const totalValue = readFinalTotal(event.event_financial_summary);
          const status = normaliseStatus(event.status);

          nextEventValues[event.id] = totalValue;

          if (totalValue === null) continue;

          if (status === "review") next.review += totalValue;
          else if (status === "ready" || status === "complete") next.ready += totalValue;
          else next.draft += totalValue;
        }

        if (active) {
          setPipelineTotals(next);
          setEventValues(nextEventValues);
        }
      } catch (err) {
        console.error("Failed to load dashboard pipeline values", err);
        if (active) {
          setPipelineTotals({ draft: 0, review: 0, ready: 0 });
          setEventValues({});
        }
      } finally {
        if (active) setPipelineLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, [events]);



  function startRename(event: EventRow) {
    setRenamingId(event.id);
    setRenameValue(event.title || "");
  }

  function cancelRename() {
    setRenamingId(null);
    setRenameValue("");
  }

  async function saveRename(eventId: string) {
    const nextTitle = renameValue.trim();
    if (!nextTitle) return;

    try {
      setRenameSavingId(eventId);
      const supabase = supabaseBrowser();
      const user = await getRequiredUser(supabase);
      const { error } = await supabase
        .from("events")
        .update({ title: nextTitle })
        .eq("id", eventId)
        .eq("user_id", user.id);
      if (error) throw error;
      setEvents((prev) => prev.map((e) => (e.id === eventId ? { ...e, title: nextTitle } : e)));
      cancelRename();
    } catch (err) {
      console.error("Failed to rename CE", err);
    } finally {
      setRenameSavingId(null);
    }
  }

  return (
    <div style={{ background: c.bg, minHeight: "100vh" }}>
      <div style={{ maxWidth: 1240, margin: "0 auto", padding: "28px 24px 36px" }}>
        <div style={{ display: "grid", gap: 16 }}>
          <section
            style={{
              background: c.card,
              border: `1px solid ${c.border}`,
              borderRadius: 28,
              padding: 28,
              boxShadow: "0 1px 2px rgba(15,23,42,0.03)",
            }}
          >
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "minmax(0, 1.55fr) minmax(320px, 0.9fr)",
                gap: 24,
                alignItems: "start",
              }}
            >
              <div style={{ display: "grid", gap: 18, alignContent: "start" }}>
                <div style={{ display: "grid", gap: 12 }}>
                  <div
                    style={{
                      fontSize: 12,
                      fontWeight: 700,
                      color: c.sub,
                      letterSpacing: 0.65,
                      textTransform: "uppercase",
                    }}
                  >
                    Commercial workspace
                  </div>

                  <div
                    style={{
                      fontSize: 22,
                      fontWeight: 600,
                      lineHeight: 1.35,
                      letterSpacing: -0.45,
                      color: c.text,
                      maxWidth: 680,
                    }}
                  >
                    Prepare stronger Compensation Events with structured workflow, evidence alignment and deterministic pricing.
                  </div>

                  <div
                    style={{
                      fontSize: 13,
                      lineHeight: 1.6,
                      color: c.sub,
                      maxWidth: 700,
                    }}
                  >
                    Keep active CEs moving cleanly from basis through to review.
                  </div>
                </div>

                <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                  <Link href="/app/new" style={{ textDecoration: "none" }}>
                    <button
                      style={{
                        height: 48,
                        padding: "0 16px",
                        borderRadius: 16,
                        border: `1px solid ${c.black}`,
                        background: c.black,
                        color: "#fff",
                        fontWeight: 700,
                        fontSize: 14,
                        cursor: "pointer",
                      }}
                    >
                      New Compensation Event
                    </button>
                  </Link>

                  {latestEvent ? (
                    <QuietButton href={`/app/event/${latestEvent.id}`}>Continue latest</QuietButton>
                  ) : null}

                  <QuietButton href="/app/rates">Rate cards</QuietButton>
                </div>

                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
                    gap: 14,
                  }}
                >
                  <StatCard label="Total CEs" value={totals.total} />
                  <StatCard label="Drafts" value={totals.drafts} tone="amber" />
                  <StatCard label="In review" value={totals.inReview} tone="blue" />
                  <StatCard label="Ready / complete" value={totals.ready} tone="green" />
                </div>

                <div
                  style={{
                    background: "#fff",
                    border: `1px solid ${c.border}`,
                    borderRadius: 18,
                    padding: 18,
                    display: "grid",
                    gridTemplateColumns: "minmax(220px, 1.1fr) minmax(0, 1.65fr)",
                    gap: 18,
                    alignItems: "center",
                  }}
                >
                  <div style={{ display: "grid", gap: 4, alignContent: "start" }}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: c.sub, textTransform: "uppercase", letterSpacing: 0.45 }}>
                      Pipeline value
                    </div>
                    <div style={{ fontSize: 13, color: c.sub, lineHeight: 1.55, maxWidth: 280 }}>
                      Saved CE totals from the financial summary engine. Dashboard is display-only and does not recalculate values.
                    </div>
                  </div>

                  {pipelineLoading ? (
                    <div style={{ fontSize: 13, color: c.sub, lineHeight: 1.6, textAlign: "right" }}>Calculating live CE values…</div>
                  ) : (
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 18 }}>
                      <div style={{ display: "grid", gap: 6, justifyItems: "end" }}>
                        <div style={{ fontSize: 11, fontWeight: 700, color: c.sub, textTransform: "uppercase", letterSpacing: 0.45 }}>Drafts</div>
                        <div style={{ fontSize: 22, fontWeight: 700, color: c.text, letterSpacing: -0.4 }}>{money(pipelineTotals.draft)}</div>
                      </div>
                      <div style={{ display: "grid", gap: 6, justifyItems: "end" }}>
                        <div style={{ fontSize: 11, fontWeight: 700, color: c.sub, textTransform: "uppercase", letterSpacing: 0.45 }}>In review</div>
                        <div style={{ fontSize: 22, fontWeight: 700, color: c.text, letterSpacing: -0.4 }}>{money(pipelineTotals.review)}</div>
                      </div>
                      <div style={{ display: "grid", gap: 6, justifyItems: "end" }}>
                        <div style={{ fontSize: 11, fontWeight: 700, color: c.sub, textTransform: "uppercase", letterSpacing: 0.45 }}>Ready</div>
                        <div style={{ fontSize: 22, fontWeight: 700, color: c.text, letterSpacing: -0.4 }}>{money(pipelineTotals.ready)}</div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div
                style={{
                  background: c.softBlue,
                  border: `1px solid ${c.borderStrong}`,
                  borderRadius: 22,
                  padding: 20,
                  display: "grid",
                  gap: 16,
                  alignContent: "start",
                }}
              >
                <div style={{ display: "grid", gap: 4 }}>
                  <div
                    style={{
                      fontSize: 12,
                      fontWeight: 700,
                      color: c.sub,
                      letterSpacing: 0.55,
                      textTransform: "uppercase",
                    }}
                  >
                    Current focus
                  </div>
                  <div style={{ fontSize: 15, fontWeight: 500, color: c.sub, letterSpacing: -0.15, lineHeight: 1.5 }}>
                    {latestEvent ? "Continue preparing latest Compensation Event" : "Create your first Compensation Event"}
                  </div>
                </div>

                <div style={{ display: "grid", gap: 12 }}>
                  <div
                    style={{
                      background: "#fff",
                      border: `1px solid ${c.border}`,
                      borderRadius: 16,
                      padding: 14,
                      display: "grid",
                      gap: 5,
                    }}
                  >
                    <div style={{ fontSize: 12, fontWeight: 700, color: c.sub, textTransform: "uppercase", letterSpacing: 0.45 }}>
                      Latest activity
                    </div>
                    <div style={{ fontSize: 15, fontWeight: 700, color: c.text, lineHeight: 1.3 }}>
                      {latestEvent ? latestEvent.title || "Untitled CE" : "No CE drafts yet"}
                    </div>
                    <div style={{ fontSize: 13, color: c.sub, lineHeight: 1.5 }}>
                      {latestEvent
                        ? `Created ${niceDate(latestEvent.created_at)} • ${statusTone(latestEvent.status).label}`
                        : "Create your first event to start building a live submission pack."}
                    </div>
                  </div>

                  {latestEvent ? (
                    <div
                      style={{
                        background: "#fff",
                        border: `1px solid ${c.border}`,
                        borderRadius: 16,
                        padding: 14,
                        display: "grid",
                        gap: 12,
                      }}
                    >
                      <div style={{ display: "grid", gap: 8 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, color: c.sub, textTransform: "uppercase", letterSpacing: 0.45 }}>
                          Progress
                        </div>

                        {focusLoading && !focusProgress ? (
                          <div style={{ fontSize: 13, color: c.sub, lineHeight: 1.6 }}>Checking latest CE progress…</div>
                        ) : (
                          <div style={{ display: "grid", gap: 8 }}>
                            {focusItems.map((item) => {
                              const icon = item.kind === "done" ? "✔" : item.kind === "warning" ? "⚠" : "○";
                              const color = item.kind === "done" ? c.greenTx : item.kind === "warning" ? c.amberTx : c.sub;
                              const suffix = item.kind === "done" ? "complete" : item.label === "Review" ? "not ready" : "incomplete";
                              return (
                                <div key={item.label} style={{ display: "flex", gap: 10, alignItems: "center" }}>
                                  <div style={{ width: 16, color, fontSize: 13, fontWeight: 700, textAlign: "center", flexShrink: 0 }}>{icon}</div>
                                  <div style={{ fontSize: 13, color: c.text, lineHeight: 1.5 }}>
                                    {item.label}
                                    <span style={{ color: c.sub }}> • {suffix}</span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>

                      {nextFocusAction ? (
                        <div style={{ display: "grid", gap: 6, paddingTop: 2 }}>
                          <div style={{ fontSize: 12, fontWeight: 700, color: c.sub, textTransform: "uppercase", letterSpacing: 0.45 }}>
                            Primary action
                          </div>
                          <Link href={nextFocusAction.href} style={{ textDecoration: "none", color: c.text, fontSize: 13, fontWeight: 600 }}>
                            {nextFocusAction.label}
                          </Link>
                        </div>
                      ) : null}
                    </div>
                  ) : null}
                </div>
              </div>
            </div>
          </section>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1.28fr 0.72fr",
              gap: 16,
              alignItems: "start",
            }}
          >
            <SectionCard
              title="Recent CE drafts"
              hint="Return to the latest live items without relying on the sidebar alone."
            >
              {loading ? (
                <div
                  style={{
                    border: `1px solid ${c.border}`,
                    borderRadius: 18,
                    padding: 16,
                    color: c.sub,
                    background: "#fff",
                    fontSize: 14,
                  }}
                >
                  Loading drafts…
                </div>
              ) : latestFive.length === 0 ? (
                <div
                  style={{
                    border: `1px dashed ${c.borderStrong}`,
                    borderRadius: 18,
                    padding: 20,
                    color: c.sub,
                    background: "#fff",
                    fontSize: 14,
                    lineHeight: 1.6,
                  }}
                >
                  No Compensation Events yet. Start a new CE to begin building your first submission pack.
                </div>
              ) : (
                <div style={{ display: "grid", gap: 12 }}>
                  {latestFive.map((e) => {
                    const tone = statusTone(e.status);
                    const isRenaming = renamingId === e.id;
                    const isSavingRename = renameSavingId === e.id;

                    return (
                      <div
                        key={e.id}
                        style={{
                          border: `1px solid ${c.border}`,
                          borderRadius: 18,
                          padding: 16,
                          background: "#fff",
                          display: "grid",
                          gap: 12,
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            gap: 12,
                            alignItems: "flex-start",
                            flexWrap: "wrap",
                          }}
                        >
                          <div style={{ minWidth: 0, flex: 1 }}>
                            {isRenaming ? (
                              <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                                <input
                                  value={renameValue}
                                  onChange={(evt) => setRenameValue(evt.target.value)}
                                  onKeyDown={(evt) => {
                                    if (evt.key === "Enter") saveRename(e.id);
                                    if (evt.key === "Escape") cancelRename();
                                  }}
                                  autoFocus
                                  style={{
                                    flex: 1,
                                    minWidth: 220,
                                    border: `1px solid ${c.border}`,
                                    borderRadius: 12,
                                    padding: "10px 12px",
                                    fontSize: 14,
                                    fontWeight: 600,
                                    color: c.text,
                                  }}
                                />
                                <button
                                  type="button"
                                  onClick={() => saveRename(e.id)}
                                  disabled={isSavingRename || !renameValue.trim()}
                                  style={{
                                    padding: "10px 12px",
                                    borderRadius: 12,
                                    border: `1px solid ${c.black}`,
                                    background: c.black,
                                    color: "#fff",
                                    fontWeight: 700,
                                    cursor: isSavingRename ? "wait" : "pointer",
                                    opacity: isSavingRename || !renameValue.trim() ? 0.7 : 1,
                                  }}
                                >
                                  Save
                                </button>
                                <button
                                  type="button"
                                  onClick={cancelRename}
                                  style={{
                                    padding: "10px 12px",
                                    borderRadius: 12,
                                    border: `1px solid ${c.border}`,
                                    background: "#fff",
                                    color: c.text,
                                    fontWeight: 600,
                                    cursor: "pointer",
                                  }}
                                >
                                  Cancel
                                </button>
                              </div>
                            ) : (
                              <div
                                style={{
                                  fontSize: 16,
                                  fontWeight: 700,
                                  color: c.text,
                                  whiteSpace: "nowrap",
                                  overflow: "hidden",
                                  textOverflow: "ellipsis",
                                  lineHeight: 1.25,
                                }}
                              >
                                {e.title || "Untitled CE"}
                              </div>
                            )}

                            <div
                              style={{
                                marginTop: 8,
                                fontSize: 13,
                                color: c.text,
                                lineHeight: 1.45,
                                fontWeight: 600,
                              }}
                            >
                              {projectContext(e)}
                            </div>

                            <div
                              style={{
                                marginTop: 4,
                                fontSize: 12,
                                color: c.sub,
                                lineHeight: 1.45,
                                fontWeight: 600,
                                textTransform: "uppercase",
                                letterSpacing: 0.4,
                              }}
                            >
                              {contractLabel(e.contract_type)}
                            </div>
                          </div>

                          <div
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: 10,
                              flexWrap: "wrap",
                              justifyContent: "flex-end",
                            }}
                          >
                            <span
                              style={{
                                padding: "5px 8px",
                                borderRadius: 999,
                                border: `1px solid ${tone.bd}`,
                                background: tone.bg,
                                color: tone.tx,
                                fontSize: 12,
                                fontWeight: 700,
                              }}
                            >
                              {tone.label}
                            </span>

                            <span style={{ fontSize: 18, color: c.text, fontWeight: 800, letterSpacing: -0.35 }}>
                              {displayCeTotal(eventValues[e.id])}
                            </span>
                          </div>
                        </div>

                        <div
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            gap: 12,
                            flexWrap: "wrap",
                            marginTop: 2,
                          }}
                        >
                          <div style={{ fontSize: 12, color: c.sub, lineHeight: 1.55, fontWeight: 600 }}>
                            Created {niceDate(e.created_at)}
                          </div>

                          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                            {!isRenaming ? (
                              <button
                                type="button"
                                onClick={() => startRename(e)}
                                style={{
                                  padding: "10px 12px",
                                  borderRadius: 12,
                                  border: `1px solid ${c.border}`,
                                  background: "#fff",
                                  color: c.text,
                                  fontWeight: 600,
                                  fontSize: 13,
                                  cursor: "pointer",
                                }}
                              >
                                Rename
                              </button>
                            ) : null}

                            <Link
                              href={`/app/event/${e.id}`}
                              style={{
                                textDecoration: "none",
                                fontSize: 13,
                                fontWeight: 700,
                                color: c.text,
                              }}
                            >
                              Open →
                            </Link>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </SectionCard>

            <SectionCard
              title="Quick actions"
              hint="Jump back into the most useful parts of the system without losing momentum."
            >
              <div style={{ display: "grid", gap: 10 }}>
                <Link href="/app/new" style={{ textDecoration: "none" }}>
                  <div
                    style={{
                      border: `1px solid ${c.border}`,
                      borderRadius: 16,
                      padding: 15,
                      background: "#fff",
                      display: "flex",
                      justifyContent: "space-between",
                      gap: 12,
                      alignItems: "center",
                    }}
                  >
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 700, color: c.text }}>Create new CE</div>
                      <div style={{ fontSize: 12, color: c.sub, marginTop: 4, lineHeight: 1.55 }}>
                        Start a fresh draft with contract-aware setup and structured workflow.
                      </div>
                    </div>
                    <div style={{ fontWeight: 700, color: c.text }}>→</div>
                  </div>
                </Link>

                <Link href="/app/rates" style={{ textDecoration: "none" }}>
                  <div
                    style={{
                      border: `1px solid ${c.border}`,
                      borderRadius: 16,
                      padding: 15,
                      background: "#fff",
                      display: "flex",
                      justifyContent: "space-between",
                      gap: 12,
                      alignItems: "center",
                    }}
                  >
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 700, color: c.text }}>Manage rate cards</div>
                      <div style={{ fontSize: 12, color: c.sub, marginTop: 4, lineHeight: 1.55 }}>
                        Keep labour, plant and material libraries tidy for deterministic pricing.
                      </div>
                    </div>
                    <div style={{ fontWeight: 700, color: c.text }}>→</div>
                  </div>
                </Link>

                {latestEvent ? (
                  <Link href={`/app/event/${latestEvent.id}/review`} style={{ textDecoration: "none" }}>
                    <div
                      style={{
                        border: `1px solid ${c.border}`,
                        borderRadius: 16,
                        padding: 15,
                        background: "#fff",
                        display: "flex",
                        justifyContent: "space-between",
                        gap: 12,
                        alignItems: "center",
                      }}
                    >
                      <div>
                        <div style={{ fontSize: 14, fontWeight: 700, color: c.text }}>Open latest review stage</div>
                        <div style={{ fontSize: 12, color: c.sub, marginTop: 4, lineHeight: 1.55 }}>
                          Return to final checks and pack selection for the latest active event.
                        </div>
                      </div>
                      <div style={{ fontWeight: 700, color: c.text }}>→</div>
                    </div>
                  </Link>
                ) : null}
              </div>
            </SectionCard>
          </div>
        </div>
      </div>
    </div>
  );
}
