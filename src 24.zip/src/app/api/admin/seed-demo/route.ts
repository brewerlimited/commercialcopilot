import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { getAuthUserFromRequest } from "@/lib/apiAuth";
import { checkAdminWithServiceRole, normalizeEmail } from "@/lib/adminAccess";

export const dynamic = "force-dynamic";

type DemoEvent = {
  title: string;
  project_name: string;
  main_contractor: string;
  contract_type: string;
  contract_source: "standard_logic" | "upload_contract";
  event_number: number;
  event_reference: string;
  status: string;
  payment_status: string;
  event_date: string;
  notice_period_days: number | null;
  notification_deadline: string | null;
  submitted_date: string | null;
  expected_payment_date: string | null;
  last_action_type: string;
  last_action_date: string;
  delay_days: number;
  basis: {
    happened_summary: string;
    cause_type: string;
    cause_summary: string;
    difference_from_plan: string;
    mechanism_tags: string[];
    time_impact_toggle: "yes" | "no" | "unsure";
    mitigation_summary: string;
  };
  resources: Array<{
    category: "labour" | "plant" | "material";
    item_name: string;
    unit: string;
    hours: number | null;
    qty: number;
    rate: number;
    notes: string;
    tags: string[];
    start_date: string;
    end_date: string;
    linked_event: string;
  }>;
  prelims: Array<{ name: string; qty: number; unit: string; rate: number; notes: string; prelim_type: string }>;
  fee_percent: number;
  fee_basis: "defined_cost" | "defined_cost_plus_prelims";
  generated_pack?: boolean;
  contractor_response?: string;
};

type DemoEwn = {
  title: string;
  project_name: string;
  main_contractor: string;
  status: string;
  event_date: string;
  what_happened: string;
  impact: string;
  required_action: string;
  evidence: string;
  location: string;
};

async function isAdminEmail(email?: string | null) {
  const normalized = normalizeEmail(email);
  if (!normalized) return false;
  return checkAdminWithServiceRole(supabaseAdmin(), normalized);
}

function isMissingOptionalTable(error: any) {
  const msg = String(error?.message || "").toLowerCase();
  return msg.includes("does not exist") || msg.includes("schema cache") || msg.includes("relation");
}

async function ignoreMissingTable<T extends { error?: any }>(promise: Promise<T>) {
  const result = await promise;
  if (result?.error && !isMissingOptionalTable(result.error)) throw result.error;
  return result;
}

function addDays(date: string, days: number | null) {
  if (!days) return null;
  const d = new Date(`${date}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function totalResources(resources: DemoEvent["resources"]) {
  return resources.reduce((sum, r) => {
    const rate = Number(r.rate || 0);
    const qty = Number(r.qty || 0);
    const hours = r.unit === "hour" ? Number(r.hours || 0) : 1;
    return sum + rate * qty * hours;
  }, 0);
}

function prelimsTotal(prelims: DemoEvent["prelims"], delayDays: number) {
  return prelims.reduce((sum, p) => sum + Number(p.qty || 0) * Number(p.rate || 0) * delayDays, 0);
}

function moneySummary(e: DemoEvent) {
  const resources_total = totalResources(e.resources);
  const prelims_total = prelimsTotal(e.prelims, e.delay_days);
  const feeBase = e.fee_basis === "defined_cost_plus_prelims" ? resources_total + prelims_total : resources_total;
  const fee_amount = feeBase * (e.fee_percent / 100);
  return {
    resources_total,
    prelims_total,
    fee_percent: e.fee_percent,
    fee_basis: e.fee_basis,
    fee_amount,
    final_total: resources_total + prelims_total + fee_amount,
    delay_days: e.delay_days,
    updated_at: new Date().toISOString(),
  };
}

function packOutput(e: DemoEvent) {
  return {
    client_output: {
      basis_of_change: {
        background: e.basis.happened_summary,
        change_to_contract_basis: e.basis.difference_from_plan,
        event_execution: e.basis.cause_summary,
        commercial_impact: `Demo generated pack placeholder. The seeded value is £${Math.round(moneySummary(e).final_total).toLocaleString("en-GB")} based on seeded labour, plant, materials and prelims. Regenerate the pack to test live AI output.`,
        contractual_position: e.contract_type.includes("nec")
          ? "NEC demo event. Live generation should consider compensation event entitlement, Defined Cost and programme effect."
          : "JCT demo variation. Live generation should consider instruction/variation basis, direct loss and expense and supporting records.",
        conclusion: "Seeded demo output only. Use Force Generate to test the live AI chain.",
      },
      time_impact: {
        delay_days: e.delay_days,
        summary: e.basis.time_impact_toggle === "yes" ? `Seeded programme impact of ${e.delay_days} days.` : "Programme impact to be confirmed.",
      },
    },
    internal_commercial_intelligence: {
      commercial_pushback: [
        "Check whether the instruction/source record is strong enough before relying on entitlement.",
        "Make sure resource records are linked to the affected area and dates.",
        "If challenged, separate rework cost from extended duration prelims.",
      ],
      evidence_gaps: ["Photos, allocation sheets and instruction record should be attached for a live submission."],
      strength_summary: "Seeded demo pack. Good enough to unlock review/download/rebuttal flow; regenerate for real AI wording.",
      internal_risk_notes: ["Do not issue seeded placeholder text to a client."],
    },
  };
}

const EVENTS: DemoEvent[] = [
  {
    title: "CE 001 - Revised drainage run and invert levels at North Gate",
    project_name: "Ainsworth Energy Recovery Facility",
    main_contractor: "Morrison Infrastructure",
    contract_type: "nec4_ecs_option_b",
    contract_source: "standard_logic",
    event_number: 1,
    event_reference: "CE 001",
    status: "submitted",
    payment_status: "applied",
    event_date: "2026-03-11",
    notice_period_days: 56,
    notification_deadline: addDays("2026-03-11", 56),
    submitted_date: "2026-03-24",
    expected_payment_date: "2026-05-22",
    last_action_type: "submitted",
    last_action_date: "2026-03-24",
    delay_days: 4,
    fee_percent: 12.5,
    fee_basis: "defined_cost_plus_prelims",
    generated_pack: true,
    basis: {
      happened_summary: "Revised drainage drawing issued for North Gate. Installed line and setting out did not match new invert levels. Crew stopped the run, lifted two short sections and re-set chambers before continuing. Works affected the entrance haul road so the area had to be kept coned and banksman controlled.",
      cause_type: "client_instruction",
      cause_summary: "Change came from revised drainage information issued after the drainage gang had already started in the area. Site team treated it as instructed change and kept working around the entrance to avoid closing access fully.",
      difference_from_plan: "Tender/previous drawing allowed straight install to the original levels. Revised levels required rework, extra trimming, extra bedding and additional supervision/interface time at the live entrance.",
      mechanism_tags: ["rework_abortive", "restricted_access", "additional_handling"],
      time_impact_toggle: "yes",
      mitigation_summary: "Gang held in the area and completed the rework in one visit. Excavated material was kept local and access was maintained with banksman control. Records: revised drawing, site diary, photos of lifted section and allocation sheets.",
    },
    resources: [
      { category: "labour", item_name: "Drainage gang", unit: "hour", hours: 9, qty: 4, rate: 42, notes: "Lift and relay affected pipework, chamber adjustment and trimming around entrance.", tags: ["rework_abortive", "restricted_access"], start_date: "2026-03-11", end_date: "2026-03-12", linked_event: "North Gate drainage" },
      { category: "plant", item_name: "13t excavator", unit: "hour", hours: 9, qty: 1, rate: 78, notes: "Re-excavation, bedding trim and handling arisings locally.", tags: ["additional_handling"], start_date: "2026-03-11", end_date: "2026-03-12", linked_event: "North Gate drainage" },
      { category: "material", item_name: "Additional bedding stone", unit: "t", hours: null, qty: 18, rate: 34, notes: "Extra bedding/ surround due to revised levels and relay.", tags: ["rework_abortive"], start_date: "2026-03-12", end_date: "2026-03-12", linked_event: "North Gate drainage" },
    ],
    prelims: [
      { name: "Site manager", qty: 1, unit: "day", rate: 420, notes: "Entrance coordination and daily records during rework.", prelim_type: "staff" },
      { name: "Working supervisor", qty: 1, unit: "day", rate: 360, notes: "Gang control and access interface.", prelim_type: "staff" },
    ],
  },
  {
    title: "CE 002 - Standing time due to delayed permit for service corridor excavation",
    project_name: "Ainsworth Energy Recovery Facility",
    main_contractor: "Morrison Infrastructure",
    contract_type: "nec4_ecs_option_b",
    contract_source: "standard_logic",
    event_number: 2,
    event_reference: "CE 002",
    status: "rejected",
    payment_status: "not_applied",
    event_date: "2026-02-06",
    notice_period_days: 56,
    notification_deadline: addDays("2026-02-06", 56),
    submitted_date: "2026-02-20",
    expected_payment_date: null,
    last_action_type: "status_rejected",
    last_action_date: "2026-04-18",
    delay_days: 2,
    fee_percent: 12.5,
    fee_basis: "defined_cost_plus_prelims",
    generated_pack: true,
    contractor_response: "Rejected. The subcontractor should have allowed for normal permit delays and has not demonstrated that the resources could not be redeployed elsewhere on site.",
    basis: {
      happened_summary: "Excavation in service corridor held because permit and isolation confirmation were not released at planned start. Gang, excavator and dumper were on site and briefed. They waited while permit was chased, then were stood down and restarted the following working day.",
      cause_type: "access_constraint",
      cause_summary: "Delay was caused by permit/access control outside our direct control. Works could not proceed in the corridor without the permit due to live services and site rules.",
      difference_from_plan: "Planned sequence was one continuous excavation shift. Actual sequence had standing time, remobilisation and supervision time with no productive output in that corridor.",
      mechanism_tags: ["standing_time", "restricted_access", "resequencing"],
      time_impact_toggle: "yes",
      mitigation_summary: "Site manager asked for other work fronts but available tasks either needed the same permit or were blocked by deliveries. Crew completed small housekeeping only. Records: permit log, diary, allocation sheet and supervisor notes.",
    },
    resources: [
      { category: "labour", item_name: "Groundworks gang", unit: "hour", hours: 7.5, qty: 3, rate: 40, notes: "Waiting and remobilisation caused by delayed permit release.", tags: ["standing_time"], start_date: "2026-02-06", end_date: "2026-02-07", linked_event: "Service corridor permit" },
      { category: "plant", item_name: "8t excavator", unit: "hour", hours: 7.5, qty: 1, rate: 61, notes: "On site and unavailable for productive excavation while permit delayed.", tags: ["standing_time"], start_date: "2026-02-06", end_date: "2026-02-06", linked_event: "Service corridor permit" },
      { category: "plant", item_name: "6t dumper", unit: "hour", hours: 7.5, qty: 1, rate: 38, notes: "Allocated to excavation works and stood during permit delay.", tags: ["standing_time"], start_date: "2026-02-06", end_date: "2026-02-06", linked_event: "Service corridor permit" },
    ],
    prelims: [{ name: "Site supervisor", qty: 1, unit: "day", rate: 340, notes: "Permit chasing and resequencing records.", prelim_type: "staff" }],
  },
  {
    title: "CE 003 - Additional concrete breakout to transformer base",
    project_name: "Ainsworth Energy Recovery Facility",
    main_contractor: "Morrison Infrastructure",
    contract_type: "nec4_ecs_option_b",
    contract_source: "standard_logic",
    event_number: 3,
    event_reference: "CE 003",
    status: "draft",
    payment_status: "not_applied",
    event_date: "2026-05-08",
    notice_period_days: 56,
    notification_deadline: addDays("2026-05-08", 56),
    submitted_date: null,
    expected_payment_date: null,
    last_action_type: "updated",
    last_action_date: "2026-05-10",
    delay_days: 1,
    fee_percent: 12.5,
    fee_basis: "defined_cost_plus_prelims",
    basis: {
      happened_summary: "Existing concrete base found under made ground in transformer area. Not shown on clearance sketch issued to site. Supervisor instructed gang to break out enough to allow reduced level dig and duct install to continue.",
      cause_type: "site_condition",
      cause_summary: "Obstruction was below surface and not identified in the information used for the planned excavation. Works changed from normal dig/trim to saw cut, breakout, load away and re-trim.",
      difference_from_plan: "Planned work was standard excavation to formation. Actual work required breakout of reinforced concrete, extra arisings handling and disposal, plus slower excavation around remaining edges.",
      mechanism_tags: ["different_plant", "additional_handling", "rework_abortive"],
      time_impact_toggle: "unsure",
      mitigation_summary: "Broke out only the required area, kept duct route open and marked remaining concrete edge for client review. Records: photos, diary note, disposal tickets to follow.",
    },
    resources: [
      { category: "labour", item_name: "Operatives", unit: "hour", hours: 8, qty: 2, rate: 39, notes: "Assist breakout, banksman control and trimming.", tags: ["additional_handling"], start_date: "2026-05-08", end_date: "2026-05-08", linked_event: "Transformer base" },
      { category: "plant", item_name: "Breaker attachment", unit: "day", hours: null, qty: 1, rate: 180, notes: "Concrete breakout to obstruction.", tags: ["different_plant"], start_date: "2026-05-08", end_date: "2026-05-08", linked_event: "Transformer base" },
      { category: "plant", item_name: "5t excavator", unit: "day", hours: null, qty: 1, rate: 310, notes: "Breakout support, loading and re-trim.", tags: ["different_plant"], start_date: "2026-05-08", end_date: "2026-05-08", linked_event: "Transformer base" },
    ],
    prelims: [{ name: "Supervisor", qty: 1, unit: "day", rate: 340, notes: "Instruction record and obstruction management.", prelim_type: "staff" }],
  },
  {
    title: "VAR 001 - Late partition set-out change to Level 04 apartments",
    project_name: "Westgate Residential Block C",
    main_contractor: "Harwood Developments",
    contract_type: "jct_d_and_b_2016",
    contract_source: "standard_logic",
    event_number: 1,
    event_reference: "VAR 001",
    status: "accepted",
    payment_status: "paid",
    event_date: "2026-02-12",
    notice_period_days: null,
    notification_deadline: null,
    submitted_date: "2026-02-28",
    expected_payment_date: "2026-04-03",
    last_action_type: "paid",
    last_action_date: "2026-04-10",
    delay_days: 3,
    fee_percent: 10,
    fee_basis: "defined_cost_plus_prelims",
    generated_pack: true,
    basis: {
      happened_summary: "Architect issued revised Level 04 setting out moving bathroom partitions in plots 4.06 to 4.10. Metal stud had already started and materials were distributed to plots. Some track removed, re-set and boards re-cut.",
      cause_type: "design_change",
      cause_summary: "Change followed revised architect information. Site team were instructed to implement the new layout to avoid holding follow-on MEP works.",
      difference_from_plan: "Original setting out was based on previous coordinated drawings. Revised layout caused abortive stud work, extra labour to re-set tracks and additional board/waste.",
      mechanism_tags: ["rework_abortive", "resequencing", "additional_handling"],
      time_impact_toggle: "yes",
      mitigation_summary: "Works kept within same week by splitting gang and prioritising plots needed by MEP. Records: revised drawing, supervisor marked-up plan, photos, delivery/waste notes.",
    },
    resources: [
      { category: "labour", item_name: "Drylining operatives", unit: "hour", hours: 8, qty: 4, rate: 38, notes: "Remove and re-set track, re-board affected partition zones.", tags: ["rework_abortive"], start_date: "2026-02-12", end_date: "2026-02-14", linked_event: "Level 04 plots" },
      { category: "material", item_name: "Plasterboard and metal track", unit: "each", hours: null, qty: 1, rate: 1450, notes: "Additional board/track and wastage from re-cut sections.", tags: ["rework_abortive"], start_date: "2026-02-14", end_date: "2026-02-14", linked_event: "Level 04 plots" },
      { category: "plant", item_name: "Material hoist allowance", unit: "day", hours: null, qty: 1, rate: 220, notes: "Additional distribution and waste removal window.", tags: ["additional_handling"], start_date: "2026-02-14", end_date: "2026-02-14", linked_event: "Level 04 plots" },
    ],
    prelims: [{ name: "Finishing supervisor", qty: 1, unit: "day", rate: 330, notes: "Plot coordination and QA records.", prelim_type: "staff" }],
  },
  {
    title: "VAR 002 - Façade bracket clashes with revised steel edge angle",
    project_name: "Westgate Residential Block C",
    main_contractor: "Harwood Developments",
    contract_type: "jct_d_and_b_2016",
    contract_source: "standard_logic",
    event_number: 2,
    event_reference: "VAR 002",
    status: "submitted",
    payment_status: "overdue",
    event_date: "2026-01-26",
    notice_period_days: null,
    notification_deadline: null,
    submitted_date: "2026-02-17",
    expected_payment_date: "2026-03-22",
    last_action_type: "payment_updated",
    last_action_date: "2026-04-05",
    delay_days: 5,
    fee_percent: 10,
    fee_basis: "defined_cost_plus_prelims",
    generated_pack: true,
    basis: {
      happened_summary: "Façade install at east elevation stopped when brackets clashed with revised steel edge angle. Fixing positions did not match the bracket schedule on site. Installer held the mast climber position while detail was checked and brackets were re-drilled/packed locally.",
      cause_type: "design_coordination",
      cause_summary: "Clash arose from revised steel detail not coordinated with façade bracket setting out. Our planned install sequence could not continue safely until fixings were confirmed.",
      difference_from_plan: "Planned work was continuous bracket/fix install. Actual work included stoppage, checking, local re-drilling, packing and return visits to complete missed bays.",
      mechanism_tags: ["standing_time", "resequencing", "restricted_access"],
      time_impact_toggle: "yes",
      mitigation_summary: "Crew moved to two available bays where possible but mast climber position limited alternative work. Records: RFI, photos, marked-up bracket schedule, daily allocation.",
    },
    resources: [
      { category: "labour", item_name: "Façade fixing gang", unit: "hour", hours: 16, qty: 3, rate: 45, notes: "Hold, re-check, re-drill and complete return works.", tags: ["standing_time", "rework_abortive"], start_date: "2026-01-26", end_date: "2026-01-30", linked_event: "East elevation" },
      { category: "plant", item_name: "Mast climber", unit: "day", hours: null, qty: 2, rate: 380, notes: "Held in position while detail resolved and return bay completed.", tags: ["standing_time", "restricted_access"], start_date: "2026-01-26", end_date: "2026-01-27", linked_event: "East elevation" },
      { category: "material", item_name: "Packers and fixings", unit: "each", hours: null, qty: 1, rate: 620, notes: "Additional fixings/packers following revised steel detail.", tags: ["additional_handling"], start_date: "2026-01-29", end_date: "2026-01-29", linked_event: "East elevation" },
    ],
    prelims: [
      { name: "Façade supervisor", qty: 1, unit: "day", rate: 360, notes: "Clash coordination and return planning.", prelim_type: "staff" },
      { name: "Access coordinator", qty: 1, unit: "day", rate: 290, notes: "Mast climber coordination.", prelim_type: "staff" },
    ],
  },
  {
    title: "VAR 003 - Out of sequence fire stopping to risers before inspection",
    project_name: "Westgate Residential Block C",
    main_contractor: "Harwood Developments",
    contract_type: "jct_d_and_b_2016",
    contract_source: "standard_logic",
    event_number: 3,
    event_reference: "VAR 003",
    status: "draft",
    payment_status: "not_applied",
    event_date: "2026-05-06",
    notice_period_days: null,
    notification_deadline: null,
    submitted_date: null,
    expected_payment_date: null,
    last_action_type: "updated",
    last_action_date: "2026-05-09",
    delay_days: 2,
    fee_percent: 10,
    fee_basis: "defined_cost_plus_prelims",
    basis: {
      happened_summary: "Site requested fire stopping to north core risers ahead of planned inspection date. Area was not fully cleared and some MEP penetrations still being adjusted. Operatives worked around other trades and returned to complete missed openings.",
      cause_type: "acceleration_or_out_of_sequence",
      cause_summary: "Request was made to support inspection/hand over sequence. Works were brought forward from planned date and carried out around incomplete builder's work/MEP interfaces.",
      difference_from_plan: "Planned work was one visit to completed risers. Actual work required fragmented visits, waiting on access, additional protection and return to incomplete penetrations.",
      mechanism_tags: ["resequencing", "restricted_access", "standing_time"],
      time_impact_toggle: "unsure",
      mitigation_summary: "Supervisor agreed a hit list by riser and kept photo records of completed openings. Returned next day for missed penetrations. Records: WhatsApp/site instruction, photos, QA sheets.",
    },
    resources: [
      { category: "labour", item_name: "Fire stopping operatives", unit: "hour", hours: 7.5, qty: 2, rate: 42, notes: "Fragmented visit and return to incomplete riser openings.", tags: ["resequencing", "restricted_access"], start_date: "2026-05-06", end_date: "2026-05-07", linked_event: "North core risers" },
      { category: "material", item_name: "Fire stopping consumables", unit: "each", hours: null, qty: 1, rate: 480, notes: "Additional mastic/compound wastage due to split visits.", tags: ["additional_handling"], start_date: "2026-05-07", end_date: "2026-05-07", linked_event: "North core risers" },
    ],
    prelims: [{ name: "Supervisor", qty: 1, unit: "day", rate: 330, notes: "Riser access coordination and QA records.", prelim_type: "staff" }],
  },
];

const EWNS: DemoEwn[] = [
  { title: "EWN - Possible delay from HV duct crossing hold point", project_name: "Ainsworth Energy Recovery Facility", main_contractor: "Morrison Infrastructure", status: "open", event_date: "2026-05-13", location: "South service road", what_happened: "HV duct crossing cannot be completed until client confirms protection detail. Trench is open but crossing point held.", impact: "Could delay backfill and surfacing sequence if detail not released this week.", required_action: "Confirm protection detail and whether concrete surround or split duct is required.", evidence: "Site photos, marked-up sketch, supervisor diary.", },
  { title: "EWN - Existing manhole cover lower than new yard levels", project_name: "Ainsworth Energy Recovery Facility", main_contractor: "Morrison Infrastructure", status: "monitoring", event_date: "2026-05-03", location: "Yard slab grid C4", what_happened: "Existing cover appears low against latest yard level. Raising detail not issued yet.", impact: "Potential rework if slab prep continues before cover detail agreed.", required_action: "Issue level/cover adjustment instruction before final trim.", evidence: "Survey check, photo and level note.", },
  { title: "EWN - Late sample approval may hold bathroom tiling start", project_name: "Westgate Residential Block C", main_contractor: "Harwood Developments", status: "open", event_date: "2026-05-12", location: "Level 05 bathrooms", what_happened: "Tile sample and grout colour not signed off. Materials are due for call off but procurement cannot release without approval.", impact: "Bathroom tiling start may move and affect follow-on sanitaryware install.", required_action: "Confirm tile/grout approval or issue alternative selection.", evidence: "Submittal tracker, email chase, programme lookahead.", },
  { title: "EWN - Lift lobby ceiling zones not clear for close up", project_name: "Westgate Residential Block C", main_contractor: "Harwood Developments", status: "converted", event_date: "2026-04-22", location: "Level 03 lift lobby", what_happened: "Ceiling close up requested but MEP containment and access panels not complete. Drylining team asked to work around incomplete zones.", impact: "Risk of out of sequence boarding and return visits.", required_action: "Confirm agreed incomplete areas and return visit basis.", evidence: "Lookahead, photos, MEP snag list.", },
];

export async function POST(req: NextRequest) {
  try {
    const adminUser = await getAuthUserFromRequest(req);
    if (!adminUser?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    if (!(await isAdminEmail(adminUser.email))) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    const body = await req.json().catch(() => ({}));
    const targetEmail = normalizeEmail(body?.targetEmail || body?.email || adminUser.email);
    if (!targetEmail) return NextResponse.json({ error: "Missing target email" }, { status: 400 });

    const admin = supabaseAdmin();
    const users = await admin.auth.admin.listUsers({ page: 1, perPage: 1000 });
    if (users.error) throw users.error;
    const target = (users.data.users || []).find((u) => normalizeEmail(u.email) === targetEmail);
    if (!target?.id) return NextResponse.json({ error: `No Supabase auth user found for ${targetEmail}` }, { status: 404 });

    const projectNames = [...new Set(EVENTS.map((e) => e.project_name))];
    const existing = await admin.from("events").select("id").eq("user_id", target.id).in("project_name", projectNames);
    if (existing.error) throw existing.error;
    const oldIds = (existing.data || []).map((x: any) => x.id).filter(Boolean);

    if (oldIds.length) {
      await ignoreMissingTable(admin.from("event_rebuttals").delete().in("event_id", oldIds));
      await ignoreMissingTable(admin.from("event_ai_drafts").delete().in("event_id", oldIds));
      await ignoreMissingTable(admin.from("event_packs").delete().in("event_id", oldIds));
      await admin.from("event_review_settings").delete().in("event_id", oldIds);
      await admin.from("event_valuation_settings").delete().in("event_id", oldIds);
      await admin.from("event_prelim_lines").delete().in("event_id", oldIds);
      await admin.from("event_resource_lines").delete().in("event_id", oldIds);
      await admin.from("event_basis").delete().in("event_id", oldIds);
      await admin.from("events").delete().in("id", oldIds).eq("user_id", target.id);
    }
    await admin.from("ewns").delete().eq("user_id", target.id).in("project_name", projectNames);

    const createdEvents: Array<{ id: string; event: DemoEvent; total: number }> = [];
    for (const e of EVENTS) {
      const id = crypto.randomUUID();
      const summary = moneySummary(e);
      const eventInsert = await admin.from("events").insert({
        id,
        user_id: target.id,
        title: e.title,
        project_name: e.project_name,
        main_contractor: e.main_contractor,
        status: e.status,
        contract_type: e.contract_type,
        contract_source: e.contract_source,
        event_number: e.event_number,
        event_reference: e.event_reference,
        event_date: e.event_date,
        notice_period_days: e.notice_period_days,
        notification_deadline: e.notification_deadline,
        payment_status: e.payment_status,
        submitted_date: e.submitted_date,
        expected_payment_date: e.expected_payment_date,
        last_action_type: e.last_action_type,
        last_action_date: e.last_action_date,
        delay_days: e.delay_days,
        event_financial_summary: summary,
        created_at: `${e.event_date}T09:00:00.000Z`,
        updated_at: new Date().toISOString(),
      });
      if (eventInsert.error) throw eventInsert.error;

      const basisRes = await admin.from("event_basis").upsert({ event_id: id, ...e.basis, updated_at: new Date().toISOString() }, { onConflict: "event_id" });
      if (basisRes.error) throw basisRes.error;

      const resourceRows = e.resources.map((r) => ({
        event_id: id,
        category: r.category,
        item_name: r.item_name,
        unit: r.unit,
        hours: r.unit === "hour" ? r.hours : null,
        qty: r.qty,
        rate: r.rate,
        total: r.unit === "hour" ? Number(r.hours || 0) * r.qty * r.rate : r.qty * r.rate,
        notes: r.notes,
        tags: r.tags,
        start_date: r.start_date,
        end_date: r.end_date,
        linked_event: r.linked_event,
      }));
      const resourcesRes = await admin.from("event_resource_lines").insert(resourceRows);
      if (resourcesRes.error) throw resourcesRes.error;

      const valuationRes = await admin.from("event_valuation_settings").upsert({ event_id: id, fee_percent: e.fee_percent, fee_basis: e.fee_basis, work_days_per_week: 5, updated_at: new Date().toISOString() }, { onConflict: "event_id" });
      if (valuationRes.error) throw valuationRes.error;

      const prelimRes = await admin.from("event_prelim_lines").insert(e.prelims.map((p) => ({ event_id: id, ...p })));
      if (prelimRes.error) throw prelimRes.error;

      const reviewRes = await admin.from("event_review_settings").upsert({
        event_id: id,
        include_basis: true,
        include_entitlement: true,
        include_time_impact: true,
        include_evidence_register: true,
        include_cost_summary: true,
        include_prelims_fee: true,
        include_risk_notes: true,
        include_excel: true,
        include_pdf: false,
        qualifications_notes: "Demo record: evidence references are seeded as notes only. Attach real photos, instructions and allocation records when testing uploads.",
        updated_at: new Date().toISOString(),
      }, { onConflict: "event_id" });
      if (reviewRes.error) throw reviewRes.error;

      if (e.generated_pack) {
        const packRes = await admin.from("event_packs").insert({
          event_id: id,
          user_id: target.id,
          delay_days: e.delay_days,
          defined_cost: summary.resources_total,
          prelim_cost: summary.prelims_total,
          fee_amount: summary.fee_amount,
          total_value: summary.final_total,
          readiness_score: 82,
          pack_version: 1,
        }).select("id").single();
        if (packRes.error) {
          if (!isMissingOptionalTable(packRes.error)) throw packRes.error;
        } else {
        const draftRes = await admin.from("event_ai_drafts").insert({
          event_id: id,
          user_id: target.id,
          pack_id: packRes.data.id,
          draft_payload: { seeded_demo: true, event_title: e.title, basis: e.basis },
          draft_output: packOutput(e),
        });
        if (draftRes.error && !isMissingOptionalTable(draftRes.error)) throw draftRes.error;
        }
      }

      if (e.contractor_response) {
        const rebuttalRes = await admin.from("event_rebuttals").upsert({
          event_id: id,
          user_id: target.id,
          contractor_response: e.contractor_response,
          rebuttal_subject: `Response to assessment - ${e.event_reference}`,
          rebuttal_body: "Demo rebuttal placeholder. Regenerate this rebuttal to test live AI using the seeded rejection wording and event data.",
          key_points: ["Permit/access restriction was outside the subcontractor's control.", "Resources were allocated to the specific work face and could not be productively redeployed.", "Records should be checked before issuing final response."],
          risk_note: "Seeded demo only. Use live generation for final wording.",
          updated_at: new Date().toISOString(),
        }, { onConflict: "event_id" });
        if (rebuttalRes.error && !isMissingOptionalTable(rebuttalRes.error)) throw rebuttalRes.error;
      }

      createdEvents.push({ id, event: e, total: summary.final_total });
    }

    for (const ewn of EWNS) {
      const converted = ewn.status === "converted" ? createdEvents.find((x) => x.event.project_name === ewn.project_name && x.event.event_number === 3)?.id || null : null;
      const ewnRes = await admin.from("ewns").insert({
        user_id: target.id,
        title: ewn.title,
        project_name: ewn.project_name,
        main_contractor: ewn.main_contractor,
        status: ewn.status,
        converted_event_id: converted,
        converted_at: converted ? new Date().toISOString() : null,
        event_date: ewn.event_date,
        what_happened: ewn.what_happened,
        impact: ewn.impact,
        required_action: ewn.required_action,
        evidence_summary: ewn.evidence,
        location: ewn.location,
        contract_type: ewn.project_name.includes("Ainsworth") ? "nec4_ecs_option_b" : "jct_d_and_b_2016",
        created_at: `${ewn.event_date}T08:30:00.000Z`,
        updated_at: new Date().toISOString(),
      });
      if (ewnRes.error) throw ewnRes.error;
    }

    await admin.from("profiles").upsert({ id: target.id, credits_remaining: 15, ewn_credits_remaining: 20, ewn_credits_limit: 20, updated_at: new Date().toISOString() }, { onConflict: "id" });
    await admin.from("user_credits").upsert({ user_id: target.id, credits_remaining: 15, updated_at: new Date().toISOString() }, { onConflict: "user_id" });

    return NextResponse.json({ success: true, targetEmail, eventsCreated: createdEvents.length, ewnsCreated: EWNS.length, totalSeededValue: Math.round(createdEvents.reduce((s, e) => s + e.total, 0)) });
  } catch (error: any) {
    console.error("Demo seed failed", error);
    return NextResponse.json({ error: error?.message || "Demo seed failed" }, { status: 500 });
  }
}
